#! python3
# -*- coding: utf-8 -*-
"""
Móng CAD Studio — pyRevit Extension (CPython 3 + WPF + Revit 2025 .NET 8)
Triển khai thép Móng Đơn, Móng Băng, Móng Cọc & Dầm Móng theo TCVN 5574:2018 & TCVN 10304:2014.
"""

import copy
import json
import os
import sys

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
LIB_DIR = os.path.join(SCRIPT_DIR, "lib")
if LIB_DIR not in sys.path:
    sys.path.insert(0, LIB_DIR)

# Reset cached local modules inside pyRevit CPython session so updates apply immediately
for _mod_name in (
    "calc_engine",
    "cad_renderer",
    "dxf_exporter",
    "dxf_scanner",
    "poly_geom",
    "presets",
    "revit_bridge",
    "xlsx_exporter",
):
    sys.modules.pop(_mod_name, None)

import clr
clr.AddReference("PresentationFramework")
clr.AddReference("PresentationCore")
clr.AddReference("WindowsBase")

from System.IO import FileAccess, FileMode, FileStream
from System.Windows import (
    CornerRadius,
    FontWeights,
    HorizontalAlignment,
    TextWrapping,
    Thickness,
    VerticalAlignment,
    Visibility,
)
from System.Windows.Controls import (
    Border,
    Button,
    CheckBox,
    ComboBox,
    ComboBoxItem,
    Grid,
    ListBoxItem,
    Orientation,
    StackPanel,
    TextBlock,
    TextBox,
)
from System.Windows.Input import Key, MouseButtonState
from System.Windows.Interop import WindowInteropHelper
from System.Windows.Markup import XamlReader
from System.Windows.Media import BrushConverter, FontFamily

from calc_engine import (
    compute_footing,
    compute_foundation_beam,
    compute_pile_cap,
    compute_strip_footing,
    format_elevation,
)
from cad_renderer import build_cad_scene, build_model_map_scene, render_scene_to_wpf_canvas
from dxf_exporter import save_scene_to_dxf
from dxf_scanner import (
    SAMPLE_ARBITRARY_PLAN_DXF,
    SAMPLE_CUSTOM_SHAPES_DXF,
    build_configs_from_candidates,
    scan_foundation_plan_input,
)
from poly_geom import SHAPE_PRESET_LABELS, build_shape_preset_polygon
from presets import (
    DEFAULT_LAYERS,
    DEFAULT_SCANNER_SETTINGS,
    SAMPLE_FOOTINGS,
    SAMPLE_FOUNDATION_BEAMS,
    SAMPLE_PILE_CAPS,
    SAMPLE_STRIP_FOOTINGS,
    create_new_footing,
    create_new_foundation_beam,
    create_new_pile_cap,
    create_new_strip_footing,
)
from revit_bridge import (
    get_revit_scan_metadata,
    guess_pile_params,
    scan_revit_foundations,
)
from xlsx_exporter import export_project_to_xlsx

SCAN_SETTINGS_PATH = os.path.join(
    os.environ.get("APPDATA", os.path.expanduser("~")),
    "MongCADStudio",
    "scan_settings.json",
)

_BRUSH_CONV = BrushConverter()
_BRUSH_CACHE = {}


def _brush(hex_str):
    b = _BRUSH_CACHE.get(hex_str)
    if b is None:
        b = _BRUSH_CONV.ConvertFromString(hex_str)
        if b.CanFreeze:
            b.Freeze()
        _BRUSH_CACHE[hex_str] = b
    return b


def _get_revit_doc():
    try:
        uiapp = __revit__  # noqa: F821
        uidoc = uiapp.ActiveUIDocument
        if uidoc is not None:
            return uidoc, uidoc.Document
    except Exception:
        pass
    return None, None


class MongCadStudioApp(object):
    def __init__(self):
        xaml_path = os.path.join(SCRIPT_DIR, "ui.xaml")
        fs = FileStream(xaml_path, FileMode.Open, FileAccess.Read)
        try:
            self.win = XamlReader.Load(fs)
        finally:
            fs.Close()

        try:
            WindowInteropHelper(self.win).Owner = __revit__.MainWindowHandle  # noqa: F821
        except Exception:
            pass

        # Application State
        self.module = "mong_don"
        self.footings = copy.deepcopy(SAMPLE_FOOTINGS)
        self.strips = copy.deepcopy(SAMPLE_STRIP_FOOTINGS)
        self.pile_caps = copy.deepcopy(SAMPLE_PILE_CAPS)
        self.beams = copy.deepcopy(SAMPLE_FOUNDATION_BEAMS)

        self.active_ids = {
            "mong_don": self.footings[0]["id"],
            "mong_bang": self.strips[0]["id"],
            "mong_coc": self.pile_caps[0]["id"],
            "dam_mong": self.beams[0]["id"],
        }
        self.view_modes = {
            "mong_don": "sheet",
            "mong_bang": "sheet",
            "mong_coc": "sheet",
            "dam_mong": "sheet",
        }
        self.sub_tab = "basic"  # basic | geom | rebar | tcvn
        self.layers = dict(DEFAULT_LAYERS)

        self.zoom = 1.0
        self.pan_x = 0.0
        self.pan_y = 0.0
        self._dragging = False
        self._drag_last = None
        self._canvas_xform = (0.1, 400.0, 300.0)
        self._suppress_events = False

        self.scanner_defaults = dict(DEFAULT_SCANNER_SETTINGS)
        self.scanned_candidates = []
        self.active_scan_candidate_id = None
        self.last_scan_notes = []
        self.scan_source_tab = "revit"
        self.scan_settings = self._load_scan_settings()
        self.revit_meta = None
        self.level_checks = []
        self.pile_fam_checks = []
        self.dai_fam_checks = []

        self._bind_controls()
        self._refresh_all()

    def _load_scan_settings(self):
        try:
            with open(SCAN_SETTINGS_PATH, "r", encoding="utf-8") as fh:
                return json.load(fh)
        except Exception:
            return {}

    def _save_scan_settings(self, data):
        try:
            parent = os.path.dirname(SCAN_SETTINGS_PATH)
            if not os.path.exists(parent):
                os.makedirs(parent)
            with open(SCAN_SETTINGS_PATH, "w", encoding="utf-8") as fh:
                json.dump(data, fh, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def _fn(self, name):
        return self.win.FindName(name)

    def _bind_controls(self):
        self.btn_mod_don = self._fn("BtnModDon")
        self.btn_mod_bang = self._fn("BtnModBang")
        self.btn_mod_coc = self._fn("BtnModCoc")
        self.btn_mod_dam = self._fn("BtnModDam")

        self.btn_view_sheet = self._fn("BtnViewSheet")
        self.btn_view_primary = self._fn("BtnViewPrimary")
        self.btn_view_section = self._fn("BtnViewSection")
        self.btn_view_all = self._fn("BtnViewAll")
        self.btn_view_model_map = self._fn("BtnViewModelMap")

        self.btn_sub_basic = self._fn("BtnSubBasic")
        self.btn_sub_geom = self._fn("BtnSubGeom")
        self.btn_sub_rebar = self._fn("BtnSubRebar")
        self.btn_sub_tcvn = self._fn("BtnSubTcvn")

        self.lst_items = self._fn("LstItems")
        self.txt_list_header = self._fn("TxtListHeader")
        self.txt_total_summary = self._fn("TxtTotalSummary")
        self.txt_tcvn_summary = self._fn("TxtTcvnSummary")
        self.pnl_inspector = self._fn("PnlInspector")
        self.cad_canvas = self._fn("CadCanvas")
        self.txt_coords = self._fn("TxtCoords")
        self.txt_status = self._fn("TxtStatus")
        self.txt_revit_state = self._fn("TxtRevitState")

        # Module tabs
        self.btn_mod_don.Click += lambda s, e: self._switch_module("mong_don")
        self.btn_mod_bang.Click += lambda s, e: self._switch_module("mong_bang")
        self.btn_mod_coc.Click += lambda s, e: self._switch_module("mong_coc")
        self.btn_mod_dam.Click += lambda s, e: self._switch_module("dam_mong")

        # View modes
        self.btn_view_sheet.Click += lambda s, e: self._switch_view("sheet")
        self.btn_view_primary.Click += lambda s, e: self._switch_view("primary")
        self.btn_view_section.Click += lambda s, e: self._switch_view("section")
        self.btn_view_all.Click += lambda s, e: self._switch_view("all")
        self.btn_view_model_map.Click += lambda s, e: self._switch_view("model_map")

        # Sub-tabs
        self.btn_sub_basic.Click += lambda s, e: self._switch_sub_tab("basic")
        self.btn_sub_geom.Click += lambda s, e: self._switch_sub_tab("geom")
        self.btn_sub_rebar.Click += lambda s, e: self._switch_sub_tab("rebar")
        self.btn_sub_tcvn.Click += lambda s, e: self._switch_sub_tab("tcvn")

        # List CRUD
        self.lst_items.SelectionChanged += self._on_list_select
        self._fn("BtnAddItem").Click += self._on_add_item
        self._fn("BtnDeleteItem").Click += self._on_delete_item

        # Layer Checkboxes
        layer_map = [
            ("ChkLayerBeton", "DCE_BaoBeTong"),
            ("ChkLayerHatch", "DCE_Hatch"),
            ("ChkLayerThepChu", "DCE_ThepChu"),
            ("ChkLayerThepDai", "DCE_ThepDai"),
            ("ChkLayerDim", "DCE_Dim"),
            ("ChkLayerBlock", "DCE_Block"),
        ]
        for chk_name, layer_key in layer_map:
            chk = self._fn(chk_name)
            chk.Checked += lambda s, e, k=layer_key: self._toggle_layer(k, True)
            chk.Unchecked += lambda s, e, k=layer_key: self._toggle_layer(k, False)

        # Zoom & Canvas mouse
        self._fn("BtnZoomIn").Click += lambda s, e: self._set_zoom(self.zoom * 1.2)
        self._fn("BtnZoomOut").Click += lambda s, e: self._set_zoom(self.zoom / 1.2)
        self._fn("BtnZoomReset").Click += lambda s, e: self._reset_zoom()

        self.cad_canvas.SizeChanged += lambda s, e: self._redraw_canvas()
        self.cad_canvas.MouseWheel += self._on_canvas_wheel
        self.cad_canvas.MouseLeftButtonDown += self._on_canvas_down
        self.cad_canvas.MouseLeftButtonUp += self._on_canvas_up
        self.cad_canvas.MouseMove += self._on_canvas_move

        # Top Actions (DXF + Excel only)
        self._fn("BtnExportDxf").Click += self._on_export_dxf
        self._fn("BtnExportXlsx").Click += self._on_export_xlsx

        # Scanner Modal
        self.scanner_overlay = self._fn("ScannerOverlay")
        self.btn_tab_source_revit = self._fn("BtnTabSourceRevit")
        self.btn_tab_source_dxf = self._fn("BtnTabSourceDxf")
        self.pnl_source_revit = self._fn("PnlSourceRevit")
        self.pnl_source_dxf = self._fn("PnlSourceDxf")

        self.txt_revit_model_info = self._fn("TxtRevitModelInfo")
        self.pnl_revit_levels = self._fn("PnlRevitLevels")
        self.pnl_pile_families = self._fn("PnlPileFamilies")
        self.pnl_dai_families = self._fn("PnlDaiFamilies")
        self.cmb_pile_d_param = self._fn("CmbPileDParam")
        self.cmb_pile_l_param = self._fn("CmbPileLParam")
        self.cmb_pile_shape = self._fn("CmbPileShape")
        self.cmb_coord_origin = self._fn("CmbCoordOrigin")
        self.txt_revit_bang_threshold = self._fn("TxtRevitBangThreshold")

        self.txt_scan_input = self._fn("TxtScanInput")
        self.txt_scan_report = self._fn("TxtScanReport")
        self.txt_scan_counts = self._fn("TxtScanCounts")
        self.txt_bang_threshold = self._fn("TxtBangThreshold")
        self.chk_replace_existing = self._fn("ChkReplaceExisting")
        self.pnl_scan_candidates = self._fn("PnlScanCandidates")
        self.scanner_map_canvas = self._fn("ScannerMapCanvas")
        self.scanner_map_canvas.SizeChanged += lambda s, e: self._redraw_scanner_map()
        self.cmb_scan_unit = self._fn("CmbScanUnit")

        self._fn("BtnOpenScanner").Click += self._on_open_scanner
        self._fn("BtnCloseScanner").Click += lambda s, e: self._set_scanner_visible(False)
        self.btn_tab_source_revit.Click += lambda s, e: self._switch_scan_source("revit")
        self.btn_tab_source_dxf.Click += lambda s, e: self._switch_scan_source("dxf")
        self._fn("BtnRevitLevelsAll").Click += lambda s, e: self._set_all_levels(True)
        self._fn("BtnRevitLevelsNone").Click += lambda s, e: self._set_all_levels(False)
        self._fn("BtnScanRevitNow").Click += self._on_scan_revit_now
        self._fn("BtnLoadDxfFile").Click += self._on_load_dxf_file
        self._fn("BtnSamplePlan").Click += lambda s, e: self._run_sample_dxf(SAMPLE_ARBITRARY_PLAN_DXF)
        self._fn("BtnSamplePoly").Click += lambda s, e: self._run_sample_dxf(SAMPLE_CUSTOM_SHAPES_DXF)
        self._fn("BtnRunTextScan").Click += lambda s, e: self._analyze_scan_text(self.txt_scan_input.Text)
        self._fn("BtnScanSelectAll").Click += lambda s, e: self._toggle_all_scanned(True)
        self._fn("BtnScanDeselectAll").Click += lambda s, e: self._toggle_all_scanned(False)
        self._fn("BtnApplyScanned").Click += self._on_apply_scanned

        _, doc = _get_revit_doc()
        if doc is not None:
            self.txt_revit_state.Text = "Revit 2025: %s" % doc.Title
        else:
            self.txt_revit_state.Text = "Chế độ Preview độc lập (chưa kết nối Revit Document)"

    def _current_list(self):
        if self.module == "mong_don":
            return self.footings
        if self.module == "mong_bang":
            return self.strips
        if self.module == "mong_coc":
            return self.pile_caps
        return self.beams

    def _current_item(self):
        items = self._current_list()
        aid = self.active_ids.get(self.module)
        for it in items:
            if it["id"] == aid:
                return it
        if items:
            self.active_ids[self.module] = items[0]["id"]
            return items[0]
        return None

    def _compute_item(self, mod, item):
        if mod == "mong_don":
            return compute_footing(item)
        if mod == "mong_bang":
            return compute_strip_footing(item)
        if mod == "mong_coc":
            return compute_pile_cap(item)
        return compute_foundation_beam(item)

    def _effective_view_mode(self):
        vm = self.view_modes[self.module]
        if vm == "primary":
            return "plan" if self.module in ("mong_don", "mong_coc") else "elevation"
        if vm == "all":
            return "all" if self.module in ("mong_don", "mong_coc") else "all_strip"
        return vm

    def _switch_module(self, mod):
        self.module = mod
        self._reset_zoom(redraw=False)
        self._refresh_all()

    def _switch_view(self, vm):
        self.view_modes[self.module] = vm
        self._reset_zoom(redraw=False)
        self._update_header_styles()
        self._redraw_canvas()

    def _switch_sub_tab(self, tab):
        self.sub_tab = tab
        self._update_header_styles()
        self._rebuild_inspector()

    def _toggle_layer(self, key, state):
        self.layers[key] = state
        self._redraw_canvas()

    def _set_zoom(self, new_zoom):
        self.zoom = max(0.25, min(6.0, float(new_zoom)))
        self._fn("BtnZoomReset").Content = "%d%%" % int(round(self.zoom * 100.0))
        self._redraw_canvas()

    def _reset_zoom(self, redraw=True):
        self.zoom = 1.0
        self.pan_x = 0.0
        self.pan_y = 0.0
        self._fn("BtnZoomReset").Content = "100%"
        if redraw:
            self._redraw_canvas()

    def _update_header_styles(self):
        mod_btns = [
            (self.btn_mod_don, "mong_don"),
            (self.btn_mod_bang, "mong_bang"),
            (self.btn_mod_coc, "mong_coc"),
            (self.btn_mod_dam, "dam_mong"),
        ]
        for btn, key in mod_btns:
            active = key == self.module
            btn.Background = _brush("#0891B2" if active else "#0F141E")
            btn.Foreground = _brush("#FFFFFF" if active else "#94A3B8")
            btn.BorderBrush = _brush("#22D3EE" if active else "#1E293B")

        self.btn_view_primary.Content = "Mặt bằng" if self.module in ("mong_don", "mong_coc") else "Mặt đứng"
        vm = self.view_modes[self.module]
        for btn, key in ((self.btn_view_sheet, "sheet"), (self.btn_view_primary, "primary"), (self.btn_view_section, "section"), (self.btn_view_all, "all"), (self.btn_view_model_map, "model_map")):
            active = key == vm
            if key == "model_map":
                btn.Background = _brush("#7F1D1D" if active else "#161D2B")
                btn.Foreground = _brush("#FCA5A5" if active else "#F87171")
            else:
                btn.Background = _brush("#164E63" if active else "#161D2B")
                btn.Foreground = _brush("#22D3EE" if active else "#CBD5E1")

        for btn, key in ((self.btn_sub_basic, "basic"), (self.btn_sub_geom, "geom"), (self.btn_sub_rebar, "rebar"), (self.btn_sub_tcvn, "tcvn")):
            active = key == self.sub_tab
            btn.Background = _brush("#164E63" if active else "#0F141E")
            btn.Foreground = _brush("#22D3EE" if active else "#94A3B8")

    def _refresh_all(self):
        self._update_header_styles()
        self._rebuild_list()
        self._rebuild_inspector()
        self._redraw_canvas()

    def _rebuild_list(self):
        self._suppress_events = True
        try:
            self.lst_items.Items.Clear()
            items = self._current_list()
            aid = self.active_ids.get(self.module)
            headers = {
                "mong_don": "MÓNG ĐƠN",
                "mong_bang": "MÓNG BĂNG",
                "mong_coc": "MÓNG CỌC",
                "dam_mong": "DẦM MÓNG",
            }
            self.txt_list_header.Text = "%s (%d)" % (headers[self.module], len(items))

            total_kg = 0.0
            ok_cnt = 0
            warn_cnt = 0
            err_cnt = 0
            sel_idx = 0

            for idx, it in enumerate(items):
                comp = self._compute_item(self.module, it)
                if self.module == "mong_don":
                    kg_tot = comp["khoiLuongThepDayTong"]
                    kg_1 = comp["khoiLuongThepDay1Mong"]
                elif self.module == "mong_bang":
                    kg_tot = comp["khoiLuongTong"]
                    kg_1 = comp["khoiLuong1Mong"]
                elif self.module == "mong_coc":
                    kg_tot = comp["khoiLuongTong"]
                    kg_1 = comp["khoiLuong1Dai"]
                else:
                    kg_tot = comp["khoiLuongTong"]
                    kg_1 = comp["khoiLuong1Dam"]
                total_kg += kg_tot

                if comp["hasError"]:
                    err_cnt += 1
                    badge_color = "#F43F5E"
                elif comp["hasWarn"]:
                    warn_cnt += 1
                    badge_color = "#F59E0B"
                else:
                    ok_cnt += 1
                    badge_color = "#10B981"

                if self.module in ("mong_don", "mong_coc"):
                    dim_str = "%s×%s×%s" % (it["B"], it["L"], it["H"])
                elif self.module == "mong_bang":
                    dim_str = "B=%s · L=%s" % (comp["B_mong"], comp["tongL"])
                else:
                    dim_str = "%s×%s · L=%s" % (it["B_dam"], it["H_dam"], comp["tongL"])

                sp = StackPanel()
                sp.Margin = Thickness(2, 3, 2, 3)
                top_row = StackPanel()
                top_row.Orientation = Orientation.Horizontal
                t_name = TextBlock()
                t_name.Text = "%s  (SL=%d)" % (it["ten"], it["soLuong"])
                t_name.FontWeight = FontWeights.SemiBold
                t_name.FontSize = float(12)
                t_name.Foreground = _brush("#F8FAFC")
                t_dot = TextBlock()
                t_dot.Text = "  ●"
                t_dot.FontSize = float(10)
                t_dot.Foreground = _brush(badge_color)
                top_row.Children.Add(t_name)
                top_row.Children.Add(t_dot)

                t_sub = TextBlock()
                t_sub.Text = "%s · %.1f kg/cấu kiện" % (dim_str, kg_1)
                t_sub.FontSize = float(10.5)
                t_sub.Foreground = _brush("#94A3B8")

                sp.Children.Add(top_row)
                sp.Children.Add(t_sub)

                lbi = ListBoxItem()
                lbi.Content = sp
                lbi.Tag = it["id"]
                lbi.Padding = Thickness(6, 4, 6, 4)
                if it["id"] == aid:
                    sel_idx = idx
                    lbi.Background = _brush("#164E63")
                self.lst_items.Items.Add(lbi)

            if items:
                self.lst_items.SelectedIndex = sel_idx
            self.txt_total_summary.Text = "Tổng khối lượng thép: %.1f kg" % total_kg
            self.txt_tcvn_summary.Text = "TCVN: %d Đạt · %d Lưu ý · %d Lỗi" % (ok_cnt, warn_cnt, err_cnt)
        finally:
            self._suppress_events = False

    def _on_list_select(self, sender, args):
        if self._suppress_events:
            return
        sel = self.lst_items.SelectedItem
        if sel is not None and sel.Tag:
            self.active_ids[self.module] = str(sel.Tag)
            self._rebuild_list()
            self._rebuild_inspector()
            self._redraw_canvas()

    def _on_add_item(self, sender, args):
        items = self._current_list()
        nxt = len(items) + 1
        if self.module == "mong_don":
            new_it = create_new_footing(nxt)
        elif self.module == "mong_bang":
            new_it = create_new_strip_footing(nxt)
        elif self.module == "mong_coc":
            new_it = create_new_pile_cap(nxt)
        else:
            new_it = create_new_foundation_beam(nxt)
        items.append(new_it)
        self.active_ids[self.module] = new_it["id"]
        self._refresh_all()
        self.txt_status.Text = "Đã thêm cấu kiện mới: %s" % new_it["ten"]

    def _on_delete_item(self, sender, args):
        items = self._current_list()
        if len(items) <= 1:
            self.txt_status.Text = "Cần giữ lại ít nhất 1 cấu kiện trong danh sách."
            return
        aid = self.active_ids.get(self.module)
        for i, it in enumerate(items):
            if it["id"] == aid:
                removed = items.pop(i)
                self.active_ids[self.module] = items[min(i, len(items) - 1)]["id"]
                self._refresh_all()
                self.txt_status.Text = "Đã xóa cấu kiện: %s" % removed["ten"]
                return

    # ==================== DYNAMIC INSPECTOR BUILDER ====================

    def _add_section_title(self, text):
        tb = TextBlock()
        tb.Text = text.upper()
        tb.FontSize = float(11)
        tb.FontWeight = FontWeights.Bold
        tb.Foreground = _brush("#38BDF8")
        tb.Margin = Thickness(0, 10, 0, 6)
        self.pnl_inspector.Children.Add(tb)

    def _add_text_row(self, label, value, on_commit, is_float=False, is_int=False, min_val=None):
        row = Grid()
        row.Margin = Thickness(0, 0, 0, 6)
        lbl = TextBlock()
        lbl.Text = label
        lbl.FontSize = float(11.5)
        lbl.Foreground = _brush("#94A3B8")
        lbl.VerticalAlignment = VerticalAlignment.Center
        lbl.Width = float(175)
        lbl.HorizontalAlignment = HorizontalAlignment.Left

        tb = TextBox()
        tb.Text = str(value)
        tb.Width = float(140)
        tb.Height = float(26)
        tb.HorizontalAlignment = HorizontalAlignment.Right
        tb.Background = _brush("#0B0F17")
        tb.Foreground = _brush("#F8FAFC")
        tb.BorderBrush = _brush("#263145")
        tb.Padding = Thickness(6, 3, 6, 3)
        tb.FontFamily = FontFamily("Consolas")

        def commit():
            raw = tb.Text.strip()
            try:
                if is_int:
                    v = int(round(float(raw)))
                    if min_val is not None:
                        v = max(int(min_val), v)
                    on_commit(v)
                elif is_float:
                    v = float(raw)
                    if min_val is not None:
                        v = max(float(min_val), v)
                    on_commit(v)
                else:
                    on_commit(raw)
                self._rebuild_list()
                self._redraw_canvas()
                if self.sub_tab == "tcvn":
                    self._rebuild_inspector()
            except Exception:
                tb.Text = str(value)

        tb.LostFocus += lambda s, e: commit()
        tb.KeyDown += lambda s, e: commit() if e.Key == Key.Enter else None

        row.Children.Add(lbl)
        row.Children.Add(tb)
        self.pnl_inspector.Children.Add(row)

    def _add_combo_row(self, label, options, current_val, on_select):
        row = Grid()
        row.Margin = Thickness(0, 0, 0, 6)
        lbl = TextBlock()
        lbl.Text = label
        lbl.FontSize = float(11.5)
        lbl.Foreground = _brush("#94A3B8")
        lbl.VerticalAlignment = VerticalAlignment.Center
        lbl.Width = float(175)
        lbl.HorizontalAlignment = HorizontalAlignment.Left

        cmb = ComboBox()
        cmb.Width = float(140)
        cmb.Height = float(26)
        cmb.HorizontalAlignment = HorizontalAlignment.Right
        sel_idx = 0
        for idx, (opt_val, opt_label) in enumerate(options):
            ci = ComboBoxItem()
            ci.Content = opt_label
            ci.Tag = opt_val
            cmb.Items.Add(ci)
            if opt_val == current_val:
                sel_idx = idx
        cmb.SelectedIndex = sel_idx

        def on_chg(s, e):
            si = cmb.SelectedItem
            if si is not None:
                on_select(si.Tag)
                self._rebuild_list()
                self._rebuild_inspector()
                self._redraw_canvas()

        cmb.SelectionChanged += on_chg
        row.Children.Add(lbl)
        row.Children.Add(cmb)
        self.pnl_inspector.Children.Add(row)

    def _add_check_row(self, label, is_checked, on_toggle):
        chk = CheckBox()
        chk.Content = label
        chk.IsChecked = bool(is_checked)
        chk.Foreground = _brush("#CBD5E1")
        chk.FontSize = float(11.5)
        chk.Margin = Thickness(0, 4, 0, 6)
        chk.Checked += lambda s, e: (on_toggle(True), self._rebuild_list(), self._redraw_canvas())
        chk.Unchecked += lambda s, e: (on_toggle(False), self._rebuild_list(), self._redraw_canvas())
        self.pnl_inspector.Children.Add(chk)

    def _rebuild_inspector(self):
        self.pnl_inspector.Children.Clear()
        item = self._current_item()
        if item is None:
            return
        comp = self._compute_item(self.module, item)

        if self.sub_tab == "basic":
            self._add_section_title("Định danh & Số lượng")
            self._add_text_row("Tên cấu kiện", item["ten"], lambda v: item.__setitem__("ten", v or "CK1"))
            self._add_text_row("Số lượng (SL)", item["soLuong"], lambda v: item.__setitem__("soLuong", v), is_int=True, min_val=1)
            if self.module in ("mong_don", "mong_coc"):
                self._add_text_row("Tỷ lệ bản vẽ (1/x)", item["tiLe"], lambda v: item.__setitem__("tiLe", v), is_int=True, min_val=5)
            else:
                self._add_text_row("Tỷ lệ Mặt đứng (1/x)", item["tiLeMatDung"], lambda v: item.__setitem__("tiLeMatDung", v), is_int=True, min_val=10)
                self._add_text_row("Tỷ lệ Mặt cắt (1/x)", item["tiLeMatCat"], lambda v: item.__setitem__("tiLeMatCat", v), is_int=True, min_val=5)

            self._add_section_title("Cao trình & Bê tông lót")
            if self.module == "mong_don":
                self._add_text_row("Cao trình đáy móng (m)", item["caoTrinhDay"], lambda v: item.__setitem__("caoTrinhDay", v), is_float=True)
                self._add_text_row("Bề dày BT lót (mm)", item["lotDay"], lambda v: item.__setitem__("lotDay", v), is_int=True, min_val=0)
                self._add_text_row("Chìa BT lót MB (mm)", item["lotChiaMatBang"], lambda v: item.__setitem__("lotChiaMatBang", v), is_int=True, min_val=0)
                self._add_text_row("Chìa BT lót MC (mm)", item["lotChiaMatCat"], lambda v: item.__setitem__("lotChiaMatCat", v), is_int=True, min_val=0)
                self._add_text_row("Lớp bảo vệ đáy (mm)", item["coverDay"], lambda v: item.__setitem__("coverDay", v), is_int=True, min_val=15)
                self._add_text_row("Lớp bảo vệ cạnh (mm)", item["coverCanh"], lambda v: item.__setitem__("coverCanh", v), is_int=True, min_val=15)
            elif self.module == "mong_coc":
                self._add_text_row("Cao trình mặt đài (m)", item["caoTrinhMatDai"], lambda v: item.__setitem__("caoTrinhMatDai", v), is_float=True)
                self._add_text_row("Bề dày BT lót (mm)", item["lotDay"], lambda v: item.__setitem__("lotDay", v), is_int=True, min_val=0)
                self._add_text_row("Chìa BT lót MB (mm)", item["lotChiaMatBang"], lambda v: item.__setitem__("lotChiaMatBang", v), is_int=True, min_val=0)
                self._add_text_row("Chìa BT lót MC (mm)", item["lotChiaMatCat"], lambda v: item.__setitem__("lotChiaMatCat", v), is_int=True, min_val=0)
                self._add_text_row("Bảo vệ trên (mm)", item["coverTren"], lambda v: item.__setitem__("coverTren", v), is_int=True, min_val=20)
                self._add_text_row("Bảo vệ đáy (mm)", item["coverDay"], lambda v: item.__setitem__("coverDay", v), is_int=True, min_val=50)
                self._add_text_row("Bảo vệ cạnh (mm)", item["coverCanh"], lambda v: item.__setitem__("coverCanh", v), is_int=True, min_val=25)
            else:
                self._add_text_row("Cao trình đỉnh dầm (m)", item["caoTrinhTop"], lambda v: item.__setitem__("caoTrinhTop", v), is_float=True)
                self._add_text_row("Bề dày BT lót (mm)", item["lotDay"], lambda v: item.__setitem__("lotDay", v), is_int=True, min_val=0)
                self._add_text_row("Lớp bảo vệ thép (mm)", item["cover"], lambda v: item.__setitem__("cover", v), is_int=True, min_val=20)

        elif self.sub_tab == "geom":
            if self.module in ("mong_don", "mong_coc"):
                self._add_section_title("Hình dạng & Kích thước đài")
                preset_opts = [(k, v) for k, v in SHAPE_PRESET_LABELS.items()]
                self._add_combo_row("Biên dạng mặt bằng", preset_opts, item.get("shapePreset", "rect"), lambda v: self._apply_shape_preset(item, v))
                self._add_text_row("Rộng B (mm)", item["B"], lambda v: item.__setitem__("B", v), is_int=True, min_val=300)
                self._add_text_row("Dài L (mm)", item["L"], lambda v: item.__setitem__("L", v), is_int=True, min_val=300)
                self._add_text_row("Cao đài H (mm)", item["H"], lambda v: item.__setitem__("H", v), is_int=True, min_val=200)
                if self.module == "mong_don":
                    self._add_text_row("Chiều cao mép (mm)", item["hMep"], lambda v: item.__setitem__("hMep", v), is_int=True, min_val=100)

                self._add_section_title("Cột & Vị trí đặt cột")
                self._add_text_row("Cột b (mm)", item["cotB"], lambda v: item.__setitem__("cotB", v), is_int=True, min_val=120)
                self._add_text_row("Cột h (mm)", item["cotH"], lambda v: item.__setitem__("cotH", v), is_int=True, min_val=120)
                self._add_combo_row("Vị trí cột", [("center", "Đúng tâm"), ("top_flush", "Sát mép trên"), ("custom", "Lệch tâm tự chọn")], item["viTriCotMode"], lambda v: item.__setitem__("viTriCotMode", v))
                self._add_text_row("Lệch tâm X (mm)", item["lechTamX"], lambda v: item.__setitem__("lechTamX", v), is_int=True)
                self._add_text_row("Lệch tâm Y (mm)", item["lechTamY"], lambda v: item.__setitem__("lechTamY", v), is_int=True)

                if self.module == "mong_coc":
                    self._add_section_title("Bố trí Cọc")
                    self._add_combo_row("Hình dạng cọc", [("square", "Cọc vuông"), ("circle", "Cọc tròn / PHC")], item["cocHinh"], lambda v: item.__setitem__("cocHinh", v))
                    self._add_text_row("Kích thước D cọc (mm)", item["cocD"], lambda v: item.__setitem__("cocD", v), is_int=True, min_val=150)
                    self._add_text_row("Số hàng cọc theo X", item["soCocX"], lambda v: item.__setitem__("soCocX", v), is_int=True, min_val=1)
                    self._add_text_row("Số hàng cọc theo Y", item["soCocY"], lambda v: item.__setitem__("soCocY", v), is_int=True, min_val=1)
                    self._add_text_row("Bước cọc X (mm)", item["buocCocX"], lambda v: item.__setitem__("buocCocX", v), is_int=True, min_val=300)
                    self._add_text_row("Bước cọc Y (mm)", item["buocCocY"], lambda v: item.__setitem__("buocCocY", v), is_int=True, min_val=300)
                    self._add_text_row("Ngàm đầu cọc (mm)", item["ngamCoc"], lambda v: item.__setitem__("ngamCoc", v), is_int=True, min_val=50)
                else:
                    self._add_section_title("Giằng móng & Cổ cột")
                    self._add_combo_row("Giằng móng", [("both", "2 bên"), ("left", "Bên trái"), ("right", "Bên phải"), ("none", "Không vẽ")], item["giangMode"], lambda v: item.__setitem__("giangMode", v))
                    self._add_text_row("Chiều cao giằng H (mm)", item["giangH"], lambda v: item.__setitem__("giangH", v), is_int=True, min_val=200)
                    self._add_text_row("Đỉnh đài -> mặt giằng", item["caoTuDinhDaiDenMatGiang"], lambda v: item.__setitem__("caoTuDinhDaiDenMatGiang", v), is_int=True, min_val=0)

            elif self.module == "mong_bang":
                self._add_section_title("Tiết diện Dầm & Cánh băng")
                self._add_text_row("Bề rộng dầm B_dam", item["B_dam"], lambda v: item.__setitem__("B_dam", v), is_int=True, min_val=200)
                self._add_text_row("Cánh trái (mm)", item["canhTrai"], lambda v: item.__setitem__("canhTrai", v), is_int=True, min_val=0)
                self._add_text_row("Cánh phải (mm)", item["canhPhai"], lambda v: item.__setitem__("canhPhai", v), is_int=True, min_val=0)
                self._add_text_row("Chiều cao H_dam (mm)", item["H_dam"], lambda v: item.__setitem__("H_dam", v), is_int=True, min_val=300)
                self._add_text_row("Chiều cao vát (mm)", item["hVat"], lambda v: item.__setitem__("hVat", v), is_int=True, min_val=0)
                self._add_text_row("Chiều cao mép (mm)", item["hMep"], lambda v: item.__setitem__("hMep", v), is_int=True, min_val=100)
                self._add_section_title("Nhịp & Trục cột (%d nhịp)" % len(item["spans"]))
                for si, sp in enumerate(item["spans"]):
                    self._add_text_row("Nhịp %d (mm)" % (si + 1), sp["L_nhip"], lambda v, obj=sp: obj.__setitem__("L_nhip", v), is_int=True, min_val=600)
                for ci, col in enumerate(item["columns"]):
                    self._add_text_row("Cột trục %s (mm)" % col["trucLabel"], col["bCot"], lambda v, obj=col: obj.__setitem__("bCot", v), is_int=True, min_val=150)

            else:
                self._add_section_title("Tiết diện Dầm Móng")
                self._add_text_row("Bề rộng dầm B_dam", item["B_dam"], lambda v: item.__setitem__("B_dam", v), is_int=True, min_val=200)
                self._add_text_row("Chiều cao dầm H_dam", item["H_dam"], lambda v: item.__setitem__("H_dam", v), is_int=True, min_val=300)
                self._add_section_title("Gối đài & Nhịp thông thủy")
                for si, sp in enumerate(item["spans"]):
                    self._add_text_row("Nhịp thông thủy %d" % (si + 1), sp["L_thongThuy"], lambda v, obj=sp: obj.__setitem__("L_thongThuy", v), is_int=True, min_val=600)
                for gi, sup in enumerate(item["supports"]):
                    self._add_text_row("Dài gối trục %s (mm)" % sup["trucLabel"], sup["supportLen"], lambda v, obj=sup: obj.__setitem__("supportLen", v), is_int=True, min_val=300)

        elif self.sub_tab == "rebar":
            diam_opts = [(d, "Ø%d" % d) for d in (8, 10, 12, 14, 16, 18, 20, 22, 25, 28, 32)]
            if self.module == "mong_don":
                self._add_section_title("Thép đáy móng Phương X & Y")
                self._add_combo_row("Đường kính phương X", diam_opts, item["thepPhuongX"]["d"], lambda v: item["thepPhuongX"].__setitem__("d", v))
                self._add_text_row("Bước thép phương X (a)", item["thepPhuongX"]["a"], lambda v: item["thepPhuongX"].__setitem__("a", v), is_int=True, min_val=80)
                self._add_check_row("Bẻ móc lên thép X", item["thepPhuongX"].get("hasHook", False), lambda v: item["thepPhuongX"].__setitem__("hasHook", v))
                self._add_combo_row("Đường kính phương Y", diam_opts, item["thepPhuongY"]["d"], lambda v: item["thepPhuongY"].__setitem__("d", v))
                self._add_text_row("Bước thép phương Y (a)", item["thepPhuongY"]["a"], lambda v: item["thepPhuongY"].__setitem__("a", v), is_int=True, min_val=80)
                self._add_section_title("Thép chờ cổ cột & Đai")
                self._add_combo_row("Thép dọc cột", diam_opts, item["thepCotD"], lambda v: item.__setitem__("thepCotD", v))
                self._add_text_row("Chân bẻ cột (mm)", item["thepCotChanL"], lambda v: item.__setitem__("thepCotChanL", v), is_int=True, min_val=150)
                self._add_text_row("Bước đai cột (mm)", item["thepDaiA"], lambda v: item.__setitem__("thepDaiA", v), is_int=True, min_val=80)

            elif self.module == "mong_coc":
                self._add_section_title("Lưới thép đáy đài (B1, B2)")
                self._add_combo_row("ĐK đáy phương X (B1)", diam_opts, item["thepDuoiX"]["d"], lambda v: item["thepDuoiX"].__setitem__("d", v))
                self._add_text_row("Bước B1 (mm)", item["thepDuoiX"]["a"], lambda v: item["thepDuoiX"].__setitem__("a", v), is_int=True, min_val=80)
                self._add_combo_row("ĐK đáy phương Y (B2)", diam_opts, item["thepDuoiY"]["d"], lambda v: item["thepDuoiY"].__setitem__("d", v))
                self._add_text_row("Bước B2 (mm)", item["thepDuoiY"]["a"], lambda v: item["thepDuoiY"].__setitem__("a", v), is_int=True, min_val=80)
                self._add_section_title("Lưới thép mặt trên (T1, T2) & Vách")
                self._add_combo_row("ĐK trên X (T1)", diam_opts, item["thepTrenX"]["d"], lambda v: item["thepTrenX"].__setitem__("d", v))
                self._add_text_row("Bước T1 (mm)", item["thepTrenX"]["a"], lambda v: item["thepTrenX"].__setitem__("a", v), is_int=True, min_val=80)
                self._add_combo_row("ĐK trên Y (T2)", diam_opts, item["thepTrenY"]["d"], lambda v: item["thepTrenY"].__setitem__("d", v))
                self._add_text_row("Bước T2 (mm)", item["thepTrenY"]["a"], lambda v: item["thepTrenY"].__setitem__("a", v), is_int=True, min_val=80)
                self._add_text_row("Số tầng thép vách", item["soTangThepVach"], lambda v: item.__setitem__("soTangThepVach", v), is_int=True, min_val=1)

            elif self.module == "mong_bang":
                self._add_section_title("Thép dọc dầm băng")
                self._add_text_row("Số thanh thép trên", item["thepTrenCount"], lambda v: item.__setitem__("thepTrenCount", v), is_int=True, min_val=2)
                self._add_combo_row("ĐK thép trên", diam_opts, item["thepTrenD"], lambda v: item.__setitem__("thepTrenD", v))
                self._add_text_row("Số thanh thép dưới", item["thepDuoiCount"], lambda v: item.__setitem__("thepDuoiCount", v), is_int=True, min_val=2)
                self._add_combo_row("ĐK thép dưới", diam_opts, item["thepDuoiD"], lambda v: item.__setitem__("thepDuoiD", v))
                self._add_text_row("Bước đai dầm (mm)", item["thepDaiA"], lambda v: item.__setitem__("thepDaiA", v), is_int=True, min_val=80)
                self._add_section_title("Thép bản cánh (MB & Dọc cánh)")
                self._add_combo_row("ĐK thép ngang cánh MB", diam_opts, item["thepNgangCanhD"], lambda v: item.__setitem__("thepNgangCanhD", v))
                self._add_text_row("Bước ngang cánh (mm)", item["thepNgangCanhA"], lambda v: item.__setitem__("thepNgangCanhA", v), is_int=True, min_val=80)
                self._add_text_row("Số thanh dọc cánh", item["thepDocCanhCount"], lambda v: item.__setitem__("thepDocCanhCount", v), is_int=True, min_val=2)

            else:
                self._add_section_title("Thép chủ Dầm Móng")
                self._add_text_row("Số thanh trên lớp 1", item["thepTren1Count"], lambda v: item.__setitem__("thepTren1Count", v), is_int=True, min_val=2)
                self._add_combo_row("ĐK trên lớp 1", diam_opts, item["thepTren1D"], lambda v: item.__setitem__("thepTren1D", v))
                self._add_text_row("Số thanh trên lớp 2", item["thepTren2Count"], lambda v: item.__setitem__("thepTren2Count", v), is_int=True, min_val=1)
                self._add_combo_row("ĐK trên lớp 2", diam_opts, item["thepTren2D"], lambda v: item.__setitem__("thepTren2D", v))
                self._add_text_row("Số thanh dưới", item["thepDuoiCount"], lambda v: item.__setitem__("thepDuoiCount", v), is_int=True, min_val=2)
                self._add_combo_row("ĐK thép dưới", diam_opts, item["thepDuoiD"], lambda v: item.__setitem__("thepDuoiD", v))
                self._add_text_row("Bước đai gối (mm)", item["thepDaiAGoi"], lambda v: item.__setitem__("thepDaiAGoi", v), is_int=True, min_val=60)
                self._add_text_row("Bước đai nhịp (mm)", item["thepDaiANhip"], lambda v: item.__setitem__("thepDaiANhip", v), is_int=True, min_val=80)

        else:
            # TCVN & Mass summary tab
            self._add_section_title("Tổng hợp khối lượng thép")
            kg_single = comp.get("khoiLuongThepDay1Mong") or comp.get("khoiLuong1Mong") or comp.get("khoiLuong1Dai") or comp.get("khoiLuong1Dam") or 0.0
            kg_total = comp.get("khoiLuongThepDayTong") or comp.get("khoiLuongTong") or 0.0
            self._add_kv_card("1 cấu kiện", "%.1f kg" % kg_single, "#E2E8F0")
            self._add_kv_card("Tổng cộng (SL=%d)" % item["soLuong"], "%.1f kg" % kg_total, "#22D3EE")

            self._add_section_title("Kiểm tra TCVN 5574:2018 & 10304")
            for chk in comp["checks"]:
                st = chk["status"]
                bg = "#064E3B" if st == "ok" else ("#451A03" if st == "warn" else "#4C0519")
                bd = "#10B981" if st == "ok" else ("#F59E0B" if st == "warn" else "#F43F5E")
                tag = "ĐẠT" if st == "ok" else ("LƯU Ý" if st == "warn" else "LỖI")
                card = Border()
                card.Background = _brush(bg)
                card.BorderBrush = _brush(bd)
                card.BorderThickness = Thickness(1)
                card.CornerRadius = CornerRadius(3.0)
                card.Padding = Thickness(8, 6, 8, 6)
                card.Margin = Thickness(0, 0, 0, 6)
                sp = StackPanel()
                t1 = TextBlock()
                t1.Text = "[%s] %s" % (tag, chk["label"])
                t1.FontSize = float(11.5)
                t1.FontWeight = FontWeights.SemiBold
                t1.Foreground = _brush("#FFFFFF")
                t1.TextWrapping = TextWrapping.Wrap
                t2 = TextBlock()
                t2.Text = chk["detail"]
                t2.FontSize = float(11)
                t2.Foreground = _brush("#CBD5E1")
                t2.TextWrapping = TextWrapping.Wrap
                sp.Children.Add(t1)
                sp.Children.Add(t2)
                card.Child = sp
                self.pnl_inspector.Children.Add(card)

    def _add_kv_card(self, key_str, val_str, val_color):
        row = Grid()
        row.Margin = Thickness(0, 0, 0, 6)
        k = TextBlock()
        k.Text = key_str
        k.FontSize = float(11.5)
        k.Foreground = _brush("#94A3B8")
        v = TextBlock()
        v.Text = val_str
        v.FontSize = float(12)
        v.FontWeight = FontWeights.Bold
        v.Foreground = _brush(val_color)
        v.HorizontalAlignment = HorizontalAlignment.Right
        row.Children.Add(k)
        row.Children.Add(v)
        self.pnl_inspector.Children.Add(row)

    def _apply_shape_preset(self, item, preset):
        item["shapePreset"] = preset
        if preset == "rect":
            item.pop("customPolygon", None)
        elif preset != "custom":
            item["customPolygon"] = build_shape_preset_polygon(preset, float(item["B"]), float(item["L"]))

    # ==================== CANVAS RENDERING & INTERACTION ====================

    def _build_current_scene(self):
        return build_cad_scene(
            self.module,
            self._current_list(),
            self.active_ids.get(self.module),
            self._effective_view_mode(),
            self.layers,
            all_module_lists={
                "mong_don": self.footings,
                "mong_bang": self.strips,
                "mong_coc": self.pile_caps,
                "dam_mong": self.beams,
            },
        )

    def _redraw_canvas(self):
        scene = self._build_current_scene()
        self._canvas_xform = render_scene_to_wpf_canvas(
            self.cad_canvas, scene, self.zoom, self.pan_x, self.pan_y
        )

    def _on_canvas_wheel(self, sender, e):
        factor = 1.15 if e.Delta > 0 else (1.0 / 1.15)
        self._set_zoom(self.zoom * factor)

    def _on_canvas_down(self, sender, e):
        self._dragging = True
        self._drag_last = e.GetPosition(self.cad_canvas)
        self.cad_canvas.CaptureMouse()

    def _on_canvas_up(self, sender, e):
        self._dragging = False
        self.cad_canvas.ReleaseMouseCapture()

    def _on_canvas_move(self, sender, e):
        pos = e.GetPosition(self.cad_canvas)
        s, ox, oy = self._canvas_xform
        if self._dragging and e.LeftButton == MouseButtonState.Pressed and self._drag_last is not None:
            dx = float(pos.X - self._drag_last.X)
            dy = float(pos.Y - self._drag_last.Y)
            self.pan_x += dx
            self.pan_y += dy
            self._drag_last = pos
            self._redraw_canvas()
        if s > 1e-6:
            wx = int(round((float(pos.X) - ox) / s))
            wy = int(round(-(float(pos.Y) - oy) / s))
            self.txt_coords.Text = "X: %d mm | Y: %d mm · Zoom %d%%" % (wx, wy, int(round(self.zoom * 100.0)))

    # ==================== SCANNER MODAL WORKFLOW ====================

    def _set_scanner_visible(self, show):
        self.scanner_overlay.Visibility = Visibility.Visible if show else Visibility.Collapsed

    def _switch_scan_source(self, mode):
        self.scan_source_tab = mode
        is_revit = mode == "revit"
        self.pnl_source_revit.Visibility = Visibility.Visible if is_revit else Visibility.Collapsed
        self.pnl_source_dxf.Visibility = Visibility.Collapsed if is_revit else Visibility.Visible
        self.btn_tab_source_revit.Background = _brush("#0F766E" if is_revit else "#161D2B")
        self.btn_tab_source_revit.Foreground = _brush("#ECFEFF" if is_revit else "#94A3B8")
        self.btn_tab_source_dxf.Background = _brush("#0891B2" if not is_revit else "#161D2B")
        self.btn_tab_source_dxf.Foreground = _brush("#FFFFFF" if not is_revit else "#94A3B8")

    def _on_open_scanner(self, sender, e):
        _, doc = _get_revit_doc()
        if doc is not None:
            self._switch_scan_source("revit")
            self._populate_revit_scan_metadata(doc)
        else:
            self._switch_scan_source("dxf")
            self.txt_revit_model_info.Text = "Chưa mở Revit Document — hãy chuyển sang tab DXF/JSON hoặc mở file dự án trong Revit 2025."
        self._set_scanner_visible(True)

    def _set_all_levels(self, state):
        for chk, _ in self.level_checks:
            chk.IsChecked = bool(state)

    def _populate_revit_scan_metadata(self, doc):
        try:
            meta = get_revit_scan_metadata(doc)
        except Exception as ex:
            self.txt_revit_model_info.Text = "Lỗi đọc thông tin mô hình Revit: %s" % ex
            return

        self.revit_meta = meta
        st = self.scan_settings
        self.txt_revit_model_info.Text = "Mô hình: %s · %d Level · %d Family" % (
            meta["title"], len(meta["levels"]), len(meta["pileFamilies"])
        )

        # 1) Levels checklist (auto-tick Levels that actually contain Structural Foundation / Framing)
        self.pnl_revit_levels.Children.Clear()
        self.level_checks = []
        saved_lvs = set(st.get("level_names") or [])
        any_has_fnd = any(lv.get("hasFoundations") for lv in meta["levels"])
        for idx, lv in enumerate(meta["levels"]):
            chk = CheckBox()
            chk.Content = lv["label"]
            chk.Foreground = _brush("#E2E8F0")
            chk.FontSize = float(11)
            chk.Margin = Thickness(0, 2, 0, 2)
            if saved_lvs:
                chk.IsChecked = lv["name"] in saved_lvs
            elif any_has_fnd:
                chk.IsChecked = bool(lv.get("hasFoundations"))
            else:
                chk.IsChecked = (idx == 0)
            self.pnl_revit_levels.Children.Add(chk)
            self.level_checks.append((chk, lv))

        # 2) Pile families checklist (auto-tick guessed Pile families when not manually configured yet)
        self.pnl_pile_families.Children.Clear()
        self.pile_fam_checks = []
        pile_configured = bool(st.get("pile_configured"))
        saved_piles = set(st.get("pile_families") or [])
        for pf in meta["pileFamilies"]:
            chk = CheckBox()
            chk.Content = "%s (%d) [%s]" % (pf["name"], pf["count"], pf["category"])
            chk.Foreground = _brush("#E2E8F0")
            chk.FontSize = float(11)
            chk.Margin = Thickness(0, 2, 0, 2)
            if pile_configured:
                chk.IsChecked = pf["name"] in saved_piles
            else:
                chk.IsChecked = bool(pf.get("isPileGuess"))
            chk.Checked += lambda s, e: self._refresh_pile_param_combos()
            chk.Unchecked += lambda s, e: self._refresh_pile_param_combos()
            self.pnl_pile_families.Children.Add(chk)
            self.pile_fam_checks.append((chk, pf))

        # 3) Dai families checklist (auto-tick via guess_dai if first time)
        self.pnl_dai_families.Children.Clear()
        self.dai_fam_checks = []
        saved_dai = st.get("dai_fams")
        saved_dai_set = set(saved_dai) if saved_dai is not None else None
        for df in meta["daiFamilies"]:
            chk = CheckBox()
            chk.Content = "%s (%d)" % (df["name"], df["count"])
            chk.Foreground = _brush("#E2E8F0")
            chk.FontSize = float(11)
            chk.Margin = Thickness(0, 2, 0, 2)
            if saved_dai_set is not None:
                chk.IsChecked = df["name"] in saved_dai_set
            else:
                chk.IsChecked = bool(df.get("isDaiGuess"))
            self.pnl_dai_families.Children.Add(chk)
            self.dai_fam_checks.append((chk, df["name"]))

        # Restore saved coordinate & threshold & shape (or auto-guess pile shape from checked pile families)
        self.cmb_coord_origin.SelectedIndex = 1 if st.get("shared") else 0
        if st.get("shape"):
            self.cmb_pile_shape.SelectedIndex = 1 if st.get("shape") == "Vuông" else 0
        else:
            checked_shapes = [pf.get("guessedShape", "Tròn") for chk, pf in self.pile_fam_checks if bool(chk.IsChecked)]
            self.cmb_pile_shape.SelectedIndex = 1 if ("Vuông" in checked_shapes) else 0
        self.txt_revit_bang_threshold.Text = str(int(st.get("revit_bang_b") or 800))
        self._refresh_pile_param_combos()

    def _refresh_pile_param_combos(self):
        selected_pfs = [pf for chk, pf in self.pile_fam_checks if bool(chk.IsChecked)]
        all_params = []
        seen = set()
        for pf in selected_pfs:
            for nm in pf.get("params", []):
                if nm not in seen:
                    seen.add(nm)
                    all_params.append(nm)
        all_params.sort(key=lambda s: s.lower())

        st = self.scan_settings
        gd, gl = guess_pile_params(all_params)
        target_d = st.get("d_param") if (st.get("d_param") in seen) else gd
        target_l = st.get("l_param") if (st.get("l_param") in seen) else gl

        for cmb, target in ((self.cmb_pile_d_param, target_d), (self.cmb_pile_l_param, target_l)):
            cmb.Items.Clear()
            ci0 = ComboBoxItem()
            ci0.Content = "(Theo kích thước hình học / BBox)"
            ci0.Tag = ""
            cmb.Items.Add(ci0)
            sel_i = 0
            for idx, nm in enumerate(all_params):
                ci = ComboBoxItem()
                ci.Content = nm
                ci.Tag = nm
                cmb.Items.Add(ci)
                if nm == target:
                    sel_i = idx + 1
            cmb.SelectedIndex = sel_i

    def _selected_scan_unit(self):
        si = self.cmb_scan_unit.SelectedItem
        return str(si.Tag) if (si is not None and si.Tag) else "auto"

    def _run_sample_dxf(self, sample_text):
        self.txt_scan_input.Text = sample_text
        self._analyze_scan_text(sample_text)

    def _analyze_scan_text(self, raw_text):
        try:
            thr = max(350, int(float(self.txt_bang_threshold.Text.strip())))
        except Exception:
            thr = 600
        self.scanner_defaults["bangBThreshold"] = thr
        report = scan_foundation_plan_input(raw_text, self._selected_scan_unit(), self.scanner_defaults)
        self.scanned_candidates = report["candidates"]
        self.last_scan_notes = list(report["messages"])
        self.txt_scan_report.Text = " · ".join(report["messages"])
        self._render_scan_candidates()

    def _on_load_dxf_file(self, sender, e):
        from Microsoft.Win32 import OpenFileDialog
        dlg = OpenFileDialog()
        dlg.Filter = "CAD DXF / JSON (*.dxf;*.json;*.txt)|*.dxf;*.json;*.txt|Tất cả (*.*)|*.*"
        if dlg.ShowDialog():
            with open(dlg.FileName, "r", encoding="utf-8", errors="replace") as fh:
                content = fh.read()
            self.txt_scan_input.Text = content[:120000]
            self._analyze_scan_text(content)

    def _on_scan_revit_now(self, sender, e):
        _, doc = _get_revit_doc()
        if doc is None:
            self.txt_scan_report.Text = "Không tìm thấy Revit 2025 Document đang mở. Hãy mở một dự án Revit hoặc chuyển sang tab DXF/JSON."
            return

        sel_levels = [lv for chk, lv in self.level_checks if bool(chk.IsChecked)]
        sel_piles = [pf["name"] for chk, pf in self.pile_fam_checks if bool(chk.IsChecked)]
        sel_dais = [nm for chk, nm in self.dai_fam_checks if bool(chk.IsChecked)]

        si_d = self.cmb_pile_d_param.SelectedItem
        si_l = self.cmb_pile_l_param.SelectedItem
        si_sh = self.cmb_pile_shape.SelectedItem
        si_orig = self.cmb_coord_origin.SelectedItem

        d_param = str(si_d.Tag) if (si_d is not None and si_d.Tag is not None) else ""
        l_param = str(si_l.Tag) if (si_l is not None and si_l.Tag is not None) else ""
        shape = str(si_sh.Tag) if (si_sh is not None and si_sh.Tag) else "Tròn"
        shared = (str(si_orig.Tag) == "shared") if (si_orig is not None and si_orig.Tag) else False
        try:
            bang_b = max(350.0, float(self.txt_revit_bang_threshold.Text.strip()))
        except Exception:
            bang_b = 800.0

        options = {
            "level_ids": [lv["id"] for lv in sel_levels],
            "pile_families": sel_piles,
            "d_param": d_param,
            "l_param": l_param,
            "shape": shape,
            "dai_fams": sel_dais,
            "shared": shared,
            "bang_b": bang_b,
        }
        self.scan_settings = {
            "level_names": [lv["name"] for lv in sel_levels],
            "pile_families": sel_piles,
            "pile_configured": True,
            "d_param": d_param,
            "l_param": l_param,
            "shape": shape,
            "dai_fams": sel_dais,
            "shared": shared,
            "revit_bang_b": bang_b,
        }
        self._save_scan_settings(self.scan_settings)

        res = scan_revit_foundations(doc, options)
        self.scanned_candidates = res["candidates"]
        self.last_scan_notes = list(res["messages"])
        self.txt_scan_report.Text = " · ".join(res["messages"])
        self._render_scan_candidates()

    def _toggle_all_scanned(self, val):
        for c in self.scanned_candidates:
            c["selected"] = bool(val)
        self._render_scan_candidates()

    def _update_scan_counts(self):
        sel = [c for c in self.scanned_candidates if c.get("selected", True)]
        n_don = sum(1 for c in sel if c.get("kind") == "mong_don")
        n_bang = sum(1 for c in sel if c.get("kind") == "mong_bang")
        n_coc = sum(1 for c in sel if c.get("kind") == "mong_coc")
        n_dam = sum(1 for c in sel if c.get("kind") == "dam_mong")
        self.txt_scan_counts.Text = "Phân loại (%d chọn): %d Đơn · %d Băng · %d Cọc · %d Dầm" % (
            len(sel), n_don, n_bang, n_coc, n_dam
        )

    def _redraw_scanner_map(self):
        if self.scanner_map_canvas is None:
            return
        scene = build_model_map_scene(
            {},
            active_id=self.active_scan_candidate_id,
            scan_candidates=self.scanned_candidates,
        )
        render_scene_to_wpf_canvas(self.scanner_map_canvas, scene, zoom=1.0, pan_x=0.0, pan_y=0.0)

    def _render_scan_candidates(self):
        self.pnl_scan_candidates.Children.Clear()
        self._update_scan_counts()
        if self.scanned_candidates and not any(c.get("id") == self.active_scan_candidate_id for c in self.scanned_candidates):
            self.active_scan_candidate_id = self.scanned_candidates[0].get("id")
        kind_opts = [
            ("mong_don", "Móng Đơn"),
            ("mong_bang", "Móng Băng"),
            ("mong_coc", "Móng Cọc"),
            ("dam_mong", "Dầm Móng"),
        ]
        for c in self.scanned_candidates:
            is_act = (c.get("id") == self.active_scan_candidate_id)
            card = Border()
            card.Background = _brush("#162336" if is_act else ("#131C2B" if c.get("selected", True) else "#0B0F17"))
            card.BorderBrush = _brush("#EF4444" if is_act else "#263145")
            card.BorderThickness = Thickness(1.5 if is_act else 1)
            card.CornerRadius = CornerRadius(3.0)
            card.Padding = Thickness(8, 6, 8, 6)
            card.Margin = Thickness(0, 0, 0, 6)

            def _on_card_click(s, e, cid=c.get("id")):
                self.active_scan_candidate_id = cid
                self._redraw_scanner_map()

            card.MouseLeftButtonDown += _on_card_click

            outer = StackPanel()
            row = StackPanel()
            row.Orientation = Orientation.Horizontal

            chk = CheckBox()
            chk.IsChecked = bool(c.get("selected", True))
            chk.VerticalAlignment = VerticalAlignment.Center
            chk.Margin = Thickness(0, 0, 8, 0)
            chk.Checked += lambda s, e, cand=c: (cand.__setitem__("selected", True), self._update_scan_counts(), self._redraw_scanner_map())
            chk.Unchecked += lambda s, e, cand=c: (cand.__setitem__("selected", False), self._update_scan_counts(), self._redraw_scanner_map())
            row.Children.Add(chk)

            cmb = ComboBox()
            cmb.Width = float(105)
            cmb.Height = float(24)
            cmb.Margin = Thickness(0, 0, 6, 0)
            sel_k = 0
            for k_idx, (k_val, k_lbl) in enumerate(kind_opts):
                ci = ComboBoxItem()
                ci.Content = k_lbl
                ci.Tag = k_val
                cmb.Items.Add(ci)
                if k_val == c.get("kind"):
                    sel_k = k_idx
            cmb.SelectedIndex = sel_k

            def _on_kind_change(s, e, cand=c, box=cmb):
                si = box.SelectedItem
                if si is not None and si.Tag:
                    cand["kind"] = str(si.Tag)
                    self._update_scan_counts()

            cmb.SelectionChanged += _on_kind_change
            row.Children.Add(cmb)

            tb_ten = TextBox()
            tb_ten.Text = str(c.get("ten", "MĐ1"))
            tb_ten.Width = float(72)
            tb_ten.Height = float(24)
            tb_ten.Background = _brush("#0B0F17")
            tb_ten.Foreground = _brush("#F8FAFC")
            tb_ten.BorderBrush = _brush("#263145")
            tb_ten.FontFamily = FontFamily("Consolas")
            tb_ten.FontWeight = FontWeights.Bold
            tb_ten.Margin = Thickness(0, 0, 6, 0)
            tb_ten.LostFocus += lambda s, e, cand=c, bx=tb_ten: cand.__setitem__("ten", bx.Text.strip() or cand["ten"])
            row.Children.Add(tb_ten)

            lbl_sl = TextBlock()
            lbl_sl.Text = "SL:"
            lbl_sl.Foreground = _brush("#94A3B8")
            lbl_sl.FontSize = float(11)
            lbl_sl.VerticalAlignment = VerticalAlignment.Center
            lbl_sl.Margin = Thickness(0, 0, 3, 0)
            row.Children.Add(lbl_sl)

            tb_sl = TextBox()
            tb_sl.Text = str(c.get("soLuong", 1))
            tb_sl.Width = float(36)
            tb_sl.Height = float(24)
            tb_sl.Background = _brush("#0B0F17")
            tb_sl.Foreground = _brush("#22D3EE")
            tb_sl.BorderBrush = _brush("#263145")
            tb_sl.FontFamily = FontFamily("Consolas")
            tb_sl.Margin = Thickness(0, 0, 8, 0)

            def _on_sl(s, e, cand=c, bx=tb_sl):
                try:
                    cand["soLuong"] = max(1, int(round(float(bx.Text.strip()))))
                except Exception:
                    bx.Text = str(cand.get("soLuong", 1))

            tb_sl.LostFocus += _on_sl
            row.Children.Add(tb_sl)

            lbl_dim = TextBlock()
            lbl_dim.Text = "%s×%s×%s mm" % (c.get("B", 0), c.get("L", 0), c.get("H", 0))
            lbl_dim.Foreground = _brush("#CBD5E1")
            lbl_dim.FontFamily = FontFamily("Consolas")
            lbl_dim.FontSize = float(11)
            lbl_dim.VerticalAlignment = VerticalAlignment.Center
            row.Children.Add(lbl_dim)

            outer.Children.Add(row)

            lbl_sum = TextBlock()
            lbl_sum.Text = c.get("summary", "")
            lbl_sum.Foreground = _brush("#94A3B8")
            lbl_sum.FontSize = float(10.5)
            lbl_sum.Margin = Thickness(24, 3, 0, 0)
            lbl_sum.TextWrapping = TextWrapping.Wrap
            outer.Children.Add(lbl_sum)

            warns = c.get("warnings") or []
            if warns:
                lbl_w = TextBlock()
                lbl_w.Text = "⚠ " + " | ".join(warns)
                lbl_w.Foreground = _brush("#FBBF24")
                lbl_w.FontSize = float(10.5)
                lbl_w.Margin = Thickness(24, 2, 0, 0)
                lbl_w.TextWrapping = TextWrapping.Wrap
                outer.Children.Add(lbl_w)

            card.Child = outer
            self.pnl_scan_candidates.Children.Add(card)
        self._redraw_scanner_map()

    def _on_apply_scanned(self, sender, e):
        built = build_configs_from_candidates(self.scanned_candidates, self.scanner_defaults)
        replace_mode = bool(self.chk_replace_existing.IsChecked)
        added = []
        if built["mongDon"]:
            self.footings = built["mongDon"] if replace_mode else (self.footings + built["mongDon"])
            self.active_ids["mong_don"] = built["mongDon"][0]["id"]
            self.module = "mong_don"
            added.append("%d Móng Đơn" % len(built["mongDon"]))
        if built["mongBang"]:
            self.strips = built["mongBang"] if replace_mode else (self.strips + built["mongBang"])
            self.active_ids["mong_bang"] = built["mongBang"][0]["id"]
            if not built["mongDon"]:
                self.module = "mong_bang"
            added.append("%d Móng Băng" % len(built["mongBang"]))
        if built["mongCoc"]:
            self.pile_caps = built["mongCoc"] if replace_mode else (self.pile_caps + built["mongCoc"])
            self.active_ids["mong_coc"] = built["mongCoc"][0]["id"]
            if not (built["mongDon"] or built["mongBang"]):
                self.module = "mong_coc"
            added.append("%d Móng Cọc" % len(built["mongCoc"]))
        if built["damMong"]:
            self.beams = built["damMong"] if replace_mode else (self.beams + built["damMong"])
            self.active_ids["dam_mong"] = built["damMong"][0]["id"]
            if not (built["mongDon"] or built["mongBang"] or built["mongCoc"]):
                self.module = "dam_mong"
            added.append("%d Dầm Móng" % len(built["damMong"]))

        self._set_scanner_visible(False)
        self._reset_zoom(redraw=False)
        self._refresh_all()
        if added:
            self.txt_status.Text = "Bước 2 (Triển khai): đã nạp " + ", ".join(added) + " — Kiểm tra bản vẽ & Vị trí Model rồi sang Bước 3 để Xuất CAD (.DXF) / Excel."

    # ==================== EXPORT DXF & EXCEL ====================

    def _on_export_dxf(self, sender, e):
        from Microsoft.Win32 import SaveFileDialog
        item = self._current_item()
        default_name = "%s_%s.dxf" % (self.module, item["ten"] if item else "sheet")
        dlg = SaveFileDialog()
        dlg.Filter = "AutoCAD DXF (*.dxf)|*.dxf"
        dlg.FileName = default_name
        if dlg.ShowDialog():
            scene = self._build_current_scene()
            save_scene_to_dxf(scene, dlg.FileName)
            self.txt_status.Text = "Đã xuất file DXF thành công: %s" % dlg.FileName

    def _on_export_xlsx(self, sender, e):
        from Microsoft.Win32 import SaveFileDialog
        _, doc = _get_revit_doc()
        doc_title = doc.Title if doc is not None else "MongCADStudio"
        dlg = SaveFileDialog()
        dlg.Filter = "Excel Workbook (*.xlsx)|*.xlsx"
        dlg.FileName = "%s_TongHopMong.xlsx" % (doc_title or "MongCADStudio")
        if dlg.ShowDialog():
            res = export_project_to_xlsx(
                dlg.FileName,
                self.footings,
                self.strips,
                self.pile_caps,
                self.beams,
                scan_notes=self.last_scan_notes,
                doc_title=doc_title,
            )
            self.txt_status.Text = "Đã xuất Excel (%d loại, %d cấu kiện, %.1f kg thép): %s" % (
                res["typesCount"], res["totalQty"], res["totalKg"], res["path"]
            )

    def show(self):
        self.win.ShowDialog()


if __name__ == "__main__":
    app = MongCadStudioApp()
    app.show()
