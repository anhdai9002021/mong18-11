# -*- coding: utf-8 -*-
"""2D Polygon Geometry helpers (ported 1:1 from polyGeom.ts)."""

import math
import re

SHAPE_PRESET_LABELS = {
    "rect": "Chữ nhật",
    "l_shape": "Chữ L",
    "t_shape": "Chữ T",
    "chamfer": "Vát 4 góc / Bát giác",
    "tri_3": "Đài 3 cọc (Tam giác vát)",
    "pent_5": "Ngũ giác (5 cọc)",
    "hex_6": "Lục giác (6–7 cọc)",
    "trapezoid": "Hình thang",
    "custom": "Đa giác tự do",
}


def signed_polygon_area(pts):
    if not pts or len(pts) < 3:
        return 0.0
    total = 0.0
    n = len(pts)
    for i in range(n):
        a = pts[i]
        b = pts[(i + 1) % n]
        total += a["x"] * b["y"] - b["x"] * a["y"]
    return total / 2.0


def polygon_area(pts):
    return abs(signed_polygon_area(pts))


def polygon_centroid(pts):
    if not pts:
        return {"x": 0.0, "y": 0.0}
    area2 = signed_polygon_area(pts) * 2.0
    if abs(area2) < 1e-6:
        sx = sum(p["x"] for p in pts)
        sy = sum(p["y"] for p in pts)
        return {"x": sx / len(pts), "y": sy / len(pts)}
    cx = 0.0
    cy = 0.0
    n = len(pts)
    for i in range(n):
        a = pts[i]
        b = pts[(i + 1) % n]
        cross = a["x"] * b["y"] - b["x"] * a["y"]
        cx += (a["x"] + b["x"]) * cross
        cy += (a["y"] + b["y"]) * cross
    return {"x": cx / (3.0 * area2), "y": cy / (3.0 * area2)}


def clean_polygon(pts, min_seg_len=1.0):
    if not pts:
        return []
    dedup = []
    for p in pts:
        px = float(p["x"])
        py = float(p["y"])
        if not dedup or math.hypot(px - dedup[-1]["x"], py - dedup[-1]["y"]) > min_seg_len:
            dedup.append({"x": px, "y": py})
    if len(dedup) > 2 and math.hypot(dedup[0]["x"] - dedup[-1]["x"], dedup[0]["y"] - dedup[-1]["y"]) <= min_seg_len:
        dedup.pop()
    if len(dedup) < 3:
        return dedup
    if signed_polygon_area(dedup) < 0:
        dedup.reverse()
    return dedup


def dist_point_to_segment(pt, a, b):
    vx = b["x"] - a["x"]
    vy = b["y"] - a["y"]
    len2 = vx * vx + vy * vy
    if len2 < 1e-9:
        return math.hypot(pt["x"] - a["x"], pt["y"] - a["y"])
    t = ((pt["x"] - a["x"]) * vx + (pt["y"] - a["y"]) * vy) / len2
    t = max(0.0, min(1.0, t))
    return math.hypot(pt["x"] - (a["x"] + t * vx), pt["y"] - (a["y"] + t * vy))


def min_dist_to_polygon_edges(pt, poly):
    if not poly or len(poly) < 3:
        return 0.0
    min_d = float("inf")
    n = len(poly)
    for i in range(n):
        a = poly[i]
        b = poly[(i + 1) % n]
        d = dist_point_to_segment(pt, a, b)
        if d < min_d:
            min_d = d
    return min_d


def point_in_polygon(pt, poly, edge_tol=1e-3):
    if not poly or len(poly) < 3:
        return False
    if edge_tol > 0 and min_dist_to_polygon_edges(pt, poly) <= edge_tol:
        return True
    inside = False
    n = len(poly)
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]["x"], poly[i]["y"]
        xj, yj = poly[j]["x"], poly[j]["y"]
        if (yi > pt["y"]) != (yj > pt["y"]):
            x_int = ((xj - xi) * (pt["y"] - yi)) / (yj - yi + 1e-12) + xi
            if pt["x"] < x_int:
                inside = not inside
        j = i
    return inside


def convex_hull(points):
    if len(points) <= 3:
        return [dict(p) for p in points]
    pts = sorted(points, key=lambda p: (p["x"], p["y"]))

    def cross(o, a, b):
        return (a["x"] - o["x"]) * (b["y"] - o["y"]) - (a["y"] - o["y"]) * (b["x"] - o["x"])

    lower = []
    for p in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(dict(p))

    upper = []
    for p in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(dict(p))

    return lower[:-1] + upper[:-1]


def min_area_rect(pts):
    cleaned = clean_polygon(pts, 0.5)
    hull = convex_hull(cleaned) if len(cleaned) >= 3 else cleaned
    if len(hull) < 3:
        xs = [p["x"] for p in pts] or [0.0]
        ys = [p["y"] for p in pts] or [0.0]
        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)
        cx = (min_x + max_x) / 2.0
        cy = (min_y + max_y) / 2.0
        return {
            "angleDeg": 0.0,
            "B": max_x - min_x,
            "L": max_y - min_y,
            "cx": cx,
            "cy": cy,
            "uAxis": {"x": 1.0, "y": 0.0},
            "vAxis": {"x": 0.0, "y": 1.0},
            "localPoly": [{"x": round(p["x"] - cx), "y": round(p["y"] - cy)} for p in cleaned],
        }

    candidate_angles = [0.0]
    n = len(hull)
    for i in range(n):
        a = hull[i]
        b = hull[(i + 1) % n]
        ang = math.atan2(b["y"] - a["y"], b["x"] - a["x"])
        while ang <= -math.pi / 4.0:
            ang += math.pi / 2.0
        while ang > math.pi / 4.0:
            ang -= math.pi / 2.0
        if abs((ang * 180.0) / math.pi) < 1.8:
            ang = 0.0
        candidate_angles.append(ang)

    best_area = float("inf")
    best = {
        "ang": 0.0,
        "minU": 0.0,
        "maxU": 0.0,
        "minV": 0.0,
        "maxV": 0.0,
        "ux": 1.0,
        "uy": 0.0,
        "vx": 0.0,
        "vy": 1.0,
    }

    for ang in candidate_angles:
        ux = math.cos(ang)
        uy = math.sin(ang)
        vx = -uy
        vy = ux
        us = [p["x"] * ux + p["y"] * uy for p in hull]
        vs = [p["x"] * vx + p["y"] * vy for p in hull]
        min_u, max_u = min(us), max(us)
        min_v, max_v = min(vs), max(vs)
        area = (max_u - min_u) * (max_v - min_v)
        score = area * 0.995 if ang == 0.0 else area
        if score < best_area:
            best_area = score
            best = {
                "ang": ang,
                "minU": min_u,
                "maxU": max_u,
                "minV": min_v,
                "maxV": max_v,
                "ux": ux,
                "uy": uy,
                "vx": vx,
                "vy": vy,
            }

    mid_u = (best["minU"] + best["maxU"]) / 2.0
    mid_v = (best["minV"] + best["maxV"]) / 2.0
    cx = mid_u * best["ux"] + mid_v * best["vx"]
    cy = mid_u * best["uy"] + mid_v * best["vy"]
    B = best["maxU"] - best["minU"]
    L = best["maxV"] - best["minV"]

    local_raw = []
    for p in cleaned:
        dx = p["x"] - cx
        dy = p["y"] - cy
        local_raw.append({
            "x": round(dx * best["ux"] + dy * best["uy"]),
            "y": round(dx * best["vx"] + dy * best["vy"]),
        })

    return {
        "angleDeg": round((best["ang"] * 180.0) / math.pi, 1),
        "B": B,
        "L": L,
        "cx": cx,
        "cy": cy,
        "uAxis": {"x": best["ux"], "y": best["uy"]},
        "vAxis": {"x": best["vx"], "y": best["vy"]},
        "localPoly": clean_polygon(local_raw),
    }


def offset_polygon(poly, dist):
    pts = clean_polygon(poly, 0.5)
    n = len(pts)
    if n < 3 or abs(dist) < 1e-4:
        return pts

    edges = []
    for i in range(n):
        a = pts[i]
        b = pts[(i + 1) % n]
        dx = b["x"] - a["x"]
        dy = b["y"] - a["y"]
        length = math.hypot(dx, dy)
        if length < 1e-5:
            continue
        nx = dy / length
        ny = -dx / length
        edges.append({
            "a": {"x": a["x"] + nx * dist, "y": a["y"] + ny * dist},
            "b": {"x": b["x"] + nx * dist, "y": b["y"] + ny * dist},
            "vtx": a,
        })
    if len(edges) < 3:
        return pts

    out = []
    miter_limit = abs(dist) * 2.6
    m = len(edges)
    for i in range(m):
        e1 = edges[(i - 1 + m) % m]
        e2 = edges[i]
        vtx = e2["vtx"]
        dx1 = e1["b"]["x"] - e1["a"]["x"]
        dy1 = e1["b"]["y"] - e1["a"]["y"]
        dx2 = e2["b"]["x"] - e2["a"]["x"]
        dy2 = e2["b"]["y"] - e2["a"]["y"]
        det = dx1 * dy2 - dy1 * dx2
        if abs(det) < 1e-4:
            out.append({"x": e2["a"]["x"], "y": e2["a"]["y"]})
            continue
        t = ((e2["a"]["x"] - e1["a"]["x"]) * dy2 - (e2["a"]["y"] - e1["a"]["y"]) * dx2) / det
        ix = e1["a"]["x"] + t * dx1
        iy = e1["a"]["y"] + t * dy1
        if math.hypot(ix - vtx["x"], iy - vtx["y"]) > miter_limit:
            out.append({"x": e1["b"]["x"], "y": e1["b"]["y"]})
            out.append({"x": e2["a"]["x"], "y": e2["a"]["y"]})
        else:
            out.append({"x": ix, "y": iy})
    return clean_polygon(out, 1.0)


def clip_line_to_poly(poly, axis, coord):
    if not poly or len(poly) < 3:
        return []
    intersections = []
    n = len(poly)
    for i in range(n):
        a = poly[i]
        b = poly[(i + 1) % n]
        va = a["y"] if axis == "x" else a["x"]
        vb = b["y"] if axis == "x" else b["x"]
        ua = a["x"] if axis == "x" else a["y"]
        ub = b["x"] if axis == "x" else b["y"]
        if (va <= coord < vb) or (vb <= coord < va):
            t = (coord - va) / (vb - va)
            intersections.append(ua + t * (ub - ua))
    intersections.sort()
    segs = []
    for i in range(0, len(intersections) - 1, 2):
        s = intersections[i]
        e = intersections[i + 1]
        if e - s > 20.0:
            segs.append((s, e))
    return segs


def is_rect_poly(pts):
    if not pts or len(pts) < 3:
        return True
    cleaned = clean_polygon(pts, 2.0)
    if len(cleaned) != 4:
        return False
    xs = [p["x"] for p in cleaned]
    ys = [p["y"] for p in cleaned]
    bbox_area = (max(xs) - min(xs)) * (max(ys) - min(ys))
    if bbox_area < 1.0:
        return True
    return abs(polygon_area(cleaned) - bbox_area) / bbox_area < 0.03


def build_shape_preset_polygon(preset, B, L, cut_w=None, cut_h=None):
    hb = B / 2.0
    hl = L / 2.0
    cw = max(150.0, min(B * 0.75, cut_w if cut_w is not None else round(B * 0.42)))
    ch = max(150.0, min(L * 0.75, cut_h if cut_h is not None else round(L * 0.42)))

    if preset == "l_shape":
        return [
            {"x": -hb, "y": -hl},
            {"x": hb, "y": -hl},
            {"x": hb, "y": hl - ch},
            {"x": hb - cw, "y": hl - ch},
            {"x": hb - cw, "y": hl},
            {"x": -hb, "y": hl},
        ]
    if preset == "t_shape":
        side_cut = max(120.0, round(cw / 2.0))
        stem_left = -hb + side_cut
        stem_right = hb - side_cut
        flange_bot = hl - max(250.0, L - ch)
        return [
            {"x": stem_left, "y": -hl},
            {"x": stem_right, "y": -hl},
            {"x": stem_right, "y": flange_bot},
            {"x": hb, "y": flange_bot},
            {"x": hb, "y": hl},
            {"x": -hb, "y": hl},
            {"x": -hb, "y": flange_bot},
            {"x": stem_left, "y": flange_bot},
        ]
    if preset == "chamfer":
        cx = min(hb * 0.65, cw * 0.6)
        cy = min(hl * 0.65, ch * 0.6)
        return [
            {"x": -hb + cx, "y": -hl},
            {"x": hb - cx, "y": -hl},
            {"x": hb, "y": -hl + cy},
            {"x": hb, "y": hl - cy},
            {"x": hb - cx, "y": hl},
            {"x": -hb + cx, "y": hl},
            {"x": -hb, "y": hl - cy},
            {"x": -hb, "y": -hl + cy},
        ]
    if preset == "tri_3":
        top_half = max(220.0, min(hb * 0.65, (B - cw) / 2.0))
        shoulder_y = -hl + max(300.0, round(L * 0.34))
        return [
            {"x": -hb + round(cw * 0.25), "y": -hl},
            {"x": hb - round(cw * 0.25), "y": -hl},
            {"x": hb, "y": shoulder_y},
            {"x": top_half, "y": hl},
            {"x": -top_half, "y": hl},
            {"x": -hb, "y": shoulder_y},
        ]
    if preset == "pent_5":
        top_half = max(250.0, round(hb * 0.55))
        return [
            {"x": -hb, "y": -hl},
            {"x": hb, "y": -hl},
            {"x": hb, "y": round(hl * 0.2)},
            {"x": top_half, "y": hl},
            {"x": -top_half, "y": hl},
            {"x": -hb, "y": round(hl * 0.2)},
        ]
    if preset == "hex_6":
        inset_x = max(200.0, round(B * 0.25))
        return [
            {"x": -hb + inset_x, "y": -hl},
            {"x": hb - inset_x, "y": -hl},
            {"x": hb, "y": 0.0},
            {"x": hb - inset_x, "y": hl},
            {"x": -hb + inset_x, "y": hl},
            {"x": -hb, "y": 0.0},
        ]
    if preset == "trapezoid":
        top_half = max(250.0, round((B - cw) / 2.0))
        return [
            {"x": -hb, "y": -hl},
            {"x": hb, "y": -hl},
            {"x": top_half, "y": hl},
            {"x": -top_half, "y": hl},
        ]
    return [
        {"x": -hb, "y": -hl},
        {"x": hb, "y": -hl},
        {"x": hb, "y": hl},
        {"x": -hb, "y": hl},
    ]


def polygon_bbox(pts):
    if not pts:
        return {"minX": -500.0, "maxX": 500.0, "minY": -500.0, "maxY": 500.0, "B": 1000, "L": 1000}
    xs = [p["x"] for p in pts]
    ys = [p["y"] for p in pts]
    min_x, max_x = min(xs), max(xs)
    min_y, max_y = min(ys), max(ys)
    return {
        "minX": min_x,
        "maxX": max_x,
        "minY": min_y,
        "maxY": max_y,
        "B": round(max_x - min_x),
        "L": round(max_y - min_y),
    }


def center_polygon(pts):
    cleaned = clean_polygon(pts, 2.0)
    bb = polygon_bbox(cleaned)
    ox = (bb["minX"] + bb["maxX"]) / 2.0
    oy = (bb["minY"] + bb["maxY"]) / 2.0
    return {
        "poly": [{"x": round(p["x"] - ox), "y": round(p["y"] - oy)} for p in cleaned],
        "B": max(200, bb["B"]),
        "L": max(200, bb["L"]),
        "offset": {"x": ox, "y": oy},
    }


def parse_polygon_string(raw):
    if not raw:
        return []
    if isinstance(raw, list):
        pts = []
        for item in raw:
            if isinstance(item, dict) and "x" in item and "y" in item:
                try:
                    pts.append({"x": float(item["x"]), "y": float(item["y"])})
                except (TypeError, ValueError):
                    pass
        return clean_polygon(pts, 1.0)
    if not isinstance(raw, str):
        return []
    s = raw.strip()
    if ";" not in s and "," not in s:
        return []
    pts = []
    for part in s.split(";"):
        tokens = [t for t in re.split(r"[,\s]+", part.strip()) if t]
        if len(tokens) >= 2:
            try:
                pts.append({"x": float(tokens[0]), "y": float(tokens[1])})
            except ValueError:
                pass
    return clean_polygon(pts, 1.0)
