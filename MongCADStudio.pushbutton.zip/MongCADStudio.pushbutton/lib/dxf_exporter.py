# -*- coding: utf-8 -*-
"""
AutoCAD ASCII DXF Exporter (AC1021 / UTF-8 Native).
Converts CAD vector scene primitives from cad_renderer.build_cad_scene()
and build_model_map_scene() into a valid AutoCAD 2007+ ASCII DXF file
(Y-flipped to Cartesian +Y up) with LTYPE, STYLE, LAYER, SOLID hatches,
and solid rebar dots.
"""

LAYER_ACI_COLORS = {
    "DCE_Khung": 7,       # White
    "DCE_BaoBeTong": 4,   # Cyan
    "DCE_Hatch": 8,       # Dark Gray
    "DCE_ThepChu": 1,     # Red
    "DCE_ThepDai": 6,     # Magenta
    "DCE_Dim": 3,         # Green
    "DCE_Block": 2,       # Yellow
    "DCE_Highlight": 1,   # Red highlight circles for scanned model map
}

_BG_COLORS = {"#14171C", "#171B22", "#0D2230", ""}


def _dxf_pair(code, val):
    return "%s\n%s" % (code, val)


def _fmt(num):
    return "%.2f" % float(num)


def _sanitize_dxf_text(text):
    return str(text or "").replace("Ø", "%%c").replace("\n", " ")


def export_scene_to_dxf_string(scene):
    """Build complete AutoCAD AC1021 ASCII DXF string from build_cad_scene() output."""
    out = []
    b = scene.get("bounds") or (0.0, 0.0, 1000.0, 1000.0)
    min_x, min_y, max_x, max_y = float(b[0]), float(b[1]), float(b[2]), float(b[3])

    # HEADER (AC1021 = AutoCAD 2007+ native UTF-8 Vietnamese + $EXTMIN/$EXTMAX)
    out.extend([
        _dxf_pair(0, "SECTION"),
        _dxf_pair(2, "HEADER"),
        _dxf_pair(9, "$ACADVER"),
        _dxf_pair(1, "AC1021"),
        _dxf_pair(9, "$DWGCODEPAGE"),
        _dxf_pair(3, "ANSI_1252"),
        _dxf_pair(9, "$INSUNITS"),
        _dxf_pair(70, "4"),  # Millimeters
        _dxf_pair(9, "$EXTMIN"),
        _dxf_pair(10, _fmt(min_x)),
        _dxf_pair(20, _fmt(-max_y)),
        _dxf_pair(30, "0.00"),
        _dxf_pair(9, "$EXTMAX"),
        _dxf_pair(10, _fmt(max_x)),
        _dxf_pair(20, _fmt(-min_y)),
        _dxf_pair(30, "0.00"),
        _dxf_pair(0, "ENDSEC"),
    ])

    # TABLES (LTYPE + STYLE + LAYER)
    out.extend([
        _dxf_pair(0, "SECTION"),
        _dxf_pair(2, "TABLES"),
        # LTYPE
        _dxf_pair(0, "TABLE"),
        _dxf_pair(2, "LTYPE"),
        _dxf_pair(70, "2"),
        _dxf_pair(0, "LTYPE"),
        _dxf_pair(2, "CONTINUOUS"),
        _dxf_pair(70, "0"),
        _dxf_pair(3, "Solid line"),
        _dxf_pair(72, "65"),
        _dxf_pair(73, "0"),
        _dxf_pair(40, "0.00"),
        _dxf_pair(0, "LTYPE"),
        _dxf_pair(2, "DASHED"),
        _dxf_pair(70, "0"),
        _dxf_pair(3, "Dashed __ __ __"),
        _dxf_pair(72, "65"),
        _dxf_pair(73, "2"),
        _dxf_pair(40, "150.00"),
        _dxf_pair(49, "100.00"),
        _dxf_pair(49, "-50.00"),
        _dxf_pair(0, "ENDTAB"),
        # STYLE
        _dxf_pair(0, "TABLE"),
        _dxf_pair(2, "STYLE"),
        _dxf_pair(70, "1"),
        _dxf_pair(0, "STYLE"),
        _dxf_pair(2, "STANDARD"),
        _dxf_pair(70, "0"),
        _dxf_pair(40, "0.00"),
        _dxf_pair(41, "0.85"),
        _dxf_pair(50, "0.00"),
        _dxf_pair(71, "0"),
        _dxf_pair(42, "50.00"),
        _dxf_pair(3, "Arial"),
        _dxf_pair(0, "ENDTAB"),
        # LAYER
        _dxf_pair(0, "TABLE"),
        _dxf_pair(2, "LAYER"),
        _dxf_pair(70, str(len(LAYER_ACI_COLORS))),
    ])
    for lname, aci in LAYER_ACI_COLORS.items():
        out.extend([
            _dxf_pair(0, "LAYER"),
            _dxf_pair(2, lname),
            _dxf_pair(70, "0"),
            _dxf_pair(62, str(aci)),
            _dxf_pair(6, "CONTINUOUS"),
        ])
    out.extend([
        _dxf_pair(0, "ENDTAB"),
        _dxf_pair(0, "ENDSEC"),
    ])

    # ENTITIES (Flip Y so world_y down -> AutoCAD +Y up)
    out.extend([
        _dxf_pair(0, "SECTION"),
        _dxf_pair(2, "ENTITIES"),
    ])

    for prim in scene.get("primitives", []):
        kind = prim.get("kind")
        layer = prim.get("layer", "DCE_BaoBeTong")
        if layer not in LAYER_ACI_COLORS:
            layer = "DCE_BaoBeTong"
        is_dashed = bool(prim.get("dash"))

        if kind == "line":
            out.extend([
                _dxf_pair(0, "LINE"),
                _dxf_pair(8, layer),
                _dxf_pair(6, "DASHED" if is_dashed else "CONTINUOUS"),
                _dxf_pair(10, _fmt(prim["x1"])),
                _dxf_pair(20, _fmt(-prim["y1"])),
                _dxf_pair(11, _fmt(prim["x2"])),
                _dxf_pair(21, _fmt(-prim["y2"])),
            ])
        elif kind in ("polyline", "polygon"):
            pts = prim.get("pts", [])
            if len(pts) < 2:
                continue
            closed_flag = 1 if kind == "polygon" or prim.get("closed") else 0
            fill_col = (prim.get("fill") or "").upper()
            # Emit SOLID entity for filled 3/4-point triangles/quads (section arrows, elevation triangles)
            if kind == "polygon" and fill_col not in _BG_COLORS and len(pts) in (3, 4):
                p0 = pts[0]
                p1 = pts[1]
                p2 = pts[2]
                p3 = pts[3] if len(pts) == 4 else pts[2]
                # AutoCAD SOLID vertex order: 0, 1, 3, 2 when quad; 0, 1, 2, 2 when tri
                q2 = p3 if len(pts) == 4 else p2
                q3 = p2 if len(pts) == 4 else p2
                out.extend([
                    _dxf_pair(0, "SOLID"),
                    _dxf_pair(8, layer),
                    _dxf_pair(10, _fmt(p0[0])), _dxf_pair(20, _fmt(-p0[1])),
                    _dxf_pair(11, _fmt(p1[0])), _dxf_pair(21, _fmt(-p1[1])),
                    _dxf_pair(12, _fmt(q2[0])), _dxf_pair(22, _fmt(-q2[1])),
                    _dxf_pair(13, _fmt(q3[0])), _dxf_pair(23, _fmt(-q3[1])),
                ])
            if prim.get("color"):
                out.extend([
                    _dxf_pair(0, "LWPOLYLINE"),
                    _dxf_pair(8, layer),
                    _dxf_pair(6, "DASHED" if is_dashed else "CONTINUOUS"),
                    _dxf_pair(90, str(len(pts))),
                    _dxf_pair(70, str(closed_flag)),
                ])
                for px, py in pts:
                    out.extend([
                        _dxf_pair(10, _fmt(px)),
                        _dxf_pair(20, _fmt(-py)),
                    ])
        elif kind == "rect":
            if not prim.get("color"):
                continue
            x, y, w, h = prim["x"], prim["y"], prim["w"], prim["h"]
            pts = [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]
            out.extend([
                _dxf_pair(0, "LWPOLYLINE"),
                _dxf_pair(8, layer),
                _dxf_pair(6, "DASHED" if is_dashed else "CONTINUOUS"),
                _dxf_pair(90, "4"),
                _dxf_pair(70, "1"),
            ])
            for px, py in pts:
                out.extend([
                    _dxf_pair(10, _fmt(px)),
                    _dxf_pair(20, _fmt(-py)),
                ])
        elif kind == "circle":
            cx, cy, r = float(prim["cx"]), float(prim["cy"]), float(prim["r"])
            fill_col = (prim.get("fill") or "").upper()
            if fill_col not in _BG_COLORS and r > 0.5:
                # Filled rebar dot as closed donut LWPOLYLINE (two semicircles, bulge=1, width=r)
                half_r = r * 0.5
                out.extend([
                    _dxf_pair(0, "LWPOLYLINE"),
                    _dxf_pair(8, layer),
                    _dxf_pair(90, "2"),
                    _dxf_pair(70, "1"),
                    _dxf_pair(43, _fmt(r)),
                    _dxf_pair(10, _fmt(cx - half_r)),
                    _dxf_pair(20, _fmt(-cy)),
                    _dxf_pair(42, "1.0"),
                    _dxf_pair(10, _fmt(cx + half_r)),
                    _dxf_pair(20, _fmt(-cy)),
                    _dxf_pair(42, "1.0"),
                ])
            else:
                out.extend([
                    _dxf_pair(0, "CIRCLE"),
                    _dxf_pair(8, layer),
                    _dxf_pair(6, "DASHED" if is_dashed else "CONTINUOUS"),
                    _dxf_pair(10, _fmt(cx)),
                    _dxf_pair(20, _fmt(-cy)),
                    _dxf_pair(40, _fmt(r)),
                ])
        elif kind == "text":
            txt = _sanitize_dxf_text(prim.get("text", ""))
            if not txt:
                continue
            h_txt = max(12.0, float(prim.get("size", 50.0)) * 0.8)
            rot = float(prim.get("rotate", 0.0))
            anchor = prim.get("anchor", "middle")
            halign = 1 if anchor == "middle" else (2 if anchor == "end" else 0)
            ax = _fmt(prim["x"])
            ay = _fmt(-prim["y"])
            out.extend([
                _dxf_pair(0, "TEXT"),
                _dxf_pair(8, layer),
                _dxf_pair(7, "STANDARD"),
                _dxf_pair(10, ax),
                _dxf_pair(20, ay),
                _dxf_pair(40, _fmt(h_txt)),
                _dxf_pair(50, _fmt(-rot if rot else 0.0)),
                _dxf_pair(1, txt),
            ])
            if halign != 0:
                out.extend([
                    _dxf_pair(72, str(halign)),
                    _dxf_pair(73, "2"),
                    _dxf_pair(11, ax),
                    _dxf_pair(21, ay),
                ])

    out.extend([
        _dxf_pair(0, "ENDSEC"),
        _dxf_pair(0, "EOF"),
    ])
    return "\n".join(out) + "\n"


def save_scene_to_dxf(scene, filepath):
    content = export_scene_to_dxf_string(scene)
    with open(filepath, "w", encoding="utf-8") as fh:
        fh.write(content)
    return filepath
