# -*- coding: utf-8 -*-
"""
Unified CAD Vector Scene Builder & WPF Canvas Renderer for all 4 foundation modules:
- mong_don (Móng Đơn)
- mong_bang (Móng Băng)
- mong_coc (Móng Cọc)
- dam_mong (Dầm Móng)
+ model_map (2D Model Floor-Plan Locator with Red Circles around scanned items)

Builds world-coordinate vector primitives once so WPF Canvas and AutoCAD DXF export
render the exact same engineering drawing.
"""

import math
from calc_engine import (
    compute_footing,
    compute_foundation_beam,
    compute_pile_cap,
    compute_strip_footing,
    format_elevation,
)
from poly_geom import clip_line_to_poly, offset_polygon

CAD = {
    "bg": "#14171C",
    "frame": "#E5E7EB",
    "concrete": "#00F0FF",
    "capPlanEdge": "#94A3B8",
    "colPlanMagenta": "#E84393",
    "pileYellow": "#FACC15",
    "axisGreen": "#22E559",
    "zigzag": "#38BDF8",
    "hatch": "#727B88",
    "rebar": "#FF2B2B",
    "stirrup": "#E84393",
    "dimLine": "#8D97A5",
    "dimText": "#22E559",
    "calloutCircle": "#94A3B8",
    "calloutNum": "#F87171",
    "titleText": "#FFFFFF",
    "axisLabel": "#EAB308",
    "highlightRed": "#EF4444",
    "highlightBright": "#FF2B2B",
}


class SceneBuilder(object):
    def __init__(self, layers):
        self.layers = layers
        self.prims = []
        self.min_x = float("inf")
        self.min_y = float("inf")
        self.max_x = float("-inf")
        self.max_y = float("-inf")

    def _expand(self, x, y):
        if x < self.min_x:
            self.min_x = x
        if y < self.min_y:
            self.min_y = y
        if x > self.max_x:
            self.max_x = x
        if y > self.max_y:
            self.max_y = y

    def line(self, x1, y1, x2, y2, color, width=3.5, layer="DCE_BaoBeTong", dash=None):
        x1, y1, x2, y2 = float(x1), float(y1), float(x2), float(y2)
        self._expand(x1, y1)
        self._expand(x2, y2)
        self.prims.append({
            "kind": "line",
            "x1": x1, "y1": y1, "x2": x2, "y2": y2,
            "color": color, "width": float(width), "layer": layer, "dash": dash,
        })

    def rect(self, x, y, w, h, stroke=None, fill=None, width=3.5, layer="DCE_BaoBeTong", dash=None):
        x, y, w, h = float(x), float(y), float(w), float(h)
        self._expand(x, y)
        self._expand(x + w, y + h)
        self.prims.append({
            "kind": "rect",
            "x": x, "y": y, "w": w, "h": h,
            "color": stroke, "fill": fill, "width": float(width), "layer": layer, "dash": dash,
        })

    def polygon(self, pts, stroke=None, fill=None, width=3.5, layer="DCE_BaoBeTong", dash=None):
        if not pts or len(pts) < 3:
            return
        norm_pts = [(float(p[0]), float(p[1])) for p in pts]
        for px, py in norm_pts:
            self._expand(px, py)
        self.prims.append({
            "kind": "polygon",
            "pts": norm_pts,
            "color": stroke, "fill": fill, "width": float(width), "layer": layer, "dash": dash,
        })

    def polyline(self, pts, color, width=3.5, layer="DCE_BaoBeTong", closed=False, dash=None):
        if not pts or len(pts) < 2:
            return
        norm_pts = [(float(p[0]), float(p[1])) for p in pts]
        for px, py in norm_pts:
            self._expand(px, py)
        self.prims.append({
            "kind": "polyline",
            "pts": norm_pts,
            "color": color, "width": float(width), "layer": layer, "closed": closed, "dash": dash,
        })

    def circle(self, cx, cy, r, stroke=None, fill=None, width=3.5, layer="DCE_Block", dash=None):
        cx, cy, r = float(cx), float(cy), float(r)
        self._expand(cx - r, cy - r)
        self._expand(cx + r, cy + r)
        self.prims.append({
            "kind": "circle",
            "cx": cx, "cy": cy, "r": r,
            "color": stroke, "fill": fill, "width": float(width), "layer": layer, "dash": dash,
        })

    def text(self, x, y, txt, color, size=48.0, anchor="middle", layer="DCE_Dim", bold=False, rotate=0.0):
        x, y = float(x), float(y)
        self._expand(x - size, y - size)
        self._expand(x + size, y + size)
        self.prims.append({
            "kind": "text",
            "x": x, "y": y, "text": str(txt),
            "color": color, "size": float(size), "anchor": anchor,
            "layer": layer, "bold": bool(bold), "rotate": float(rotate),
        })

    def arch_tick(self, x, y, size=18.0, width=5.0):
        self.line(x - size, y + size, x + size, y - size, CAD["dimLine"], width, layer="DCE_Dim")

    def dim_h(self, x1, x2, y_dim, y_ext1, text, y_ext2=None, font_size=48.0, tick_size=18.0, overshoot=35.0, text_above=True):
        if not self.layers.get("DCE_Dim", True):
            return
        if y_ext2 is None:
            y_ext2 = y_ext1
        min_x = min(x1, x2)
        max_x = max(x1, x2)
        if max_x - min_x < 1.0:
            return
        dir1 = 1.0 if y_dim > y_ext1 else -1.0
        dir2 = 1.0 if y_dim > y_ext2 else -1.0
        mid_x = (min_x + max_x) / 2.0
        sw = max(2.2, font_size * 0.048)
        text_y = (y_dim - font_size * 0.45) if text_above else (y_dim + font_size * 1.1)
        self.line(min_x, y_ext1, min_x, y_dim + dir1 * overshoot, CAD["dimLine"], sw, "DCE_Dim")
        self.line(max_x, y_ext2, max_x, y_dim + dir2 * overshoot, CAD["dimLine"], sw, "DCE_Dim")
        self.line(min_x - overshoot, y_dim, max_x + overshoot, y_dim, CAD["dimLine"], sw, "DCE_Dim")
        self.arch_tick(min_x, y_dim, tick_size, sw * 1.7)
        self.arch_tick(max_x, y_dim, tick_size, sw * 1.7)
        self.text(mid_x, text_y, text, CAD["dimText"], font_size, "middle", "DCE_Dim", bold=True)

    def dim_v(self, y1, y2, x_dim, x_ext1, text, x_ext2=None, font_size=48.0, tick_size=18.0, overshoot=35.0, text_side="left"):
        if not self.layers.get("DCE_Dim", True):
            return
        if x_ext2 is None:
            x_ext2 = x_ext1
        min_y = min(y1, y2)
        max_y = max(y1, y2)
        if max_y - min_y < 1.0:
            return
        dir1 = 1.0 if x_dim > x_ext1 else -1.0
        dir2 = 1.0 if x_dim > x_ext2 else -1.0
        mid_y = (min_y + max_y) / 2.0
        sw = max(2.2, font_size * 0.048)
        self.line(x_ext1, min_y, x_dim + dir1 * overshoot, min_y, CAD["dimLine"], sw, "DCE_Dim")
        self.line(x_ext2, max_y, x_dim + dir2 * overshoot, max_y, CAD["dimLine"], sw, "DCE_Dim")
        self.line(x_dim, min_y - overshoot, x_dim, max_y + overshoot, CAD["dimLine"], sw, "DCE_Dim")
        self.arch_tick(x_dim, min_y, tick_size, sw * 1.7)
        self.arch_tick(x_dim, max_y, tick_size, sw * 1.7)
        if text_side == "right":
            self.text(x_dim + font_size * 0.55, mid_y, text, CAD["dimText"], font_size, "start", "DCE_Dim", bold=True)
        else:
            self.text(x_dim - font_size * 0.55, mid_y, text, CAD["dimText"], font_size, "end", "DCE_Dim", bold=True)

    def callout(self, cx, cy, mark, spec_text, leader_pts, text_side="right", r=54.0, font_size=48.0, ox=0.0, oy=0.0, rotate=0.0):
        if not self.layers.get("DCE_Block", True):
            return
        shifted = [(px + ox, py + oy) for (px, py) in leader_pts]
        self.polyline(shifted, CAD["dimLine"], max(2.5, font_size * 0.055), "DCE_Block")
        acx, acy = cx + ox, cy + oy
        self.circle(acx, acy, r, stroke=CAD["calloutCircle"], fill=CAD["bg"], width=max(3.0, font_size * 0.065), layer="DCE_Block")
        self.text(acx, acy + font_size * 0.1, mark, CAD["calloutNum"], font_size, "middle", "DCE_Block", bold=True)
        if abs(rotate) > 1.0:
            # Rotated vertical spec along bar
            ty = (acx, acy - r - font_size * 0.55)
            self.text(acx, acy - r - font_size * 0.55, spec_text, CAD["dimText"], font_size, "start", "DCE_Block", bold=True, rotate=rotate)
        else:
            tx = (acx - r - font_size * 0.35) if text_side == "left" else (acx + r + font_size * 0.35)
            anchor = "end" if text_side == "left" else "start"
            self.text(tx, acy - font_size * 0.55, spec_text, CAD["dimText"], font_size, anchor, "DCE_Block", bold=True)

    def section_marker(self, x, y, direction="up", label="1", size=46.0, line_len=110.0, ox=0.0, oy=0.0):
        """Draw filled green section-cut triangle arrow + red label '1' matching Web CAD."""
        if not self.layers.get("DCE_Block", True):
            return
        ax, ay = x + ox, y + oy
        s = float(size)
        ll = float(line_len)
        fs = max(46.0, s * 1.25)
        if direction == "up":
            # Vertical cut stem + upward green triangle + label right/left
            self.line(ax - ll * 0.45, ay, ax + ll * 0.45, ay, CAD["axisGreen"], max(4.0, s * 0.1), "DCE_Block")
            self.polygon([(ax, ay - s), (ax - s * 0.65, ay), (ax + s * 0.65, ay)], stroke=CAD["axisGreen"], fill=CAD["axisGreen"], width=2.0, layer="DCE_Block")
            self.text(ax - s * 1.15, ay - s * 0.1, label, CAD["calloutNum"], fs, "end", "DCE_Block", bold=True)
        elif direction == "down":
            self.line(ax - ll * 0.45, ay, ax + ll * 0.45, ay, CAD["axisGreen"], max(4.0, s * 0.1), "DCE_Block")
            self.polygon([(ax, ay + s), (ax - s * 0.65, ay), (ax + s * 0.65, ay)], stroke=CAD["axisGreen"], fill=CAD["axisGreen"], width=2.0, layer="DCE_Block")
            self.text(ax - s * 1.15, ay + s * 0.65, label, CAD["calloutNum"], fs, "end", "DCE_Block", bold=True)
        elif direction == "right":
            # Vertical cut line + rightward arrow triangle
            self.line(ax, ay - ll * 0.45, ax, ay + ll * 0.45, CAD["axisGreen"], max(4.0, s * 0.1), "DCE_Block")
            self.polygon([(ax + s, ay), (ax, ay - s * 0.65), (ax, ay + s * 0.65)], stroke=CAD["axisGreen"], fill=CAD["axisGreen"], width=2.0, layer="DCE_Block")
            self.text(ax + s * 0.5, ay + s * 1.3, label, CAD["calloutNum"], fs, "middle", "DCE_Block", bold=True)
        else:
            # left
            self.line(ax, ay - ll * 0.45, ax, ay + ll * 0.45, CAD["axisGreen"], max(4.0, s * 0.1), "DCE_Block")
            self.polygon([(ax - s, ay), (ax, ay - s * 0.65), (ax, ay + s * 0.65)], stroke=CAD["axisGreen"], fill=CAD["axisGreen"], width=2.0, layer="DCE_Block")
            self.text(ax - s * 0.5, ay + s * 1.3, label, CAD["calloutNum"], fs, "middle", "DCE_Block", bold=True)

    def elevation_flag(self, x_tip, y_tip, text, scale=25.0, side="left", ox=0.0, oy=0.0):
        if not self.layers.get("DCE_Block", True):
            return
        s = float(scale)
        xt, yt = x_tip + ox, y_tip + oy
        xa = (xt - 4.5 * s) if side == "left" else (xt + 4.5 * s)
        h_tri = 1.6 * s
        w_tri = 1.4 * s
        stem_h = 3.2 * s
        fs = 2.0 * s
        sw = max(2.4, 0.09 * s)
        l_start = (xa - 2.0 * s) if side == "left" else xt
        l_end = xt if side == "left" else (xa + 2.2 * s)
        self.line(l_start, yt, l_end, yt, CAD["hatch"], sw, "DCE_Block")
        self.polygon([(xa, yt), (xa - w_tri, yt - h_tri), (xa, yt - h_tri)], stroke=CAD["hatch"], fill=CAD["hatch"], width=sw, layer="DCE_Block")
        self.polygon([(xa, yt), (xa + w_tri, yt - h_tri), (xa, yt - h_tri)], stroke=CAD["hatch"], fill=None, width=sw, layer="DCE_Block")
        self.line(xa, yt, xa, yt - stem_h, CAD["hatch"], sw, "DCE_Block")
        self.line(xa - 1.5 * s, yt - stem_h, xa + 8.6 * s, yt - stem_h, CAD["hatch"], sw, "DCE_Block")
        self.text(xa + 0.4 * s, yt - stem_h - 0.55 * s, text, CAD["dimText"], fs, "start", "DCE_Block", bold=True)

    def title_block(self, x, y, title, scale_text, font_title=76.0, font_scale=48.0, ox=0.0, oy=0.0):
        if not self.layers.get("DCE_Block", True):
            return
        ax, ay = x + ox, y + oy
        est_w = max(240.0, len(title) * font_title * 0.6)
        self.text(ax, ay, title, CAD["titleText"], font_title, "middle", "DCE_Block", bold=True)
        self.line(ax - est_w / 2.0, ay + font_title * 0.45, ax + est_w / 2.0, ay + font_title * 0.45, CAD["titleText"], max(3.5, font_title * 0.06), "DCE_Block")
        self.text(ax, ay + font_title * 1.15, scale_text, CAD["calloutNum"], font_scale, "middle", "DCE_Block", bold=True)

    def zigzag_v(self, x, y, length, ox=0.0, oy=0.0):
        half = length / 2.0
        zig = 35.0
        pts = [(x + ox, y - half + oy), (x + ox, y - zig + oy), (x - zig + ox, y + oy), (x + zig + ox, y + oy), (x + ox, y + zig + oy), (x + ox, y + half + oy)]
        self.polyline(pts, CAD["zigzag"], 3.5, "DCE_BaoBeTong")

    def zigzag_h(self, x1, x2, y, zig_w=70.0, zig_h=55.0, ox=0.0, oy=0.0):
        mid = (x1 + x2) / 2.0
        pts = [
            (x1 + ox, y + oy),
            (mid - zig_w + ox, y + oy),
            (mid - zig_w / 3.0 + ox, y - zig_h + oy),
            (mid + zig_w / 3.0 + ox, y + zig_h + oy),
            (mid + zig_w + ox, y + oy),
            (x2 + ox, y + oy),
        ]
        self.polyline(pts, CAD["zigzag"], 4.0, "DCE_BaoBeTong")

    def hatch_diagonal(self, x, y, w, h, step=90.0, ox=0.0, oy=0.0):
        if not self.layers.get("DCE_Hatch", True) or w <= 0 or h <= 0:
            return
        step = max(40.0, float(step))
        ax, ay = x + ox, y + oy
        self.rect(ax, ay, w, h, stroke=None, fill="#171B22", width=0.0, layer="DCE_Hatch")
        span = w + h
        d = step * 0.5
        while d < span:
            x1 = ax + max(0.0, d - h)
            y1 = ay + min(h, d)
            x2 = ax + min(w, d)
            y2 = ay + max(0.0, d - w)
            if math.hypot(x2 - x1, y2 - y1) > 4.0:
                self.line(x1, y1, x2, y2, "#2A3240", 1.8, "DCE_Hatch")
            d += step

    def build_result(self):
        if self.min_x == float("inf"):
            return {"bounds": (0.0, 0.0, 1000.0, 1000.0), "primitives": []}
        return {
            "bounds": (self.min_x, self.min_y, self.max_x, self.max_y),
            "primitives": self.prims,
        }


def _poly_svg_pts(poly, ox=0.0, oy=0.0):
    return [(p["x"] + ox, -p["y"] + oy) for p in poly]


# ==================== 1. MÓNG ĐƠN SCENE ====================

def _draw_single_footing(sb, cfg, view_mode="sheet", ox=0.0):
    comp = compute_footing(cfg)
    B = float(cfg["B"])
    L = float(cfg["L"])
    H = float(cfg["H"])
    h_mep = float(cfg["hMep"])
    half_b = B / 2.0
    half_l = L / 2.0
    lean_mb = float(cfg["lotChiaMatBang"])
    lean_mc = float(cfg["lotChiaMatCat"])

    col_cx = comp["colCx"]
    col_cy = -comp["colCy"]
    col_left = col_cx - float(cfg["cotB"]) / 2.0
    col_right = col_cx + float(cfg["cotB"]) / 2.0
    col_top = col_cy - float(cfg["cotH"]) / 2.0
    col_bot = col_cy + float(cfg["cotH"]) / 2.0

    ped_left = comp["pedLeft"]
    ped_right = comp["pedRight"]
    ped_top = -comp["pedTop"]
    ped_bot = -comp["pedBot"]

    top_dim1 = -half_l - lean_mb - 190.0
    top_dim2 = -half_l - lean_mb - 325.0
    bot_dim1 = half_l + lean_mb + 190.0
    bot_dim2 = half_l + lean_mb + 325.0
    left_dim1 = -half_b - lean_mb - 190.0
    left_dim2 = -half_b - lean_mb - 325.0
    right_dim1 = half_b + lean_mb + 190.0
    right_dim2 = half_b + lean_mb + 325.0
    plan_title_y = bot_dim2 + 280.0

    sec_origin_y = 350.0 if view_mode == "section" else (plan_title_y + 2050.0)
    sec_bot_y = sec_origin_y
    sec_mep_y = sec_bot_y - h_mep
    sec_top_y = sec_bot_y - H
    sec_beam_top_y = sec_top_y - float(cfg["caoTuDinhDaiDenMatGiang"])
    sec_beam_bot_y = sec_beam_top_y + float(cfg["giangH"])
    sec_col_top_y = sec_beam_top_y - float(cfg["chieuCaoCotVeThem"])
    lean_bot_y = sec_bot_y + float(cfg["lotDay"])
    sec_title_y = lean_bot_y + 780.0

    frame_left = -half_b - 1080.0
    frame_right = half_b + 1080.0
    frame_top = (sec_col_top_y - 260.0) if view_mode == "section" else (top_dim2 - 220.0)
    frame_bot = (plan_title_y + 240.0) if view_mode == "plan" else (sec_title_y + 220.0)
    sb.rect(ox + frame_left, frame_top, frame_right - frame_left, frame_bot - frame_top, stroke=CAD["frame"], fill=None, width=4.5, layer="DCE_Khung")

    show_plan = view_mode in ("sheet", "plan")
    show_sec = view_mode in ("sheet", "section")

    if show_plan:
        if float(cfg["lotDay"]) > 0 and lean_mb > 0 and sb.layers.get("DCE_Hatch", True):
            if comp["isPolygonal"]:
                lean_poly = offset_polygon(comp["outlinePolygon"], lean_mb)
                sb.polygon(_poly_svg_pts(lean_poly, ox), stroke=CAD["axisGreen"], fill="#171B22", width=3.5, layer="DCE_Hatch")
                sb.polygon(_poly_svg_pts(comp["outlinePolygon"], ox), stroke=None, fill=CAD["bg"], width=0.0, layer="DCE_Hatch")
            else:
                sb.hatch_diagonal(-half_b - lean_mb, -half_l - lean_mb, B + 2 * lean_mb, L + 2 * lean_mb, 90.0, ox)
                sb.rect(ox - half_b - lean_mb, -half_l - lean_mb, B + 2 * lean_mb, L + 2 * lean_mb, stroke=CAD["axisGreen"], fill=None, width=3.5, layer="DCE_Hatch")
                sb.rect(ox - half_b, -half_l, B, L, stroke=None, fill=CAD["bg"], width=0.0, layer="DCE_Hatch")

        if sb.layers.get("DCE_BaoBeTong", True):
            if comp["isPolygonal"]:
                sb.polygon(_poly_svg_pts(comp["outlinePolygon"], ox), stroke=CAD["concrete"], fill=None, width=4.5, layer="DCE_BaoBeTong")
            else:
                sb.rect(ox - half_b, -half_l, B, L, stroke=CAD["concrete"], fill=None, width=4.5, layer="DCE_BaoBeTong")
                # Chamfer slope lines from outer corners to pedestal corners
                sb.line(ox - half_b, -half_l, ox + ped_left, ped_top, CAD["concrete"], 3.2, "DCE_BaoBeTong")
                sb.line(ox + half_b, -half_l, ox + ped_right, ped_top, CAD["concrete"], 3.2, "DCE_BaoBeTong")
                sb.line(ox - half_b, half_l, ox + ped_left, ped_bot, CAD["concrete"], 3.2, "DCE_BaoBeTong")
                sb.line(ox + half_b, half_l, ox + ped_right, ped_bot, CAD["concrete"], 3.2, "DCE_BaoBeTong")
                sb.rect(ox + ped_left, ped_top, ped_right - ped_left, ped_bot - ped_top, stroke=CAD["concrete"], fill=None, width=3.2, layer="DCE_BaoBeTong")

            for col in comp["allColumns"]:
                cl = ox + col["x"] - col["b"] / 2.0
                ct = -col["y"] - col["h"] / 2.0
                sb.rect(cl, ct, col["b"], col["h"], stroke=CAD["colPlanMagenta"], fill=None, width=4.5, layer="DCE_BaoBeTong")
                sb.line(cl, ct, cl + col["b"], ct + col["h"], CAD["colPlanMagenta"], 2.8, "DCE_BaoBeTong")
                sb.line(cl + col["b"], ct, cl, ct + col["h"], CAD["colPlanMagenta"], 2.8, "DCE_BaoBeTong")

        # Plan rebar bars 1 & 2 (with rotated vertical callout for bar 2)
        cover_c = float(cfg["coverCanh"])
        bar1_y = (-half_l + 150.0) if col_bot > half_l - 260 else (half_l - 150.0)
        bar2_x = (-half_b + 180.0) if col_right > half_b - 260 else (half_b - 180.0)
        bar1_s, bar1_e = -half_b + cover_c, half_b - cover_c
        bar2_s, bar2_e = -half_l + cover_c, half_l - cover_c
        if comp["isPolygonal"]:
            inner_p = offset_polygon(comp["outlinePolygon"], -max(25.0, cover_c))
            if len(inner_p) >= 3:
                best_len = -1.0
                for cy_cand in (half_l - 160.0, -half_l + 160.0, half_l * 0.45, -half_l * 0.45, 0.0):
                    for s, e in clip_line_to_poly(inner_p, "x", -cy_cand):
                        if e - s > best_len:
                            best_len = e - s
                            bar1_y, bar1_s, bar1_e = cy_cand, s, e
                best_len2 = -1.0
                for cx_cand in (-half_b + 180.0, half_b - 180.0, -half_b * 0.45, half_b * 0.45, 0.0):
                    for s, e in clip_line_to_poly(inner_p, "y", cx_cand):
                        if e - s > best_len2:
                            best_len2 = e - s
                            bar2_x, bar2_s, bar2_e = cx_cand, -e, -s

        if sb.layers.get("DCE_ThepChu", True):
            sb.line(ox + bar1_s, bar1_y, ox + bar1_e, bar1_y, CAD["rebar"], 6.0, "DCE_ThepChu")
            sb.line(ox + bar2_x, bar2_s, ox + bar2_x, bar2_e, CAD["rebar"], 6.0, "DCE_ThepChu")
            bx = cfg["thepPhuongX"]
            by = cfg["thepPhuongY"]
            b1_cx = (bar1_s + bar1_e) / 2.0 - 160.0
            sb.callout(b1_cx, bar1_y - 115.0, "1", "Ø%da%d" % (bx["d"], bx["a"]),
                       [(b1_cx, bar1_y - 59.0), (b1_cx, bar1_y)], "right", ox=ox)
            b2_cy = (bar2_s + bar2_e) / 2.0 + 120.0
            sb.callout(bar2_x - 135.0, b2_cy, "2", "Ø%da%d" % (by["d"], by["a"]),
                       [(bar2_x - 80.0, b2_cy), (bar2_x, b2_cy)], "right", ox=ox, rotate=-90.0)

        # Green filled section cut triangles 1 - 1 on left & right of plan
        sb.section_marker(-half_b - lean_mb - 460.0, 0.0, "up", "1", size=48.0, line_len=110.0, ox=ox)
        sb.section_marker(half_b + lean_mb + 460.0, 0.0, "up", "1", size=48.0, line_len=110.0, ox=ox)

        # Full 4-side Plan Dimension Chains
        sb.dim_h(ox - half_b, ox + half_b, top_dim2, -half_l, str(int(round(B))), text_above=True)
        if comp["dxLeft"] > 0:
            sb.dim_h(ox - half_b, ox + col_left, top_dim1, -half_l, str(comp["dxLeft"]), text_above=True)
        sb.dim_h(ox + col_left, ox + col_right, top_dim1, -half_l, str(int(round(cfg["cotB"]))), text_above=True)
        if comp["dxRight"] > 0:
            sb.dim_h(ox + col_right, ox + half_b, top_dim1, -half_l, str(comp["dxRight"]), text_above=True)

        # Bottom Plan Dimensions matching Web screenshot
        if comp["dxLeft"] > 0:
            sb.dim_h(ox - half_b, ox + col_left, bot_dim1, half_l, str(comp["dxLeft"]), text_above=False)
        sb.dim_h(ox + col_left, ox + col_right, bot_dim1, half_l, str(int(round(cfg["cotB"]))), text_above=False)
        if comp["dxRight"] > 0:
            sb.dim_h(ox + col_right, ox + half_b, bot_dim1, half_l, str(comp["dxRight"]), text_above=False)
        sb.dim_h(ox - half_b, ox + half_b, bot_dim2, half_l, str(int(round(B))), text_above=False)

        # Left & Right Vertical Plan Dimensions
        sb.dim_v(-half_l, half_l, ox + left_dim2, -half_b, str(int(round(L))), text_side="left")
        if comp["dyTop"] > 0:
            sb.dim_v(-half_l, col_top, ox + left_dim1, -half_b, str(comp["dyTop"]), text_side="left")
        sb.dim_v(col_top, col_bot, ox + left_dim1, -half_b, str(int(round(cfg["cotH"]))), text_side="left")
        if comp["dyBot"] > 0:
            sb.dim_v(col_bot, half_l, ox + left_dim1, -half_b, str(comp["dyBot"]), text_side="left")

        if comp["dyTop"] > 0:
            sb.dim_v(-half_l, col_top, ox + right_dim1, half_b, str(comp["dyTop"]), text_side="right")
        sb.dim_v(col_top, col_bot, ox + right_dim1, half_b, str(int(round(cfg["cotH"]))), text_side="right")
        if comp["dyBot"] > 0:
            sb.dim_v(col_bot, half_l, ox + right_dim1, half_b, str(comp["dyBot"]), text_side="right")
        sb.dim_v(-half_l, half_l, ox + right_dim2, half_b, str(int(round(L))), text_side="right")

        sub_parts = []
        if comp["isPolygonal"]:
            sub_parts.append("%d ĐỈNH" % len(comp["outlinePolygon"]))
        if cfg.get("gocXoay") and abs(float(cfg["gocXoay"])) > 1:
            sub_parts.append("%g°" % cfg["gocXoay"])
        title_str = "MÓNG %s (SL=%d)" % (cfg["ten"], cfg["soLuong"])
        if sub_parts:
            title_str += " · " + " · ".join(sub_parts)
        sb.title_block(0, plan_title_y, title_str, "TL: 1/%d · S=%.2fm²" % (cfg["tiLe"], comp["dienTichM2"]), ox=ox)

    if show_sec:
        # Lean concrete in section
        if float(cfg["lotDay"]) > 0:
            lw = B + 2 * lean_mc
            if sb.layers.get("DCE_Hatch", True):
                sb.hatch_diagonal(-half_b - lean_mc, sec_bot_y, lw, float(cfg["lotDay"]), 75.0, ox)
            if sb.layers.get("DCE_BaoBeTong", True):
                sb.rect(ox - half_b - lean_mc, sec_bot_y, lw, float(cfg["lotDay"]), stroke=CAD["concrete"], fill=None, width=4.0, layer="DCE_BaoBeTong")

        # Footing Trapezoid + Column + Tie Beams
        if sb.layers.get("DCE_BaoBeTong", True):
            foot_pts = [
                (ox - half_b, sec_bot_y),
                (ox + half_b, sec_bot_y),
                (ox + half_b, sec_mep_y),
                (ox + ped_right, sec_top_y),
                (ox + col_right, sec_top_y),
                (ox + col_right, sec_col_top_y),
                (ox + col_left, sec_col_top_y),
                (ox + col_left, sec_top_y),
                (ox + ped_left, sec_top_y),
                (ox - half_b, sec_mep_y),
            ]
            sb.polygon(foot_pts, stroke=CAD["concrete"], fill=None, width=4.5, layer="DCE_BaoBeTong")

            show_left_b = cfg["giangMode"] in ("both", "left")
            show_right_b = cfg["giangMode"] in ("both", "right")
            stub = 820.0
            if show_left_b:
                sb.line(ox + col_left - stub, sec_beam_top_y, ox + col_left, sec_beam_top_y, CAD["concrete"], 4.0, "DCE_BaoBeTong")
                sb.line(ox + col_left - stub, sec_beam_bot_y, ox + col_left, sec_beam_bot_y, CAD["concrete"], 4.0, "DCE_BaoBeTong")
                sb.zigzag_v(col_left - stub, (sec_beam_top_y + sec_beam_bot_y) / 2.0, float(cfg["giangH"]) + 80.0, ox)
            if show_right_b:
                sb.line(ox + col_right, sec_beam_top_y, ox + col_right + stub, sec_beam_top_y, CAD["concrete"], 4.0, "DCE_BaoBeTong")
                sb.line(ox + col_right, sec_beam_bot_y, ox + col_right + stub, sec_beam_bot_y, CAD["concrete"], 4.0, "DCE_BaoBeTong")
                sb.zigzag_v(col_right + stub, (sec_beam_top_y + sec_beam_bot_y) / 2.0, float(cfg["giangH"]) + 80.0, ox)
            sb.zigzag_h(col_left - 60, col_right + 60, sec_col_top_y, 50.0, 35.0, ox)

        # Rebar in section
        rebar_bot_y = sec_bot_y - float(cfg["coverDay"])
        rebar_l_x = -half_b + float(cfg["coverCanh"])
        rebar_r_x = half_b - float(cfg["coverCanh"])
        dot_r = max(8.0, float(cfg["thepPhuongY"]["d"]) / 2.0 + 2.5)
        dot_y = rebar_bot_y - dot_r
        dot_count = min(28, max(2, comp["soThanhY"]))
        dots_x = [
            ((rebar_l_x + dot_r) + (rebar_r_x - rebar_l_x - 2 * dot_r) * i / float(dot_count - 1))
            for i in range(dot_count)
        ]

        if sb.layers.get("DCE_ThepChu", True):
            bx = cfg["thepPhuongX"]
            if bx.get("hasHook"):
                hk = min(float(bx.get("hookLen", 150)), H - 80.0)
                sb.polyline([
                    (ox + rebar_l_x, rebar_bot_y - hk),
                    (ox + rebar_l_x, rebar_bot_y),
                    (ox + rebar_r_x, rebar_bot_y),
                    (ox + rebar_r_x, rebar_bot_y - hk),
                ], CAD["rebar"], 6.5, "DCE_ThepChu")
            else:
                sb.line(ox + rebar_l_x, rebar_bot_y, ox + rebar_r_x, rebar_bot_y, CAD["rebar"], 6.5, "DCE_ThepChu")

            for dx in dots_x:
                sb.circle(ox + dx, dot_y, dot_r, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")

            # Column starter dowels
            d_ins = min(40.0, max(20.0, float(cfg["cotB"]) * 0.18))
            dl_x = col_left + d_ins
            dr_x = col_right - d_ins
            d_foot_y = rebar_bot_y - 30.0
            sb.polyline([
                (ox + dl_x - float(cfg["thepCotChanL"]), d_foot_y),
                (ox + dl_x, d_foot_y),
                (ox + dl_x, sec_col_top_y + 40.0),
            ], CAD["rebar"], 6.0, "DCE_ThepChu")
            sb.polyline([
                (ox + dr_x + float(cfg["thepCotChanL"]), d_foot_y),
                (ox + dr_x, d_foot_y),
                (ox + dr_x, sec_col_top_y + 40.0),
            ], CAD["rebar"], 6.0, "DCE_ThepChu")

            if sb.layers.get("DCE_ThepDai", True):
                sy = d_foot_y - 50.0
                step_a = max(80.0, float(cfg["thepDaiA"]))
                while sy >= sec_col_top_y + 20.0:
                    sb.line(ox + dl_x, sy, ox + dr_x, sy, CAD["stirrup"], 4.5, "DCE_ThepDai")
                    sy -= step_a

            by = cfg["thepPhuongY"]
            sb.callout(-half_b + 300.0, lean_bot_y + 160.0, "2", "Ø%da%d" % (by["d"], by["a"]),
                       [(-half_b + 354.0, lean_bot_y + 160.0), (dots_x[2 if len(dots_x) > 2 else 0], lean_bot_y + 160.0), (dots_x[2 if len(dots_x) > 2 else 0], dot_y)], "right", ox=ox)
            sb.callout(half_b - 300.0, lean_bot_y + 160.0, "1", "Ø%da%d" % (bx["d"], bx["a"]),
                       [(half_b - 354.0, lean_bot_y + 160.0), (rebar_r_x - 160.0, lean_bot_y + 160.0), (rebar_r_x - 160.0, rebar_bot_y)], "left", ox=ox)

        # Elevation flags (bottom footing & tie beam top on left)
        sb.elevation_flag(-half_b - 200.0, sec_bot_y, format_elevation(cfg["caoTrinhDay"]), scale=float(cfg["tiLe"]), side="left", ox=ox)
        if cfg["giangMode"] != "none":
            sb.elevation_flag(col_left - 820.0, sec_beam_top_y, format_elevation(comp["caoTrinhMatGiang"]), scale=float(cfg["tiLe"]), side="left", ox=ox)

        # Vertical dims: left neck->beam (650), H (400), lotDay (100); right h_mep (200)
        if float(cfg["caoTuDinhDaiDenMatGiang"]) > 0 and cfg["giangMode"] != "none":
            sb.dim_v(sec_beam_top_y, sec_top_y, ox - half_b - 220.0, -half_b, str(int(round(cfg["caoTuDinhDaiDenMatGiang"]))), text_side="left")
        sb.dim_v(sec_top_y, sec_bot_y, ox - half_b - 220.0, -half_b, str(int(round(H))), text_side="left")
        if float(cfg["lotDay"]) > 0:
            sb.dim_v(sec_bot_y, lean_bot_y, ox - half_b - 220.0, -half_b - lean_mc, str(int(round(cfg["lotDay"]))), text_side="left")
        sb.dim_v(sec_mep_y, sec_bot_y, ox + half_b + 180.0, half_b, str(int(round(h_mep))), text_side="right")

        # Bottom MC 1-1 dim chains matching Web: leanMC | left->col | col->right | leanMC & B
        mc_dim1 = lean_bot_y + 300.0
        mc_dim2 = lean_bot_y + 440.0
        if lean_mc > 0:
            sb.dim_h(ox - half_b - lean_mc, ox - half_b, mc_dim1, lean_bot_y, str(int(round(lean_mc))), text_above=False)
        sb.dim_h(ox - half_b, ox + col_cx, mc_dim1, lean_bot_y, str(int(round(col_cx - (-half_b)))), text_above=False)
        sb.dim_h(ox + col_cx, ox + half_b, mc_dim1, lean_bot_y, str(int(round(half_b - col_cx))), text_above=False)
        if lean_mc > 0:
            sb.dim_h(ox + half_b, ox + half_b + lean_mc, mc_dim1, lean_bot_y, str(int(round(lean_mc))), text_above=False)
        sb.dim_h(ox - half_b, ox + half_b, mc_dim2, lean_bot_y, str(int(round(B))), text_above=False)

        sb.title_block(0, sec_title_y, "MC 1-1 (%s)" % cfg["ten"], "TL: 1/%d · KL=%.1f kg" % (cfg["tiLe"], comp["khoiLuongThepDay1Mong"]), ox=ox)


# ==================== 2. MÓNG CỌC SCENE ====================

def _draw_pile_cap(sb, cfg, view_mode="sheet", ox=0.0):
    comp = compute_pile_cap(cfg)
    B = float(cfg["B"])
    L = float(cfg["L"])
    H = float(cfg["H"])
    half_b = B / 2.0
    half_l = L / 2.0
    lean_mb = float(cfg["lotChiaMatBang"])
    lean_mc = float(cfg["lotChiaMatCat"])

    col_cx = comp["colCx"]
    col_cy = -comp["colCy"]
    col_left = col_cx - float(cfg["cotB"]) / 2.0
    col_right = col_cx + float(cfg["cotB"]) / 2.0
    col_top = col_cy - float(cfg["cotH"]) / 2.0
    col_bot = col_cy + float(cfg["cotH"]) / 2.0

    top_dim1 = -half_l - lean_mb - 190.0
    top_dim2 = -half_l - lean_mb - 320.0
    bot_dim1 = half_l + lean_mb + 190.0
    bot_dim2 = half_l + lean_mb + 320.0
    left_dim1 = -half_b - lean_mb - 190.0
    left_dim2 = -half_b - lean_mb - 320.0
    right_dim1 = half_b + lean_mb + 190.0
    right_dim2 = half_b + lean_mb + 320.0
    plan_title_y = bot_dim2 + 275.0

    sec_origin_y = 350.0 if view_mode == "section" else (plan_title_y + 1950.0)
    sec_bot_y = sec_origin_y
    sec_top_y = sec_bot_y - H
    sec_col_top_y = sec_top_y - float(cfg["chieuCaoCotVeThem"])
    lean_bot_y = sec_bot_y + float(cfg["lotDay"])
    pile_bot_y = lean_bot_y + float(cfg["cocVeThem"])
    pile_head_y = sec_bot_y - float(cfg["ngamCoc"])
    sec_title_y = lean_bot_y + 740.0

    frame_left = -half_b - 1180.0
    frame_right = half_b + 1080.0
    frame_top = (sec_col_top_y - 350.0) if view_mode == "section" else (top_dim2 - 220.0)
    frame_bot = (plan_title_y + 220.0) if view_mode == "plan" else (sec_title_y + 220.0)
    sb.rect(ox + frame_left, frame_top, frame_right - frame_left, frame_bot - frame_top, stroke=CAD["frame"], fill=None, width=4.5, layer="DCE_Khung")

    unique_xs = []
    for x in sorted(p["x"] for p in comp["piles"]):
        if not unique_xs or abs(x - unique_xs[-1]) >= 25:
            unique_xs.append(x)
    unique_ys = []
    for y in sorted(-p["y"] for p in comp["piles"]):
        if not unique_ys or abs(y - unique_ys[-1]) >= 25:
            unique_ys.append(y)

    # Flush top rule for lean concrete in ĐM4 (when col is top_flush, lean top edge = 0)
    lean_top_ext = 0.0 if cfg.get("viTriCotMode") == "top_flush" else lean_mb

    if view_mode in ("sheet", "plan"):
        if float(cfg["lotDay"]) > 0 and lean_mb > 0 and sb.layers.get("DCE_Hatch", True):
            if comp["isPolygonal"]:
                lean_p = offset_polygon(comp["outlinePolygon"], lean_mb)
                sb.polygon(_poly_svg_pts(lean_p, ox), stroke=CAD["axisGreen"], fill="#171B22", width=3.5, layer="DCE_Hatch")
                sb.polygon(_poly_svg_pts(comp["outlinePolygon"], ox), stroke=None, fill=CAD["bg"], width=0.0, layer="DCE_Hatch")
            else:
                sb.hatch_diagonal(-half_b - lean_mb, -half_l - lean_top_ext, B + 2 * lean_mb, L + lean_top_ext + lean_mb, 90.0, ox)
                sb.rect(ox - half_b - lean_mb, -half_l - lean_top_ext, B + 2 * lean_mb, L + lean_top_ext + lean_mb, stroke=CAD["axisGreen"], fill=None, width=3.5, layer="DCE_Hatch")
                sb.rect(ox - half_b, -half_l, B, L, stroke=None, fill=CAD["bg"], width=0.0, layer="DCE_Hatch")

        if sb.layers.get("DCE_BaoBeTong", True):
            if comp["isPolygonal"]:
                sb.polygon(_poly_svg_pts(comp["outlinePolygon"], ox), stroke=CAD["capPlanEdge"], fill=None, width=4.5, layer="DCE_BaoBeTong")
            else:
                sb.rect(ox - half_b, -half_l, B, L, stroke=CAD["capPlanEdge"], fill=None, width=4.5, layer="DCE_BaoBeTong")
            for col in comp["allColumns"]:
                cl = ox + col["x"] - col["b"] / 2.0
                ct = -col["y"] - col["h"] / 2.0
                sb.rect(cl, ct, col["b"], col["h"], stroke=CAD["colPlanMagenta"], fill=None, width=4.5, layer="DCE_BaoBeTong")
                sb.line(cl, ct, cl + col["b"], ct + col["h"], CAD["colPlanMagenta"], 2.8, "DCE_BaoBeTong")
                sb.line(cl + col["b"], ct, cl, ct + col["h"], CAD["colPlanMagenta"], 2.8, "DCE_BaoBeTong")

        if sb.layers.get("DCE_Block", True):
            for pile in comp["piles"]:
                px, py = ox + pile["x"], -pile["y"]
                pd = float(pile.get("d") or cfg["cocD"])
                r = pd / 2.0
                ext = round(pd * 0.36)
                if cfg["cocHinh"] == "square":
                    sb.rect(px - r, py - r, pd, pd, stroke=CAD["pileYellow"], fill=None, width=4.0, layer="DCE_Block")
                else:
                    sb.circle(px, py, r, stroke=CAD["pileYellow"], fill=None, width=4.0, layer="DCE_Block")
                sb.line(px - r - ext, py, px + r + ext, py, CAD["pileYellow"], 2.8, "DCE_Block")
                sb.line(px, py - r - ext, px, py + r + ext, CAD["pileYellow"], 2.8, "DCE_Block")

        if sb.layers.get("DCE_ThepChu", True):
            bar_c = max(45.0, float(cfg["coverCanh"]))
            top_y, bot_y = -half_l + bar_c + 25.0, half_l - bar_c - 25.0
            left_x, right_x = -half_b + bar_c + 25.0, half_b - bar_c - 25.0
            hk = min(180.0, min(B, L) * 0.14)
            # Horizontal top T1 & bottom B1 bars with hooks
            sb.polyline([(ox + left_x + 25, top_y + hk), (ox + left_x + 25, top_y), (ox + right_x - 25, top_y), (ox + right_x - 25, top_y + hk)], CAD["rebar"], 6.0, "DCE_ThepChu")
            sb.polyline([(ox + left_x + 25, bot_y - hk), (ox + left_x + 25, bot_y), (ox + right_x - 25, bot_y), (ox + right_x - 25, bot_y - hk)], CAD["rebar"], 6.0, "DCE_ThepChu")
            # Vertical left T2 & right B2 bars with hooks
            sb.polyline([(ox + left_x + hk, top_y + 25), (ox + left_x, top_y + 25), (ox + left_x, bot_y - 25), (ox + left_x + hk, bot_y - 25)], CAD["rebar"], 6.0, "DCE_ThepChu")
            sb.polyline([(ox + right_x - hk, top_y + 25), (ox + right_x, top_y + 25), (ox + right_x, bot_y - 25), (ox + right_x - hk, bot_y - 25)], CAD["rebar"], 6.0, "DCE_ThepChu")

            sb.callout(-60, top_y + 115, "T1", "Ø%da%d" % (cfg["thepTrenX"]["d"], cfg["thepTrenX"]["a"]),
                       [(-60, top_y + 60), (-60, top_y)], "right", ox=ox)
            sb.callout(-60, bot_y - 115, "B1", "Ø%da%d" % (cfg["thepDuoiX"]["d"], cfg["thepDuoiX"]["a"]),
                       [(-60, bot_y - 60), (-60, bot_y)], "right", ox=ox)
            sb.callout(left_x + 120, 40.0, "T2", "Ø%da%d" % (cfg["thepTrenY"]["d"], cfg["thepTrenY"]["a"]),
                       [(left_x + 65, 40.0), (left_x, 40.0)], "right", ox=ox, rotate=-90.0)
            sb.callout(right_x - 120, 40.0, "B2", "Ø%da%d" % (cfg["thepDuoiY"]["d"], cfg["thepDuoiY"]["a"]),
                       [(right_x - 65, 40.0), (right_x, 40.0)], "right", ox=ox, rotate=-90.0)

        # Green filled section markers 1 - 1
        sb.section_marker(-half_b - lean_mb - 480.0, 0.0, "up", "1", size=48.0, line_len=110.0, ox=ox)
        sb.section_marker(half_b + lean_mb + 480.0, 0.0, "up", "1", size=48.0, line_len=110.0, ox=ox)

        # Top Plan Dims: lean | dxLeft | cotB | dxRight | lean & B
        if lean_mb > 0:
            sb.dim_h(ox - half_b - lean_mb, ox - half_b, top_dim1, -half_l - lean_top_ext, str(int(round(lean_mb))), text_above=True)
        if comp["dxLeft"] > 0:
            sb.dim_h(ox - half_b, ox + col_left, top_dim1, -half_l, str(comp["dxLeft"]), text_above=True)
        sb.dim_h(ox + col_left, ox + col_right, top_dim1, -half_l, str(int(round(cfg["cotB"]))), text_above=True)
        if comp["dxRight"] > 0:
            sb.dim_h(ox + col_right, ox + half_b, top_dim1, -half_l, str(comp["dxRight"]), text_above=True)
        if lean_mb > 0:
            sb.dim_h(ox + half_b, ox + half_b + lean_mb, top_dim1, -half_l - lean_top_ext, str(int(round(lean_mb))), text_above=True)
        sb.dim_h(ox - half_b, ox + half_b, top_dim2, -half_l, str(int(round(B))), text_above=True)

        # Bottom Plan Dims: lean | edge | pileSpacings | edge | lean & B
        if lean_mb > 0:
            sb.dim_h(ox - half_b - lean_mb, ox - half_b, bot_dim1, half_l + lean_mb, str(int(round(lean_mb))), text_above=False)
        if unique_xs:
            sb.dim_h(ox - half_b, ox + unique_xs[0], bot_dim1, half_l, str(int(round(unique_xs[0] - (-half_b)))), text_above=False)
            for k in range(len(unique_xs) - 1):
                sb.dim_h(ox + unique_xs[k], ox + unique_xs[k + 1], bot_dim1, half_l, str(int(round(unique_xs[k + 1] - unique_xs[k]))), text_above=False)
            sb.dim_h(ox + unique_xs[-1], ox + half_b, bot_dim1, half_l, str(int(round(half_b - unique_xs[-1]))), text_above=False)
        if lean_mb > 0:
            sb.dim_h(ox + half_b, ox + half_b + lean_mb, bot_dim1, half_l + lean_mb, str(int(round(lean_mb))), text_above=False)
        sb.dim_h(ox - half_b, ox + half_b, bot_dim2, half_l, str(int(round(B))), text_above=False)

        # Left & Right Vertical Plan Dims: lean | pileY | lean & L_lean
        if unique_ys:
            if lean_top_ext > 0:
                sb.dim_v(-half_l - lean_top_ext, -half_l, ox + left_dim1, -half_b - lean_mb, str(int(round(lean_top_ext))), text_side="left")
            sb.dim_v(-half_l, unique_ys[0], ox + left_dim1, -half_b, str(int(round(unique_ys[0] - (-half_l)))), text_side="left")
            for k in range(len(unique_ys) - 1):
                sb.dim_v(unique_ys[k], unique_ys[k + 1], ox + left_dim1, -half_b, str(int(round(unique_ys[k + 1] - unique_ys[k]))), text_side="left")
            sb.dim_v(unique_ys[-1], half_l, ox + left_dim1, -half_b, str(int(round(half_l - unique_ys[-1]))), text_side="left")
            if lean_mb > 0:
                sb.dim_v(half_l, half_l + lean_mb, ox + left_dim1, -half_b - lean_mb, str(int(round(lean_mb))), text_side="left")
        sb.dim_v(-half_l - lean_top_ext, half_l + lean_mb, ox + left_dim2, -half_b - lean_mb, str(int(round(L + lean_top_ext + lean_mb))), text_side="left")

        if unique_ys:
            sb.dim_v(-half_l, unique_ys[0], ox + right_dim1, half_b, str(int(round(unique_ys[0] - (-half_l)))), text_side="right")
            for k in range(len(unique_ys) - 1):
                sb.dim_v(unique_ys[k], unique_ys[k + 1], ox + right_dim1, half_b, str(int(round(unique_ys[k + 1] - unique_ys[k]))), text_side="right")
            sb.dim_v(unique_ys[-1], half_l, ox + right_dim1, half_b, str(int(round(half_l - unique_ys[-1]))), text_side="right")
            if lean_mb > 0:
                sb.dim_v(half_l, half_l + lean_mb, ox + right_dim1, half_b + lean_mb, str(int(round(lean_mb))), text_side="right")
        sb.dim_v(-half_l - lean_top_ext, half_l + lean_mb, ox + right_dim2, half_b + lean_mb, str(int(round(L + lean_top_ext + lean_mb))), text_side="right")

        sb.title_block(0, plan_title_y, "MÓNG %s (SL=%d)" % (cfg["ten"], cfg["soLuong"]),
                       "TL: 1/%d · %d CỌC Ø%d" % (cfg["tiLe"], comp["tongSoCoc"], cfg["cocD"]), ox=ox)

    if view_mode in ("sheet", "section"):
        # Pile shafts + V-flared starter dowels
        coc_d = float(cfg["cocD"])
        for px in unique_xs:
            pl, pr = ox + px - coc_d / 2.0, ox + px + coc_d / 2.0
            if sb.layers.get("DCE_BaoBeTong", True):
                sb.line(pl, pile_head_y, pl, pile_bot_y, CAD["concrete"], 4.0, "DCE_BaoBeTong")
                sb.line(pr, pile_head_y, pr, pile_bot_y, CAD["concrete"], 4.0, "DCE_BaoBeTong")
                sb.line(pl, pile_head_y, pr, pile_head_y, CAD["concrete"], 3.5, "DCE_BaoBeTong")
                sb.zigzag_h(px - coc_d / 2.0 - 40, px + coc_d / 2.0 + 40, pile_bot_y, 45.0, 30.0, ox)
            if sb.layers.get("DCE_ThepChu", True):
                rau_top = pile_head_y - float(cfg["rauCocCao"])
                flare = max(55.0, coc_d * 0.42)
                # V-shaped flared rebar anchors into cap
                sb.polyline([(pl + 32, pile_bot_y), (pl + 32, pile_head_y), (pl + 32 - flare, rau_top)], CAD["rebar"], 5.0, "DCE_ThepChu")
                sb.polyline([(pr - 32, pile_bot_y), (pr - 32, pile_head_y), (pr - 32 + flare, rau_top)], CAD["rebar"], 5.0, "DCE_ThepChu")

        if sb.layers.get("DCE_BaoBeTong", True):
            sb.rect(ox - half_b, sec_top_y, B, H, stroke=CAD["concrete"], fill=None, width=4.5, layer="DCE_BaoBeTong")
            sb.line(ox + col_left, sec_top_y, ox + col_left, sec_col_top_y, CAD["concrete"], 4.5, "DCE_BaoBeTong")
            sb.line(ox + col_right, sec_top_y, ox + col_right, sec_col_top_y, CAD["concrete"], 4.5, "DCE_BaoBeTong")
            sb.zigzag_h(col_left - 55, col_right + 55, sec_col_top_y, 50.0, 30.0, ox)

        # Lean concrete segmented cleanly around pile shafts (never overlaps pile shafts!)
        if float(cfg["lotDay"]) > 0:
            intervals = []
            cur_s = -half_b - lean_mc
            end_x = half_b + lean_mc
            for px in unique_xs:
                p_l = px - coc_d / 2.0
                p_r = px + coc_d / 2.0
                if p_l > cur_s + 5.0:
                    intervals.append((cur_s, p_l))
                cur_s = max(cur_s, p_r)
            if end_x > cur_s + 5.0:
                intervals.append((cur_s, end_x))
            for is_x, ie_x in intervals:
                if sb.layers.get("DCE_Hatch", True):
                    sb.hatch_diagonal(is_x, sec_bot_y, ie_x - is_x, float(cfg["lotDay"]), 70.0, ox)
                if sb.layers.get("DCE_BaoBeTong", True):
                    sb.rect(ox + is_x, sec_bot_y, ie_x - is_x, float(cfg["lotDay"]), stroke=CAD["concrete"], fill=None, width=3.5, layer="DCE_BaoBeTong")

        # Rebar cage + column starter dowels + side belt skin bars (2)
        r_l = -half_b + float(cfg["coverCanh"])
        r_r = half_b - float(cfg["coverCanh"])
        r_b = sec_bot_y - float(cfg["coverDay"])
        r_t = sec_top_y + float(cfg["coverTren"])
        moc_top = max(r_t + 60.0, r_b - float(cfg["mocDuoiLen"]))
        if sb.layers.get("DCE_ThepChu", True):
            sb.polyline([(ox + r_l, moc_top), (ox + r_l, r_b), (ox + r_r, r_b), (ox + r_r, moc_top)], CAD["rebar"], 6.5, "DCE_ThepChu")
            sb.polyline([(ox + r_l + 26, r_b - 60), (ox + r_l + 26, r_t), (ox + r_r - 26, r_t), (ox + r_r - 26, r_b - 60)], CAD["rebar"], 6.5, "DCE_ThepChu")

            # Column starter L-dowels + stirrups inside cap & starter neck
            d_ins = min(40.0, max(20.0, float(cfg["cotB"]) * 0.16))
            dl_x = col_left + d_ins
            dr_x = col_right - d_ins
            d_foot_y = r_b - 28.0
            chan_l = float(cfg.get("thepCotChanL", 300))
            sb.polyline([(ox + dl_x - chan_l, d_foot_y), (ox + dl_x, d_foot_y), (ox + dl_x, sec_col_top_y + 40.0)], CAD["rebar"], 6.0, "DCE_ThepChu")
            sb.polyline([(ox + dr_x + chan_l, d_foot_y), (ox + dr_x, d_foot_y), (ox + dr_x, sec_col_top_y + 40.0)], CAD["rebar"], 6.0, "DCE_ThepChu")
            if sb.layers.get("DCE_ThepDai", True):
                sy = d_foot_y - 50.0
                step_a = max(90.0, float(cfg.get("thepDaiA", 200)))
                while sy >= sec_col_top_y + 20.0:
                    sb.line(ox + dl_x, sy, ox + dr_x, sy, CAD["stirrup"], 4.5, "DCE_ThepDai")
                    sy -= step_a

            # Bottom & top dots (B2, T2)
            nb2 = max(2, min(28, comp["soThanhB2"]))
            for i in range(nb2):
                dx = r_l + 28 + (r_r - r_l - 56) * i / float(nb2 - 1)
                sb.circle(ox + dx, r_b - 11.0, 9.0, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")
            nt2 = max(2, min(28, comp["soThanhT2"]))
            for i in range(nt2):
                dx = r_l + 54 + (r_r - r_l - 108) * i / float(nt2 - 1)
                sb.circle(ox + dx, r_t + 11.0, 9.0, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")

            # Side belt / skin bars (2) at mid-depth on left & right walls
            n_vach = max(1, min(6, int(cfg.get("soTangThepVach", 3))))
            v_top_y = r_t + 160.0
            v_bot_y = r_b - 160.0
            v_last_y = (v_top_y + v_bot_y) / 2.0
            for vi in range(n_vach):
                vy = (v_top_y + v_bot_y) / 2.0 if n_vach == 1 else (v_top_y + (v_bot_y - v_top_y) * vi / float(n_vach - 1))
                v_last_y = vy
                sb.circle(ox + r_l + 42.0, vy, 9.0, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")
                sb.circle(ox + r_r - 42.0, vy, 9.0, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")

            # Callouts T2, T1, 2, B2, B1
            sb.callout(-half_b - 250, sec_top_y - 125, "T2", "Ø%da%d" % (cfg["thepTrenY"]["d"], cfg["thepTrenY"]["a"]),
                       [(-half_b - 196, sec_top_y - 125), (r_l + 54, sec_top_y - 125), (r_l + 54, r_t + 11)], "left", ox=ox)
            sb.callout(half_b + 380, sec_top_y - 125, "T1", "Ø%da%d" % (cfg["thepTrenX"]["d"], cfg["thepTrenX"]["a"]),
                       [(half_b + 326, sec_top_y - 125), (r_r - 120, sec_top_y - 125), (r_r - 120, r_t)], "right", ox=ox)
            vach_cfg = cfg.get("thepVach") or {"d": 12, "a": 200}
            sb.callout(half_b + 380, v_last_y, "2", "Ø%da%d" % (vach_cfg["d"], vach_cfg["a"]),
                       [(half_b + 326, v_last_y), (r_r - 42.0, v_last_y)], "right", ox=ox)
            sb.callout(-half_b - 250, lean_bot_y + 150, "B2", "Ø%da%d" % (cfg["thepDuoiY"]["d"], cfg["thepDuoiY"]["a"]),
                       [(-half_b - 196, lean_bot_y + 150), (r_l + 28, lean_bot_y + 150), (r_l + 28, r_b - 11)], "left", ox=ox)
            sb.callout(half_b + 380, lean_bot_y + 150, "B1", "Ø%da%d" % (cfg["thepDuoiX"]["d"], cfg["thepDuoiX"]["a"]),
                       [(half_b + 326, lean_bot_y + 150), (r_r - 120, lean_bot_y + 150), (r_r - 120, r_b)], "right", ox=ox)

        # Elevation flag on left cap surface
        sb.elevation_flag(-half_b - 180, sec_top_y, format_elevation(cfg["caoTrinhMatDai"]), scale=float(cfg["tiLe"]), side="left", ox=ox)

        # Inner vertical hook dims (mocDuoiLen = 360) left & right
        sb.dim_v(moc_top, r_b, ox + r_l + 155, r_l, str(int(round(cfg["mocDuoiLen"]))), text_side="left")
        sb.dim_v(moc_top, r_b, ox + r_r - 155, r_r, str(int(round(cfg["mocDuoiLen"]))), text_side="right")

        # Section left vertical dims (H, coverDay, lotDay)
        sb.dim_v(sec_top_y, sec_bot_y, ox - half_b - 220, -half_b, str(int(round(H))), text_side="left")
        sb.dim_v(r_b, sec_bot_y, ox - half_b - 110, -half_b, str(int(round(cfg["coverDay"]))), text_side="left")
        sb.dim_v(sec_bot_y, lean_bot_y, ox - half_b - 110, -half_b - lean_mc, str(int(round(cfg["lotDay"]))), text_side="left")

        # Section Top & Bottom Dims
        if comp["dxLeft"] > 0:
            sb.dim_h(ox - half_b, ox + col_left, sec_top_y - 240, sec_top_y, str(comp["dxLeft"]), text_above=True)
        sb.dim_h(ox + col_left, ox + col_right, sec_top_y - 240, sec_top_y, str(int(round(cfg["cotB"]))), text_above=True)
        if comp["dxRight"] > 0:
            sb.dim_h(ox + col_right, ox + half_b, sec_top_y - 240, sec_top_y, str(comp["dxRight"]), text_above=True)

        mc_bot1 = lean_bot_y + 220.0
        mc_bot2 = lean_bot_y + 360.0
        if lean_mc > 0:
            sb.dim_h(ox - half_b - lean_mc, ox - half_b, mc_bot1, lean_bot_y, str(int(round(lean_mc))), text_above=False)
        if unique_xs:
            sb.dim_h(ox - half_b, ox + unique_xs[0], mc_bot1, sec_bot_y, str(int(round(unique_xs[0] - (-half_b)))), text_above=False)
            for k in range(len(unique_xs) - 1):
                sb.dim_h(ox + unique_xs[k], ox + unique_xs[k + 1], mc_bot1, sec_bot_y, str(int(round(unique_xs[k + 1] - unique_xs[k]))), text_above=False)
            sb.dim_h(ox + unique_xs[-1], ox + half_b, mc_bot1, sec_bot_y, str(int(round(half_b - unique_xs[-1]))), text_above=False)
        if lean_mc > 0:
            sb.dim_h(ox + half_b, ox + half_b + lean_mc, mc_bot1, lean_bot_y, str(int(round(lean_mc))), text_above=False)
        sb.dim_h(ox - half_b, ox + half_b, mc_bot2, sec_bot_y, str(int(round(B))), text_above=False)

        sb.title_block(0, sec_title_y, "MC 1-1 (%s)" % cfg["ten"], "TL: 1/%d · KL=%.1f kg" % (cfg["tiLe"], comp["khoiLuong1Dai"]), ox=ox)


# ==================== 3. MÓNG BĂNG SCENE ====================

def _draw_strip_footing(sb, cfg, view_mode="sheet", ox=0.0):
    comp = compute_strip_footing(cfg)
    tong_l = float(comp["tongL"])
    H_dam = float(cfg["H_dam"])
    B_dam = float(cfg["B_dam"])
    lot_day = float(cfg["lotDay"])
    lot_chia = float(cfg["lotChia"])

    elev_l, elev_r = -1250.0, tong_l + 420.0
    elev_t, elev_b = -1750.0, H_dam + lot_day + 2450.0

    b_half = B_dam / 2.0
    left_edge = -b_half - float(cfg["canhTrai"])
    right_edge = b_half + float(cfg["canhPhai"])
    sec_dim1_x = min(left_edge - 175.0, -b_half - 620.0)
    sec_dim2_x = sec_dim1_x - 150.0
    sec_l = min(sec_dim2_x - 420.0, -b_half - 1100.0)
    sec_r = max(right_edge + 1100.0, b_half + 1350.0)
    sec_t, sec_b = -380.0, H_dam + lot_day + 840.0

    sec_s = 1.0 if view_mode == "section" else 1.7
    sec_ox = ox + (0.0 if view_mode == "section" else (elev_l - sec_l * sec_s))
    sec_oy = 0.0 if view_mode == "section" else (elev_b + 500.0 - sec_t * sec_s)

    if view_mode in ("sheet", "elevation"):
        sb.rect(ox + elev_l, elev_t, elev_r - elev_l, elev_b - elev_t, stroke=CAD["frame"], fill=None, width=5.0, layer="DCE_Khung")
        y_top, y_bot = 0.0, H_dam
        y_col_top = -float(cfg["chieuCaoCoCot"])
        lean_bot = y_bot + lot_day
        top_dim_y = -1020.0
        axis_dim1_y = lean_bot + 700.0
        axis_dim2_y = lean_bot + 960.0
        axis_c_y = lean_bot + 1360.0
        elev_title_y = axis_c_y + 480.0
        s_elev = max(30.0, float(cfg["tiLeMatDung"]))

        if sb.layers.get("DCE_Block", True):
            for col in comp["colLayouts"]:
                sb.line(ox + col["axisX"], y_col_top - 80, ox + col["axisX"], axis_c_y - 140, CAD["axisGreen"], 3.5, "DCE_Block", dash=(120, 35))
                sb.circle(ox + col["axisX"], axis_c_y, 2.5 * s_elev, stroke=CAD["axisGreen"], fill=CAD["bg"], width=4.0, layer="DCE_Block")
                sb.text(ox + col["axisX"], axis_c_y + 0.3 * s_elev, col["trucLabel"], CAD["axisLabel"], 2.2 * s_elev, "middle", "DCE_Block", bold=True)

        if lot_day > 0:
            sb.hatch_diagonal(-lot_chia, y_bot, tong_l + 2 * lot_chia, lot_day, 90.0, ox)
            if sb.layers.get("DCE_BaoBeTong", True):
                sb.rect(ox - lot_chia, y_bot, tong_l + 2 * lot_chia, lot_day, stroke=CAD["concrete"], fill=None, width=5.0, layer="DCE_BaoBeTong")

        if sb.layers.get("DCE_BaoBeTong", True):
            sb.rect(ox, y_top, tong_l, H_dam, stroke=CAD["concrete"], fill=None, width=5.5, layer="DCE_BaoBeTong")
            for col in comp["colLayouts"]:
                sb.line(ox + col["xStart"], y_top, ox + col["xStart"], y_col_top, CAD["concrete"], 5.0, "DCE_BaoBeTong")
                sb.line(ox + col["xEnd"], y_top, ox + col["xEnd"], y_col_top, CAD["concrete"], 5.0, "DCE_BaoBeTong")
                sb.zigzag_h(col["xStart"] - 60, col["xEnd"] + 60, y_col_top, 45.0, 40.0, ox)
                sb.rect(ox + col["xStart"], y_top, col["bCot"], H_dam, stroke=CAD["axisGreen"], fill=None, width=3.5, layer="DCE_BaoBeTong")

        cover = float(cfg["cover"])
        rt_y, rb_y = y_top + cover, y_bot - cover
        rl_x, rr_x = cover, tong_l - cover
        rm_y = y_top + H_dam / 2.0

        if sb.layers.get("DCE_ThepChu", True):
            hk_t = min(float(cfg["thepTrenMocLen"]), H_dam - 140.0)
            hk_b = min(float(cfg["thepDuoiMocLen"]), H_dam - 180.0)
            sb.polyline([(ox + rl_x + 60, rt_y + hk_t), (ox + rl_x, rt_y + hk_t), (ox + rl_x, rt_y), (ox + rr_x, rt_y), (ox + rr_x, rt_y + hk_t), (ox + rr_x - 60, rt_y + hk_t)], CAD["rebar"], 9.0, "DCE_ThepChu")
            sb.polyline([(ox + rl_x + 85, rb_y - hk_b), (ox + rl_x + 25, rb_y - hk_b), (ox + rl_x + 25, rb_y), (ox + rr_x - 25, rb_y), (ox + rr_x - 25, rb_y - hk_b), (ox + rr_x - 85, rb_y - hk_b)], CAD["rebar"], 9.0, "DCE_ThepChu")
            sb.polyline([(ox + rl_x + 195, rm_y - 25), (ox + rl_x + 130, rm_y), (ox + rr_x - 130, rm_y), (ox + rr_x - 195, rm_y - 25)], CAD["rebar"], 8.0, "DCE_ThepChu")

        if sb.layers.get("DCE_ThepDai", True):
            for sp in comp["spanLayouts"]:
                for tx in (sp["xStart"] + 50, sp["xStart"] + 350, sp["xEnd"] - 300, sp["xEnd"] - 50):
                    if sp["xStart"] + 20 < tx < sp["xEnd"] - 20:
                        sb.line(ox + tx, rt_y, ox + tx, rb_y, CAD["stirrup"], 6.0, "DCE_ThepDai")

        for sp in comp["spanLayouts"]:
            # Section markers above & below span midpoint
            sb.section_marker(sp["midX"], -750.0, "left", "1", size=95.0, line_len=210.0, ox=ox)
            sb.section_marker(sp["midX"], axis_c_y, "left", "1", size=95.0, line_len=210.0, ox=ox)
            # Callout (5) stirrups above span
            sb.callout(sp["midX"], -460.0, "5", "Ø%da%d" % (cfg["thepDaiD"], cfg["thepDaiA"]),
                       [(sp["midX"] - 140, -460.0), (sp["midX"] - 140, rt_y + 120.0)], "right", r=2.1 * s_elev, font_size=1.9 * s_elev, ox=ox)
            # Callout (1) top rebar
            top_cx = sp["xStart"] + max(240.0, min(sp["L_nhip"] * 0.25, sp["midX"] - sp["xStart"] - 340.0))
            sb.callout(top_cx, y_top - 220, "1", "%dØ%d" % (cfg["thepTrenCount"], cfg["thepTrenD"]),
                       [(top_cx + 120, y_top - 220), (min(sp["xEnd"] - 60, top_cx + 540), y_top - 220), (min(sp["xEnd"] - 60, top_cx + 540), rt_y)], "right", r=2.2 * s_elev, font_size=2.0 * s_elev, ox=ox)
            # Callout (2) bottom rebar & (4) skin bar
            bl_x = sp["xStart"] + max(240.0, sp["L_nhip"] * 0.14)
            sb.callout(bl_x, lean_bot + 290, "2", "%dØ%d" % (cfg["thepDuoiCount"], cfg["thepDuoiD"]),
                       [(bl_x + 120, lean_bot + 290), (min(sp["midX"] - 80, bl_x + 500), lean_bot + 290), (min(sp["midX"] - 80, bl_x + 500), rb_y)], "right", r=2.2 * s_elev, font_size=2.0 * s_elev, ox=ox)
            gia_cx = sp["xEnd"] - max(320.0, sp["L_nhip"] * 0.22)
            sb.callout(gia_cx, lean_bot + 290, "4", "%dØ%d" % (cfg["thepGiaCount"], cfg["thepGiaD"]),
                       [(gia_cx - 120, lean_bot + 290), (gia_cx - 320, lean_bot + 290), (gia_cx - 320, rm_y)], "left", r=2.2 * s_elev, font_size=2.0 * s_elev, ox=ox)

        sb.elevation_flag(-380, y_top, format_elevation(cfg["caoTrinhTop"]), scale=s_elev, side="left", ox=ox)
        sb.dim_v(y_top, y_bot, ox - 240, 0, str(int(round(H_dam))), font_size=120.0, tick_size=42.0, overshoot=80.0)
        for idx, col in enumerate(comp["colLayouts"]):
            sb.dim_h(ox + col["xStart"], ox + col["xEnd"], top_dim_y, y_top, str(int(round(col["bCot"]))), font_size=115.0, tick_size=40.0, overshoot=80.0)
            if idx < len(comp["spanLayouts"]):
                sp = comp["spanLayouts"][idx]
                sb.dim_h(ox + sp["xStart"], ox + sp["xEnd"], top_dim_y, y_top, str(int(round(sp["L_nhip"]))), font_size=115.0, tick_size=40.0, overshoot=80.0)
        for idx, gap in enumerate(comp["axisGaps"]):
            sb.dim_h(ox + comp["colLayouts"][idx]["axisX"], ox + comp["colLayouts"][idx + 1]["axisX"], axis_dim1_y, lean_bot, str(int(round(gap))), font_size=120.0, tick_size=42.0, overshoot=80.0)
        if len(comp["colLayouts"]) >= 2:
            sb.dim_h(ox + comp["colLayouts"][0]["axisX"], ox + comp["colLayouts"][-1]["axisX"], axis_dim2_y, lean_bot, str(int(round(comp["axisTotalSpan"]))), font_size=120.0, tick_size=42.0, overshoot=80.0)

        sb.title_block(tong_l / 2.0, elev_title_y, "MÓNG %s (SL=%d; L=%d)" % (cfg["ten"], cfg["soLuong"], comp["tongL"]), "TL: 1/%d" % cfg["tiLeMatDung"], font_title=205.0, font_scale=125.0, ox=ox)

    if view_mode in ("sheet", "section"):
        def sx(val):
            return sec_ox + val * sec_s

        def sy(val):
            return sec_oy + val * sec_s

        s_sec = max(18.0, float(cfg["tiLeMatCat"])) * sec_s
        y_s_top, y_s_sh, y_s_mep, y_s_bot = 0.0, float(comp["hTren"]), H_dam - float(cfg["hMep"]), H_dam
        y_s_lean = y_s_bot + lot_day
        sh_l = min(float(cfg["vaiMepDam"]), float(cfg["canhTrai"])) if cfg["canhTrai"] > 0 else 0.0
        sh_r = min(float(cfg["vaiMepDam"]), float(cfg["canhPhai"])) if cfg["canhPhai"] > 0 else 0.0

        sb.rect(sx(sec_l), sy(sec_t), (sec_r - sec_l) * sec_s, (sec_b - sec_t) * sec_s, stroke=CAD["frame"], fill=None, width=4.0, layer="DCE_Khung")
        if lot_day > 0:
            sb.hatch_diagonal((left_edge - lot_chia) * sec_s, y_s_bot * sec_s, (comp["B_mong"] + 2 * lot_chia) * sec_s, lot_day * sec_s, 75.0 * sec_s, sec_ox, sec_oy)
            if sb.layers.get("DCE_BaoBeTong", True):
                sb.rect(sx(left_edge - lot_chia), sy(y_s_bot), (comp["B_mong"] + 2 * lot_chia) * sec_s, lot_day * sec_s, stroke=CAD["concrete"], fill=None, width=4.0, layer="DCE_BaoBeTong")

        pts = [(-b_half, y_s_top), (b_half, y_s_top)]
        if cfg["canhPhai"] > 0:
            pts.append((b_half, y_s_sh))
            if sh_r > 0:
                pts.append((b_half + sh_r, y_s_sh))
            pts.extend([(right_edge, y_s_mep), (right_edge, y_s_bot)])
        else:
            pts.append((b_half, y_s_bot))
        if cfg["canhTrai"] > 0:
            pts.extend([(left_edge, y_s_bot), (left_edge, y_s_mep)])
            if sh_l > 0:
                pts.append((-b_half - sh_l, y_s_sh))
            pts.append((-b_half, y_s_sh))
        else:
            pts.append((-b_half, y_s_bot))
        if sb.layers.get("DCE_BaoBeTong", True):
            sb.polygon([(sx(px), sy(py)) for (px, py) in pts], stroke=CAD["concrete"], fill=None, width=4.5, layer="DCE_BaoBeTong")

        cover = float(cfg["cover"])
        st_l, st_r, st_t, st_b = -b_half + cover, b_half - cover, y_s_top + cover, y_s_bot - cover
        mid_y = H_dam / 2.0
        if sb.layers.get("DCE_ThepDai", True):
            sb.rect(sx(st_l), sy(st_t), (st_r - st_l) * sec_s, (st_b - st_t) * sec_s, stroke=CAD["stirrup"], fill=None, width=5.5, layer="DCE_ThepDai")
            # 135-deg corner hook on outer stirrup
            sb.line(sx(st_l), sy(st_t), sx(st_l + 32), sy(st_t + 32), CAD["stirrup"], 4.5, "DCE_ThepDai")
            # C-tie (6) hooking skin bars (4)
            sb.polyline([
                (sx(st_l + 28), sy(mid_y - 40)), (sx(st_l), sy(mid_y - 40)),
                (sx(st_l), sy(mid_y)), (sx(st_r), sy(mid_y)),
                (sx(st_r), sy(mid_y - 40)), (sx(st_r - 28), sy(mid_y - 40)),
            ], CAD["stirrup"], 4.5, "DCE_ThepDai")

        if sb.layers.get("DCE_ThepChu", True):
            mb_l, mb_r, mb_y = left_edge + cover, right_edge - cover, y_s_bot - cover
            hk = float(cfg["thepNgangCanhHook"])
            sb.polyline([(sx(mb_l), sy(mb_y - hk)), (sx(mb_l), sy(mb_y)), (sx(mb_r), sy(mb_y)), (sx(mb_r), sy(mb_y - hk))], CAD["rebar"], 6.5, "DCE_ThepChu")
            nt = max(1, int(cfg["thepTrenCount"]))
            nb = max(1, int(cfg["thepDuoiCount"]))
            dot_ty = st_t + max(14.0, cfg["thepTrenD"] * 0.85)
            dot_by = st_b - max(14.0, cfg["thepDuoiD"] * 0.85)
            for i in range(nt):
                dx = ((st_l + st_r) / 2.0) if nt == 1 else (st_l + 20 + (st_r - st_l - 40) * i / float(nt - 1))
                sb.circle(sx(dx), sy(dot_ty), max(10.0, cfg["thepTrenD"] * 0.8) * sec_s, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")
            for i in range(nb):
                dx = ((st_l + st_r) / 2.0) if nb == 1 else (st_l + 20 + (st_r - st_l - 40) * i / float(nb - 1))
                sb.circle(sx(dx), sy(dot_by), max(10.0, cfg["thepDuoiD"] * 0.8) * sec_s, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")
            # Skin bars (4) left & right
            sb.circle(sx(st_l + 22), sy(mid_y), max(8.0, cfg["thepGiaD"] * 0.75) * sec_s, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")
            sb.circle(sx(st_r - 22), sy(mid_y), max(8.0, cfg["thepGiaD"] * 0.75) * sec_s, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")
            # Wing longitudinal bars (3) across wings
            n_wing = max(2, min(16, int(cfg.get("thepDocCanhCount", 6))))
            wing_r = max(7.5, float(cfg.get("thepDocCanhD", 12)) * 0.7) * sec_s
            wing_dot_y = mb_y - 12.0
            wing_xs = []
            if cfg["canhTrai"] > 0 and cfg["canhPhai"] > 0:
                half_n = max(1, n_wing // 2)
                for wi in range(half_n):
                    wing_xs.append(mb_l + 40 + (st_l - 60 - (mb_l + 40)) * wi / float(max(1, half_n - 1)))
                for wi in range(n_wing - half_n):
                    wing_xs.append(st_r + 60 + (mb_r - 40 - (st_r + 60)) * wi / float(max(1, n_wing - half_n - 1)))
            elif cfg["canhPhai"] > 0:
                for wi in range(n_wing):
                    wing_xs.append(st_r + 70 + (mb_r - 40 - (st_r + 70)) * wi / float(max(1, n_wing - 1)))
            elif cfg["canhTrai"] > 0:
                for wi in range(n_wing):
                    wing_xs.append(mb_l + 40 + (st_l - 70 - (mb_l + 40)) * wi / float(max(1, n_wing - 1)))
            for wx in wing_xs:
                sb.circle(sx(wx), sy(wing_dot_y), wing_r, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")

            # Stacked 5 left callouts: (1), (6), (4), (5), (2) + right callouts (3), (MB)
            lx_c = left_edge - 420.0
            sb.callout(sx(lx_c), sy(dot_ty - 20), "1", "%dØ%d" % (cfg["thepTrenCount"], cfg["thepTrenD"]),
                       [(sx(lx_c + 65), sy(dot_ty - 20)), (sx(st_l + 20), sy(dot_ty))], "left", r=2.0 * s_sec, font_size=1.85 * s_sec)
            sb.callout(sx(lx_c), sy(dot_ty + 115), "6", "Ø%da%d" % (cfg["thepDaiGiaD"], cfg["thepDaiGiaA"]),
                       [(sx(lx_c + 65), sy(dot_ty + 115)), (sx(st_l), sy(mid_y - 30))], "left", r=2.0 * s_sec, font_size=1.85 * s_sec)
            sb.callout(sx(lx_c), sy(mid_y), "4", "%dØ%d" % (cfg["thepGiaCount"], cfg["thepGiaD"]),
                       [(sx(lx_c + 65), sy(mid_y)), (sx(st_l + 22), sy(mid_y))], "left", r=2.0 * s_sec, font_size=1.85 * s_sec)
            sb.callout(sx(lx_c), sy(mid_y + 135), "5", "Ø%da%d" % (cfg["thepDaiD"], cfg["thepDaiA"]),
                       [(sx(lx_c + 65), sy(mid_y + 135)), (sx(st_l), sy(mid_y + 135))], "left", r=2.0 * s_sec, font_size=1.85 * s_sec)
            sb.callout(sx(lx_c), sy(dot_by), "2", "%dØ%d" % (cfg["thepDuoiCount"], cfg["thepDuoiD"]),
                       [(sx(lx_c + 65), sy(dot_by)), (sx(st_l + 20), sy(dot_by))], "left", r=2.0 * s_sec, font_size=1.85 * s_sec)

            if wing_xs:
                sb.callout(sx(right_edge + 380), sy(y_s_bot - 170), "3", "%dØ%d" % (cfg["thepDocCanhCount"], cfg["thepDocCanhD"]),
                           [(sx(right_edge + 320), sy(y_s_bot - 170)), (sx(wing_xs[-1]), sy(y_s_bot - 170)), (sx(wing_xs[-1]), sy(wing_dot_y))], "right", r=2.0 * s_sec, font_size=1.85 * s_sec)
            sb.callout(sx(right_edge + 380), sy(y_s_bot - 25), "MB", "Ø%da%d" % (cfg["thepNgangCanhD"], cfg["thepNgangCanhA"]),
                       [(sx(right_edge + 320), sy(y_s_bot - 25)), (sx(mb_r - 70), sy(y_s_bot - 25)), (sx(mb_r - 70), sy(mb_y))], "right", r=2.0 * s_sec, font_size=1.85 * s_sec)

        sb.elevation_flag(b_half + 120, y_s_top, format_elevation(cfg["caoTrinhTop"]), scale=s_sec / sec_s, side="right", ox=sec_ox + b_half * (sec_s - 1.0), oy=sec_oy)
        # Left detailed vertical dims: hTren | hVat | hMep | lotDay + H_dam
        x_d1 = sx(sec_dim1_x)
        x_d2 = sx(sec_dim2_x)
        if comp["hTren"] > 0:
            sb.dim_v(sy(y_s_top), sy(y_s_sh), x_d1, sx(-b_half), str(int(round(comp["hTren"]))), font_size=46.0 * sec_s, tick_size=16.0 * sec_s, overshoot=28.0 * sec_s)
        if float(cfg["hVat"]) > 0:
            sb.dim_v(sy(y_s_sh), sy(y_s_mep), x_d1, sx(left_edge), str(int(round(cfg["hVat"]))), font_size=46.0 * sec_s, tick_size=16.0 * sec_s, overshoot=28.0 * sec_s)
        sb.dim_v(sy(y_s_mep), sy(y_s_bot), x_d1, sx(left_edge), str(int(round(cfg["hMep"]))), font_size=46.0 * sec_s, tick_size=16.0 * sec_s, overshoot=28.0 * sec_s)
        if lot_day > 0:
            sb.dim_v(sy(y_s_bot), sy(y_s_lean), x_d1, sx(left_edge - lot_chia), str(int(round(lot_day))), font_size=46.0 * sec_s, tick_size=16.0 * sec_s, overshoot=28.0 * sec_s)
        sb.dim_v(sy(y_s_top), sy(y_s_bot), x_d2, sx(-b_half), str(int(round(H_dam))), font_size=46.0 * sec_s, tick_size=16.0 * sec_s, overshoot=28.0 * sec_s)

        # Bottom MC 1-1 detailed chain: lotChia | canhTrai | B_dam | canhPhai | lotChia + B_mong
        y_bd1 = sy(y_s_lean + 190)
        y_bd2 = sy(y_s_lean + 360)
        if lot_chia > 0:
            sb.dim_h(sx(left_edge - lot_chia), sx(left_edge), y_bd1, sy(y_s_lean), str(int(round(lot_chia))), font_size=46.0 * sec_s, tick_size=16.0 * sec_s, overshoot=28.0 * sec_s, text_above=False)
        if cfg["canhTrai"] > 0:
            sb.dim_h(sx(left_edge), sx(-b_half), y_bd1, sy(y_s_bot), str(int(round(cfg["canhTrai"]))), font_size=46.0 * sec_s, tick_size=16.0 * sec_s, overshoot=28.0 * sec_s, text_above=False)
        sb.dim_h(sx(-b_half), sx(b_half), y_bd1, sy(y_s_bot), str(int(round(B_dam))), font_size=46.0 * sec_s, tick_size=16.0 * sec_s, overshoot=28.0 * sec_s, text_above=False)
        if cfg["canhPhai"] > 0:
            sb.dim_h(sx(b_half), sx(right_edge), y_bd1, sy(y_s_bot), str(int(round(cfg["canhPhai"]))), font_size=46.0 * sec_s, tick_size=16.0 * sec_s, overshoot=28.0 * sec_s, text_above=False)
        if lot_chia > 0:
            sb.dim_h(sx(right_edge), sx(right_edge + lot_chia), y_bd1, sy(y_s_lean), str(int(round(lot_chia))), font_size=46.0 * sec_s, tick_size=16.0 * sec_s, overshoot=28.0 * sec_s, text_above=False)
        sb.dim_h(sx(left_edge), sx(right_edge), y_bd2, sy(y_s_bot), str(int(round(comp["B_mong"]))), font_size=46.0 * sec_s, tick_size=16.0 * sec_s, overshoot=28.0 * sec_s, text_above=False)

        sb.title_block(sx(0), sy(y_s_lean + 540), "MC 1-1 (%s)" % cfg["ten"], "TL: 1/%d · KL=%.1f kg" % (cfg["tiLeMatCat"], comp["khoiLuong1Mong"]), font_title=82.0 * sec_s, font_scale=52.0 * sec_s)


# ==================== 4. DẦM MÓNG SCENE ====================

def _draw_foundation_beam(sb, cfg, view_mode="sheet", ox=0.0):
    comp = compute_foundation_beam(cfg)
    tong_l = float(comp["tongL"])
    H_dam = float(cfg["H_dam"])
    B_dam = float(cfg["B_dam"])
    lot_day = float(cfg["lotDay"])
    lot_chia = float(cfg["lotChiaMatCat"])

    elev_l, elev_r = -980.0, tong_l + 420.0
    elev_t, elev_b = -1520.0, H_dam + max(lot_day, float(cfg["supportBotExt"])) + 1680.0

    b_half = B_dam / 2.0
    lean_half = b_half + lot_chia
    sec_l = -max(lean_half + 480.0, b_half + 650.0) - 520.0
    sec_r = max(lean_half + 360.0, b_half + 760.0)
    sec_t, sec_b = -380.0, H_dam + lot_day + 680.0

    sec_s = 1.0 if view_mode == "section" else 1.85
    sec_ox = ox + (0.0 if view_mode == "section" else (elev_l - sec_l * sec_s))
    sec_oy = 0.0 if view_mode == "section" else (elev_b + 380.0 - sec_t * sec_s)

    if view_mode in ("sheet", "elevation"):
        sb.rect(ox + elev_l, elev_t, elev_r - elev_l, elev_b - elev_t, stroke=CAD["frame"], fill=None, width=5.0, layer="DCE_Khung")
        y_top, y_bot = 0.0, H_dam
        y_sup_top = -float(cfg["supportTopExt"])
        y_sup_bot = y_bot + float(cfg["supportBotExt"])
        lean_bot = y_bot + lot_day
        bot_start = max(y_sup_bot, lean_bot)
        top_dim_y = y_sup_top - 440.0
        axis_dim1_y = bot_start + 340.0
        axis_dim2_y = bot_start + 580.0
        axis_c_y = bot_start + 950.0
        elev_title_y = axis_c_y + 460.0
        s_elev = max(36.0, float(cfg["tiLeMatDung"]))

        if sb.layers.get("DCE_Block", True):
            for sup in comp["supportSegments"]:
                sb.line(ox + sup["axisX"], y_sup_top - 60, ox + sup["axisX"], axis_c_y - 135, CAD["axisGreen"], 3.5, "DCE_Block", dash=(120, 35))
                sb.circle(ox + sup["axisX"], axis_c_y, 2.4 * s_elev, stroke=CAD["axisGreen"], fill=CAD["bg"], width=4.0, layer="DCE_Block")
                sb.text(ox + sup["axisX"], axis_c_y + 0.3 * s_elev, sup["trucLabel"], CAD["axisLabel"], 2.1 * s_elev, "middle", "DCE_Block", bold=True)

        if lot_day > 0:
            for sp in comp["spanSegments"]:
                sb.hatch_diagonal(sp["xStart"], y_bot, sp["L_thongThuy"], lot_day, 75.0, ox)
                if sb.layers.get("DCE_BaoBeTong", True):
                    sb.rect(ox + sp["xStart"], y_bot, sp["L_thongThuy"], lot_day, stroke=CAD["concrete"], fill=None, width=4.5, layer="DCE_BaoBeTong")

        if sb.layers.get("DCE_BaoBeTong", True):
            sb.rect(ox, y_top, tong_l, H_dam, stroke=CAD["concrete"], fill=None, width=5.5, layer="DCE_BaoBeTong")
            for sup in comp["supportSegments"]:
                sb.line(ox + sup["xStart"], y_sup_top, ox + sup["xStart"], y_sup_bot, CAD["concrete"], 4.5, "DCE_BaoBeTong")
                sb.line(ox + sup["xEnd"], y_sup_top, ox + sup["xEnd"], y_sup_bot, CAD["concrete"], 4.5, "DCE_BaoBeTong")
                sb.zigzag_h(sup["xStart"] - 40, sup["xEnd"] + 40, y_sup_top, 60, 45, ox)
                sb.zigzag_h(sup["xStart"] - 40, sup["xEnd"] + 40, y_sup_bot, 60, 45, ox)
                # Green intersecting cross-beam / column core inside support
                cw = min(sup["supportLen"] * 0.7, max(160.0, sup.get("colW", 300.0)))
                ch = min(H_dam - 40.0, max(200.0, sup.get("colH", 600.0)))
                cx0 = (sup["xStart"] + sup["xEnd"]) / 2.0 - cw / 2.0
                cy0 = (y_top + y_bot) / 2.0 - ch / 2.0
                sb.rect(ox + cx0, cy0, cw, ch, stroke=CAD["axisGreen"], fill=None, width=3.5, layer="DCE_BaoBeTong")
            for sp in comp["spanSegments"]:
                if sp.get("hasMidCrossBeam"):
                    mcw = float(sp.get("midCrossW", 300.0))
                    mch = min(H_dam * 0.45, float(sp.get("midCrossH", 300.0)))
                    mx0 = (sp["xStart"] + sp["xEnd"]) / 2.0 - mcw / 2.0
                    sb.rect(ox + mx0, y_top, mcw, mch, stroke=CAD["axisGreen"], fill=None, width=3.5, layer="DCE_BaoBeTong")

        cover = float(cfg["cover"])
        rt1_y = y_top + cover
        rt2_y = rt1_y + max(42.0, cfg["thepTren1D"] * 2.5)
        rb_y = y_bot - cover
        rm_y = y_top + H_dam / 2.0
        if sb.layers.get("DCE_ThepChu", True):
            hk1 = min(float(cfg["thepTren1Moc"]), H_dam - 150.0)
            hk2 = min(float(cfg["thepTren2Moc"]), H_dam - 180.0)
            hkb = min(float(cfg["thepDuoiMoc"]), H_dam - 150.0)
            sb.polyline([(ox + cover, rt1_y + hk1), (ox + cover, rt1_y), (ox + tong_l - cover, rt1_y), (ox + tong_l - cover, rt1_y + hk1)], CAD["rebar"], 8.5, "DCE_ThepChu")
            sb.polyline([(ox + cover + 30, rt2_y + hk2), (ox + cover + 30, rt2_y), (ox + tong_l - cover - 30, rt2_y), (ox + tong_l - cover - 30, rt2_y + hk2)], CAD["rebar"], 7.5, "DCE_ThepChu")
            sb.polyline([(ox + cover + 16, rb_y - hkb), (ox + cover + 16, rb_y), (ox + tong_l - cover - 16, rb_y), (ox + tong_l - cover - 16, rb_y - hkb)], CAD["rebar"], 8.5, "DCE_ThepChu")
            gia_s = comp["spanSegments"][0]["xStart"] if comp["spanSegments"] else 0.0
            gia_e = comp["spanSegments"][-1]["xEnd"] if comp["spanSegments"] else tong_l
            sb.line(ox + max(cover + 60, gia_s - cfg["thepGiaNeoGoi"]), rm_y, ox + min(tong_l - cover - 60, gia_e + cfg["thepGiaNeoGoi"]), rm_y, CAD["rebar"], 7.0, "DCE_ThepChu")

        # Dense stirrup ticks in support zones + sparser ticks in midspan
        if sb.layers.get("DCE_ThepDai", True):
            for sp in comp["spanSegments"]:
                vgl = float(sp["vungGoiLen"])
                tx_list = [
                    sp["xStart"] + 60, sp["xStart"] + vgl * 0.35, sp["xStart"] + vgl * 0.7, sp["xStart"] + vgl,
                    (sp["xStart"] + sp["xEnd"]) / 2.0 - 220, (sp["xStart"] + sp["xEnd"]) / 2.0 + 220,
                    sp["xEnd"] - vgl, sp["xEnd"] - vgl * 0.7, sp["xEnd"] - vgl * 0.35, sp["xEnd"] - 60,
                ]
                for tx in tx_list:
                    if sp["xStart"] + 20 < tx < sp["xEnd"] - 20:
                        sb.line(ox + tx, rt1_y, ox + tx, rb_y, CAD["stirrup"], 5.0, "DCE_ThepDai")

        # Callouts on Elevation (5, 1, 3, 2, 4 + section 1-1 markers)
        for sp in comp["spanSegments"]:
            mid_x = (sp["xStart"] + sp["xEnd"]) / 2.0
            vgl = float(sp["vungGoiLen"])
            sb.section_marker(mid_x, y_sup_top - 210.0, "left", "1", size=90.0, line_len=200.0, ox=ox)
            sb.section_marker(mid_x, axis_c_y - 120.0, "left", "1", size=90.0, line_len=200.0, ox=ox)
            if vgl >= 250.0:
                sb.callout(sp["xStart"] + vgl * 0.5, y_top - 480.0, "5", "Ø%da%d" % (cfg["thepDaiD"], cfg["thepDaiAGoi"]),
                           [(sp["xStart"] + vgl * 0.5, y_top - 380.0), (sp["xStart"] + vgl * 0.5, rt1_y + 120.0)], "right", r=1.9 * s_elev, font_size=1.7 * s_elev, ox=ox)
                sb.callout(sp["xEnd"] - vgl * 0.5, y_top - 480.0, "5", "Ø%da%d" % (cfg["thepDaiD"], cfg["thepDaiAGoi"]),
                           [(sp["xEnd"] - vgl * 0.5, y_top - 380.0), (sp["xEnd"] - vgl * 0.5, rt1_y + 120.0)], "right", r=1.9 * s_elev, font_size=1.7 * s_elev, ox=ox)
            sb.callout(mid_x - 80.0, y_top - 480.0, "5", "Ø%da%d" % (cfg["thepDaiD"], cfg["thepDaiANhip"]),
                       [(mid_x, y_top - 380.0), (mid_x, rt1_y + 120.0)], "right", r=1.9 * s_elev, font_size=1.7 * s_elev, ox=ox)

            # Stacked top (1) & (3)
            sb.callout(mid_x - 320.0, y_top - 220.0, "1", "%dØ%d" % (cfg["thepTren1Count"], cfg["thepTren1D"]),
                       [(mid_x - 200.0, y_top - 220.0), (mid_x + 40.0, y_top - 220.0), (mid_x + 40.0, rt1_y)], "right", r=1.9 * s_elev, font_size=1.7 * s_elev, ox=ox)
            sb.callout(mid_x - 320.0, y_top - 70.0, "3", "%dØ%d" % (cfg["thepTren2Count"], cfg["thepTren2D"]),
                       [(mid_x - 200.0, y_top - 70.0), (mid_x - 10.0, y_top - 70.0), (mid_x - 10.0, rt2_y)], "right", r=1.9 * s_elev, font_size=1.7 * s_elev, ox=ox)
            # Bottom (2) & skin (4)
            sb.callout(mid_x - 280.0, lean_bot + 210.0, "2", "%dØ%d" % (cfg["thepDuoiCount"], cfg["thepDuoiD"]),
                       [(mid_x - 180.0, lean_bot + 210.0), (mid_x - 20.0, lean_bot + 210.0), (mid_x - 20.0, rb_y)], "left", r=1.9 * s_elev, font_size=1.7 * s_elev, ox=ox)
            sb.callout(mid_x + 280.0, lean_bot + 210.0, "4", "%dØ%d" % (cfg["thepGiaCount"], cfg["thepGiaD"]),
                       [(mid_x + 180.0, lean_bot + 210.0), (mid_x + 40.0, lean_bot + 210.0), (mid_x + 40.0, rm_y)], "right", r=1.9 * s_elev, font_size=1.7 * s_elev, ox=ox)

        # Top dimensions split into support + 3 span zones (vungGoi | vungNhip | vungGoi)
        for idx, sup in enumerate(comp["supportSegments"]):
            sb.dim_h(ox + sup["xStart"], ox + sup["xEnd"], top_dim_y, y_sup_top, str(int(round(sup["supportLen"]))), font_size=115.0, tick_size=40.0, overshoot=80.0)
            if idx < len(comp["spanSegments"]):
                sp = comp["spanSegments"][idx]
                vgl = sp["vungGoiLen"]
                if vgl > 50 and sp["vungNhipLen"] > 50:
                    sb.dim_h(ox + sp["xStart"], ox + sp["xStart"] + vgl, top_dim_y, y_top, str(int(round(vgl))), font_size=115.0, tick_size=40.0, overshoot=80.0)
                    sb.dim_h(ox + sp["xStart"] + vgl, ox + sp["xEnd"] - vgl, top_dim_y, y_top, str(int(round(sp["vungNhipLen"]))), font_size=115.0, tick_size=40.0, overshoot=80.0)
                    sb.dim_h(ox + sp["xEnd"] - vgl, ox + sp["xEnd"], top_dim_y, y_top, str(int(round(vgl))), font_size=115.0, tick_size=40.0, overshoot=80.0)
                else:
                    sb.dim_h(ox + sp["xStart"], ox + sp["xEnd"], top_dim_y, y_top, str(int(round(sp["L_thongThuy"]))), font_size=115.0, tick_size=40.0, overshoot=80.0)

        for i in range(len(comp["supportSegments"]) - 1):
            a1, a2 = comp["supportSegments"][i]["axisX"], comp["supportSegments"][i + 1]["axisX"]
            sb.dim_h(ox + a1, ox + a2, axis_dim1_y, bot_start, str(int(round(a2 - a1))), font_size=120.0, tick_size=42.0, overshoot=80.0)
        if len(comp["supportSegments"]) >= 2:
            a0, an = comp["supportSegments"][0]["axisX"], comp["supportSegments"][-1]["axisX"]
            sb.dim_h(ox + a0, ox + an, axis_dim2_y, bot_start, str(int(round(an - a0))), font_size=120.0, tick_size=42.0, overshoot=80.0)
        sb.dim_v(y_top, y_bot, ox - 240, 0, str(int(round(H_dam))), font_size=120.0, tick_size=42.0, overshoot=80.0)
        sb.elevation_flag(-380, y_top, format_elevation(cfg["caoTrinhTop"]), scale=s_elev, side="left", ox=ox)
        sb.title_block(tong_l / 2.0, elev_title_y, "DẦM %s (SL=%d; L=%d)" % (cfg["ten"], cfg["soLuong"], comp["tongL"]), "TL: 1/%d" % cfg["tiLeMatDung"], font_title=205.0, font_scale=125.0, ox=ox)

    if view_mode in ("sheet", "section"):
        def sx(val):
            return sec_ox + val * sec_s

        def sy(val):
            return sec_oy + val * sec_s

        s_sec = max(18.0, float(cfg["tiLeMatCat"])) * sec_s
        sb.rect(sx(sec_l), sy(sec_t), (sec_r - sec_l) * sec_s, (sec_b - sec_t) * sec_s, stroke=CAD["frame"], fill=None, width=4.0, layer="DCE_Khung")
        if lot_day > 0:
            sb.hatch_diagonal(-lean_half * sec_s, H_dam * sec_s, 2 * lean_half * sec_s, lot_day * sec_s, 65.0 * sec_s, sec_ox, sec_oy)
            if sb.layers.get("DCE_BaoBeTong", True):
                sb.rect(sx(-lean_half), sy(H_dam), 2 * lean_half * sec_s, lot_day * sec_s, stroke=CAD["concrete"], fill=None, width=4.0, layer="DCE_BaoBeTong")
        if sb.layers.get("DCE_BaoBeTong", True):
            sb.rect(sx(-b_half), sy(0), B_dam * sec_s, H_dam * sec_s, stroke=CAD["concrete"], fill=None, width=4.5, layer="DCE_BaoBeTong")
        cover = float(cfg["cover"])
        st_l, st_r, st_t, st_b = -b_half + cover, b_half - cover, cover, H_dam - cover
        dt1 = st_t + max(18.0, cfg["thepTren1D"] * 1.1)
        dt2 = dt1 + max(48.0, cfg["thepTren2D"] * 2.8)
        db = st_b - max(18.0, cfg["thepDuoiD"] * 1.1)
        mid_y = H_dam / 2.0

        if sb.layers.get("DCE_ThepDai", True):
            sb.rect(sx(st_l), sy(st_t), (st_r - st_l) * sec_s, (st_b - st_t) * sec_s, stroke=CAD["stirrup"], fill=None, width=5.0, layer="DCE_ThepDai")
            # 135-deg outer stirrup corner hook
            sb.line(sx(st_l), sy(st_t), sx(st_l + 32), sy(st_t + 32), CAD["stirrup"], 4.5, "DCE_ThepDai")
            # C-tie (6) clamping layer 2 top bars
            sb.polyline([
                (sx(st_l + 30), sy(dt2 + 32)), (sx(st_l), sy(dt2 + 32)),
                (sx(st_l), sy(dt2)), (sx(st_r), sy(dt2)),
                (sx(st_r), sy(dt2 + 32)), (sx(st_r - 30), sy(dt2 + 32)),
            ], CAD["stirrup"], 4.5, "DCE_ThepDai")
            # C-tie (7) clamping mid-depth skin bars
            sb.polyline([
                (sx(st_l + 30), sy(mid_y - 36)), (sx(st_l), sy(mid_y - 36)),
                (sx(st_l), sy(mid_y)), (sx(st_r), sy(mid_y)),
                (sx(st_r), sy(mid_y - 36)), (sx(st_r - 30), sy(mid_y - 36)),
            ], CAD["stirrup"], 4.5, "DCE_ThepDai")

        if sb.layers.get("DCE_ThepChu", True):
            for cnt, cy_dot, diam in ((cfg["thepTren1Count"], dt1, cfg["thepTren1D"]), (cfg["thepTren2Count"], dt2, cfg["thepTren2D"]), (cfg["thepDuoiCount"], db, cfg["thepDuoiD"])):
                n = max(1, int(cnt))
                for i in range(n):
                    dx = ((st_l + st_r) / 2.0) if n == 1 else (st_l + 22 + (st_r - st_l - 44) * i / float(n - 1))
                    sb.circle(sx(dx), sy(cy_dot), max(10.0, diam * 0.75) * sec_s, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")
            sb.circle(sx(st_l + 22), sy(mid_y), max(8.0, cfg["thepGiaD"] * 0.75) * sec_s, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")
            sb.circle(sx(st_r - 22), sy(mid_y), max(8.0, cfg["thepGiaD"] * 0.75) * sec_s, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")

            # Stacked 6 left callouts: (6), (1), (7), (4), (5), (2) + right (3)
            lx_c = -lean_half - 440.0
            sb.callout(sx(lx_c), sy(dt1 - 165), "6", "Ø%da%d" % (cfg["thepDaiCTrenD"], cfg["thepDaiCTrenA"]),
                       [(sx(lx_c + 65), sy(dt1 - 165)), (sx(st_l + 30), sy(dt1 - 165)), (sx(st_l + 30), sy(dt2))], "left", r=2.0 * s_sec, font_size=1.8 * s_sec)
            sb.callout(sx(lx_c), sy(dt1 - 20), "1", "%dØ%d" % (cfg["thepTren1Count"], cfg["thepTren1D"]),
                       [(sx(lx_c + 65), sy(dt1 - 20)), (sx(st_l + 22), sy(dt1))], "left", r=2.0 * s_sec, font_size=1.8 * s_sec)
            sb.callout(sx(lx_c), sy(mid_y - 125), "7", "Ø%da%d" % (cfg["thepDaiCHongD"], cfg["thepDaiCHongA"]),
                       [(sx(lx_c + 65), sy(mid_y - 125)), (sx(st_l), sy(mid_y))], "left", r=2.0 * s_sec, font_size=1.8 * s_sec)
            sb.callout(sx(lx_c), sy(mid_y + 20), "4", "%dØ%d" % (cfg["thepGiaCount"], cfg["thepGiaD"]),
                       [(sx(lx_c + 65), sy(mid_y + 20)), (sx(st_l + 22), sy(mid_y))], "left", r=2.0 * s_sec, font_size=1.8 * s_sec)
            sb.callout(sx(lx_c), sy(mid_y + 185), "5", "Ø%da%d/%d" % (cfg["thepDaiD"], cfg["thepDaiAGoi"], cfg["thepDaiANhip"]),
                       [(sx(lx_c + 65), sy(mid_y + 185)), (sx(st_l), sy(mid_y + 185))], "left", r=2.0 * s_sec, font_size=1.8 * s_sec)
            sb.callout(sx(lx_c), sy(H_dam + lot_day + 80), "2", "%dØ%d" % (cfg["thepDuoiCount"], cfg["thepDuoiD"]),
                       [(sx(lx_c + 65), sy(H_dam + lot_day + 80)), (sx(st_l + 22), sy(H_dam + lot_day + 80)), (sx(st_l + 22), sy(db))], "left", r=2.0 * s_sec, font_size=1.8 * s_sec)
            sb.callout(sx(lean_half + 320), sy(dt2), "3", "%dØ%d" % (cfg["thepTren2Count"], cfg["thepTren2D"]),
                       [(sx(lean_half + 255), sy(dt2)), (sx(st_r - 22), sy(dt2))], "right", r=2.0 * s_sec, font_size=1.8 * s_sec)

        sb.elevation_flag(b_half + 100, 0.0, format_elevation(cfg["caoTrinhTop"]), scale=s_sec / sec_s, side="right", ox=sec_ox + b_half * (sec_s - 1.0), oy=sec_oy)
        # Bottom MC 1-1 dim chain: lotChia | B_dam | lotChia
        y_mc_b = sy(H_dam + lot_day + 160)
        if lot_chia > 0:
            sb.dim_h(sx(-lean_half), sx(-b_half), y_mc_b, sy(H_dam + lot_day), str(int(round(lot_chia))), font_size=48.0 * sec_s, tick_size=16.0 * sec_s, overshoot=28.0 * sec_s, text_above=False)
        sb.dim_h(sx(-b_half), sx(b_half), y_mc_b, sy(H_dam), str(int(round(B_dam))), font_size=48.0 * sec_s, tick_size=16.0 * sec_s, overshoot=28.0 * sec_s, text_above=False)
        if lot_chia > 0:
            sb.dim_h(sx(b_half), sx(lean_half), y_mc_b, sy(H_dam + lot_day), str(int(round(lot_chia))), font_size=48.0 * sec_s, tick_size=16.0 * sec_s, overshoot=28.0 * sec_s, text_above=False)

        sb.dim_v(sy(0), sy(H_dam), sx(-b_half - 180), sx(-b_half), str(int(round(H_dam))), font_size=48.0 * sec_s, tick_size=16.0 * sec_s, overshoot=28.0 * sec_s)
        if lot_day > 0:
            sb.dim_v(sy(H_dam), sy(H_dam + lot_day), sx(-b_half - 180), sx(-lean_half), str(int(round(lot_day))), font_size=48.0 * sec_s, tick_size=16.0 * sec_s, overshoot=28.0 * sec_s)
        sb.title_block(sx(0), sy(H_dam + lot_day + 440), "DẦM %s (SL=%d; L=%d)" % (cfg["ten"], cfg["soLuong"], comp["tongL"]), "MC 1-1 (TỶ LỆ 1/%d)" % cfg["tiLeMatCat"], font_title=65.0 * sec_s, font_scale=44.0 * sec_s)


# ==================== 5. 2D MODEL FLOOR-PLAN LOCATOR (WITH RED CIRCLES) ====================

def build_model_map_scene(module_lists, active_module=None, active_id=None, layers=None, scan_candidates=None):
    """
    Build a 2D Model Floor-Plan scene placing all scanned foundations and beams
    at their actual world XY coordinates (with world_y negated to screen Y-down),
    and drawing BOLD RED CIRCLES around every scanned item so users can verify
    exact model locations and never mix up Marks.
    """
    sb = SceneBuilder(layers or {"DCE_BaoBeTong": True, "DCE_Block": True, "DCE_Dim": True, "DCE_Hatch": True, "DCE_ThepChu": True, "DCE_ThepDai": True})

    instances = []
    if scan_candidates is not None:
        for c in scan_candidates:
            sel = bool(c.get("selected", True))
            is_act = (active_id is not None and c.get("id") == active_id)
            wis = list(c.get("worldInstances") or [])
            if wis:
                for wi in wis:
                    instances.append({
                        "ten": c.get("ten", wi.get("ten", "")),
                        "kind": c.get("kind", wi.get("kind", "mong_don")),
                        "selected": sel,
                        "active": is_act,
                        "wi": wi,
                        "soLuong": c.get("soLuong", 1),
                    })
    else:
        all_mods = (
            ("mong_don", module_lists.get("mong_don", [])),
            ("mong_bang", module_lists.get("mong_bang", [])),
            ("mong_coc", module_lists.get("mong_coc", [])),
            ("dam_mong", module_lists.get("dam_mong", [])),
        )
        fallback_x = 0.0
        for mod_key, items in all_mods:
            for it in items:
                is_act = (mod_key == active_module and it.get("id") == active_id)
                wis = list(it.get("worldInstances") or [])
                if wis:
                    for wi in wis:
                        instances.append({
                            "ten": it.get("ten", wi.get("ten", "")),
                            "kind": mod_key,
                            "selected": True,
                            "active": is_act,
                            "wi": wi,
                            "soLuong": it.get("soLuong", 1),
                        })
                else:
                    # Schematic row placement when item has no model world coords
                    bw = float(it.get("B") or it.get("B_dam") or 800.0)
                    bl = float(it.get("L") or 3000.0)
                    instances.append({
                        "ten": it.get("ten", ""),
                        "kind": mod_key,
                        "selected": True,
                        "active": is_act,
                        "soLuong": it.get("soLuong", 1),
                        "wi": {
                            "cx": fallback_x + bw / 2.0,
                            "cy": -4000.0,
                            "B": bw,
                            "L": bl,
                            "ang": 0.0,
                        },
                    })
                    fallback_x += bw + 1400.0

    if not instances:
        sb.text(500.0, 400.0, "Chưa có dữ liệu tọa độ từ mô hình. Hãy thực hiện Quét ở Bước 1.", CAD["dimLine"], 46.0, "middle", "DCE_Block", bold=True)
        return sb.build_result()

    # Estimate label/stroke scale from overall plan extent
    cxs = [float(x["wi"].get("cx", 0.0)) for x in instances]
    cys = [-float(x["wi"].get("cy", 0.0)) for x in instances]
    span_x = max(2500.0, (max(cxs) - min(cxs)) + 2400.0)
    span_y = max(2500.0, (max(cys) - min(cys)) + 2400.0)
    plan_scale = max(span_x, span_y)
    font_sz = max(75.0, min(320.0, plan_scale * 0.018))
    ring_pad = max(220.0, plan_scale * 0.018)

    for inst in instances:
        wi = inst["wi"]
        cx = float(wi.get("cx", 0.0))
        cy = -float(wi.get("cy", 0.0))  # World Y up -> scene Y down
        bw = float(wi.get("B") or 500.0)
        bl = float(wi.get("L") or 500.0)
        ang = float(wi.get("ang") or 0.0)
        kind = inst["kind"]
        is_act = inst["active"]
        is_sel = inst["selected"]

        stroke_col = "#22D3EE" if is_act else (CAD["concrete"] if kind in ("mong_don", "mong_coc") else ("#38BDF8" if kind == "mong_bang" else "#60A5FA"))
        if not is_sel:
            stroke_col = "#475569"

        poly = wi.get("poly")
        p0 = wi.get("p0")
        p1 = wi.get("p1")
        if poly and len(poly) >= 3:
            pts = [(float(p[0]), -float(p[1])) for p in poly]
            sb.polygon(pts, stroke=stroke_col, fill="#0D2230" if is_act else None, width=6.0 if is_act else 4.0, layer="DCE_BaoBeTong")
            xs = [pt[0] for pt in pts]
            ys = [pt[1] for pt in pts]
            half_diag = 0.5 * math.hypot(max(xs) - min(xs), max(ys) - min(ys))
            mid_x = (min(xs) + max(xs)) / 2.0
            mid_y = (min(ys) + max(ys)) / 2.0
        elif p0 and p1 and kind in ("dam_mong", "mong_bang"):
            x0, y0 = float(p0[0]), -float(p0[1])
            x1, y1 = float(p1[0]), -float(p1[1])
            dx, dy = x1 - x0, y1 - y0
            ln = math.hypot(dx, dy) or 1.0
            nx, ny = -dy / ln * (bw / 2.0), dx / ln * (bw / 2.0)
            pts = [(x0 + nx, y0 + ny), (x1 + nx, y1 + ny), (x1 - nx, y1 - ny), (x0 - nx, y0 - ny)]
            sb.polygon(pts, stroke=stroke_col, fill="#0D2230" if is_act else None, width=6.0 if is_act else 4.0, layer="DCE_BaoBeTong")
            mid_x = (x0 + x1) / 2.0
            mid_y = (y0 + y1) / 2.0
            half_diag = 0.5 * math.hypot(ln, bw)
        else:
            # Oriented rectangle from (cx, cy, B, L, ang)
            ca, sa = math.cos(-ang), math.sin(-ang)
            hw, hh = bw / 2.0, bl / 2.0
            corners = [(-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh)]
            pts = [(cx + ux * ca - uy * sa, cy + ux * sa + uy * ca) for (ux, uy) in corners]
            sb.polygon(pts, stroke=stroke_col, fill="#0D2230" if is_act else None, width=6.0 if is_act else 4.0, layer="DCE_BaoBeTong")
            mid_x, mid_y = cx, cy
            half_diag = 0.5 * math.hypot(bw, bl)

        # RED CIRCLE HIGHLIGHT around every scanned foundation & beam
        if is_sel:
            red_r = max(380.0, half_diag + ring_pad)
            if is_act:
                sb.circle(mid_x, mid_y, red_r, stroke=CAD["highlightBright"], fill=None, width=9.0, layer="DCE_Highlight")
                sb.circle(mid_x, mid_y, red_r + ring_pad * 0.45, stroke=CAD["highlightRed"], fill=None, width=5.5, layer="DCE_Highlight", dash=(120, 60))
                sb.line(mid_x - red_r * 0.25, mid_y, mid_x + red_r * 0.25, mid_y, CAD["highlightBright"], 4.0, "DCE_Highlight")
                sb.line(mid_x, mid_y - red_r * 0.25, mid_x, mid_y + red_r * 0.25, CAD["highlightBright"], 4.0, "DCE_Highlight")
            else:
                sb.circle(mid_x, mid_y, red_r, stroke=CAD["highlightRed"], fill=None, width=6.0, layer="DCE_Highlight")

        lbl_col = "#FACC15" if is_act else ("#FCA5A5" if is_sel else "#64748B")
        sb.text(mid_x, mid_y - font_sz * 0.15, inst["ten"], lbl_col, font_sz * (1.15 if is_act else 0.95), "middle", "DCE_Block", bold=True)

    # Map Header / Legend outside bounding box
    res = sb.build_result()
    bx0, by0, bx1, by1 = res["bounds"]
    pad = max(350.0, plan_scale * 0.04)
    sb.rect(bx0 - pad, by0 - pad * 1.4, (bx1 - bx0) + 2 * pad, (by1 - by0) + 2.4 * pad, stroke=CAD["frame"], fill=None, width=5.0, layer="DCE_Khung")
    sb.text((bx0 + bx1) / 2.0, by0 - pad * 0.7, "MẶT BẰNG ĐỊNH VỊ MÓNG & DẦM TRONG MODEL (KHOANH ĐỎ CẤU KIỆN ĐÃ QUÉT)", "#FFFFFF", font_sz * 1.15, "middle", "DCE_Block", bold=True)
    return sb.build_result()


def build_cad_scene(module, items, active_id, view_mode, layers, all_module_lists=None):
    """Build complete scene dict for the active module & view mode."""
    if view_mode == "model_map":
        mod_lists = all_module_lists or {module: items}
        return build_model_map_scene(mod_lists, module, active_id, layers)

    sb = SceneBuilder(layers)
    active = None
    for it in items:
        if it["id"] == active_id:
            active = it
            break
    if active is None and items:
        active = items[0]
    if active is None:
        return sb.build_result()

    if module == "mong_don":
        if view_mode == "all":
            cur_x = 0.0
            for it in items:
                half_b = float(it["B"]) / 2.0
                ox = cur_x + half_b + 1100.0
                _draw_single_footing(sb, it, "sheet", ox=ox)
                cur_x = ox + half_b + 1600.0
        else:
            _draw_single_footing(sb, active, view_mode, ox=0.0)
    elif module == "mong_bang":
        if view_mode == "all_strip":
            cur_x = 0.0
            for it in items:
                comp = compute_strip_footing(it)
                ox = cur_x + 1400.0
                _draw_strip_footing(sb, it, "sheet", ox=ox)
                cur_x = ox + float(comp["tongL"]) + 1500.0
        else:
            _draw_strip_footing(sb, active, view_mode, ox=0.0)
    elif module == "mong_coc":
        if view_mode == "all":
            cur_x = 0.0
            for it in items:
                half_b = float(it["B"]) / 2.0
                ox = cur_x + half_b + 1200.0
                _draw_pile_cap(sb, it, "sheet", ox=ox)
                cur_x = ox + half_b + 1500.0
        else:
            _draw_pile_cap(sb, active, view_mode, ox=0.0)
    elif module == "dam_mong":
        if view_mode == "all_strip":
            cur_x = 0.0
            for it in items:
                comp = compute_foundation_beam(it)
                ox = cur_x + 1100.0
                _draw_foundation_beam(sb, it, "sheet", ox=ox)
                cur_x = ox + float(comp["tongL"]) + 1300.0
        else:
            _draw_foundation_beam(sb, active, view_mode, ox=0.0)

    return sb.build_result()


# ==================== WPF CANVAS VECTOR RENDERER (CPython 3 SAFE) ====================

def render_scene_to_wpf_canvas(canvas, scene, zoom=1.0, pan_x=0.0, pan_y=0.0):
    """
    Render scene primitives directly onto a System.Windows.Controls.Canvas.
    All numeric values are explicitly cast to Python float() for pythonnet 3.x compatibility.
    Returns (s, ox, oy) for mouse coordinate readout.
    """
    from System.Windows import FontWeights, Point
    from System.Windows.Controls import Canvas, TextBlock
    from System.Windows.Media import BrushConverter, DoubleCollection, FontFamily, PointCollection, RotateTransform
    from System.Windows.Shapes import Ellipse, Line, Polygon, Polyline, Rectangle

    canvas.Children.Clear()
    cw = float(canvas.ActualWidth) if canvas.ActualWidth and float(canvas.ActualWidth) > 20.0 else 860.0
    ch = float(canvas.ActualHeight) if canvas.ActualHeight and float(canvas.ActualHeight) > 20.0 else 640.0

    min_x, min_y, max_x, max_y = scene["bounds"]
    world_w = max(400.0, max_x - min_x)
    world_h = max(400.0, max_y - min_y)
    pad = 28.0
    base_scale = min((cw - 2.0 * pad) / world_w, (ch - 2.0 * pad) / world_h)
    s = float(base_scale * zoom)
    cx_w = (min_x + max_x) / 2.0
    cy_w = (min_y + max_y) / 2.0
    ox = cw / 2.0 + float(pan_x) - cx_w * s
    oy = ch / 2.0 + float(pan_y) - cy_w * s

    brush_cache = {}
    conv = BrushConverter()

    def get_brush(hex_str):
        if not hex_str:
            return None
        b = brush_cache.get(hex_str)
        if b is None:
            b = conv.ConvertFromString(hex_str)
            if b.CanFreeze:
                b.Freeze()
            brush_cache[hex_str] = b
        return b

    # Background CAD minor grid
    grid_brush = get_brush("#1B212C")
    grid_step_w = 1000.0 if (world_w > 4500.0) else 400.0
    step_px = grid_step_w * s
    if step_px >= 14.0:
        gx0 = math.floor((-ox) / step_px) * step_px + ox
        while gx0 < cw:
            gl = Line()
            gl.X1 = float(gx0)
            gl.Y1 = float(0.0)
            gl.X2 = float(gx0)
            gl.Y2 = float(ch)
            gl.Stroke = grid_brush
            gl.StrokeThickness = float(0.8)
            canvas.Children.Add(gl)
            gx0 += step_px
        gy0 = math.floor((-oy) / step_px) * step_px + oy
        while gy0 < ch:
            gl = Line()
            gl.X1 = float(0.0)
            gl.Y1 = float(gy0)
            gl.X2 = float(cw)
            gl.Y2 = float(gy0)
            gl.Stroke = grid_brush
            gl.StrokeThickness = float(0.8)
            canvas.Children.Add(gl)
            gy0 += step_px

    mono_font = FontFamily("Consolas")
    sans_font = FontFamily("Segoe UI")

    for prim in scene.get("primitives", []):
        kind = prim["kind"]
        stroke_b = get_brush(prim.get("color"))
        fill_b = get_brush(prim.get("fill"))
        sw = max(0.9, float(prim.get("width", 3.0)) * s * 0.62)
        dash_vals = prim.get("dash")

        if kind == "line":
            el = Line()
            el.X1 = float(ox + prim["x1"] * s)
            el.Y1 = float(oy + prim["y1"] * s)
            el.X2 = float(ox + prim["x2"] * s)
            el.Y2 = float(oy + prim["y2"] * s)
            el.Stroke = stroke_b
            el.StrokeThickness = float(sw)
            if dash_vals:
                dc = DoubleCollection()
                for dv in dash_vals:
                    dc.Add(float(max(2.0, dv * s / max(0.8, sw))))
                el.StrokeDashArray = dc
            canvas.Children.Add(el)

        elif kind == "rect":
            rw = float(prim["w"]) * s
            rh = float(prim["h"]) * s
            if rw <= 0.1 or rh <= 0.1:
                continue
            el = Rectangle()
            el.Width = float(rw)
            el.Height = float(rh)
            if stroke_b is not None:
                el.Stroke = stroke_b
                el.StrokeThickness = float(sw)
            if fill_b is not None:
                el.Fill = fill_b
            if dash_vals:
                dc = DoubleCollection()
                for dv in dash_vals:
                    dc.Add(float(max(2.0, dv * s / max(0.8, sw))))
                el.StrokeDashArray = dc
            Canvas.SetLeft(el, float(ox + prim["x"] * s))
            Canvas.SetTop(el, float(oy + prim["y"] * s))
            canvas.Children.Add(el)

        elif kind in ("polygon", "polyline"):
            pc = PointCollection()
            for px, py in prim["pts"]:
                pc.Add(Point(float(ox + px * s), float(oy + py * s)))
            if kind == "polygon":
                el = Polygon()
                el.Points = pc
                if stroke_b is not None:
                    el.Stroke = stroke_b
                    el.StrokeThickness = float(sw)
                if fill_b is not None:
                    el.Fill = fill_b
                canvas.Children.Add(el)
            else:
                el = Polyline()
                el.Points = pc
                el.Stroke = stroke_b
                el.StrokeThickness = float(sw)
                canvas.Children.Add(el)

        elif kind == "circle":
            rad = max(1.2, float(prim["r"]) * s)
            el = Ellipse()
            el.Width = float(rad * 2.0)
            el.Height = float(rad * 2.0)
            if stroke_b is not None:
                el.Stroke = stroke_b
                el.StrokeThickness = float(sw)
            if fill_b is not None:
                el.Fill = fill_b
            if dash_vals:
                dc = DoubleCollection()
                for dv in dash_vals:
                    dc.Add(float(max(2.0, dv * s / max(0.8, sw))))
                el.StrokeDashArray = dc
            Canvas.SetLeft(el, float(ox + prim["cx"] * s - rad))
            Canvas.SetTop(el, float(oy + prim["cy"] * s - rad))
            canvas.Children.Add(el)

        elif kind == "text":
            fs = float(prim["size"]) * s * 0.92
            if fs < 5.0:
                continue
            tb = TextBlock()
            tb.Text = str(prim["text"])
            tb.Foreground = stroke_b if stroke_b is not None else get_brush("#E2E8F0")
            tb.FontSize = float(min(36.0, fs))
            tb.FontFamily = sans_font if prim["size"] >= 70.0 else mono_font
            if prim.get("bold"):
                tb.FontWeight = FontWeights.SemiBold
            tx = float(ox + prim["x"] * s)
            ty = float(oy + prim["y"] * s)
            est_w = len(tb.Text) * tb.FontSize * 0.58
            rot = float(prim.get("rotate", 0.0))
            if abs(rot) > 1.0:
                # Rotate around world anchor point cleanly
                tb.RenderTransform = RotateTransform(rot)
                Canvas.SetLeft(tb, float(tx - tb.FontSize * 0.6))
                Canvas.SetTop(tb, float(ty))
            else:
                anchor = prim.get("anchor", "middle")
                if anchor == "middle":
                    tx -= est_w / 2.0
                elif anchor == "end":
                    tx -= est_w
                Canvas.SetLeft(tb, float(tx))
                Canvas.SetTop(tb, float(ty - tb.FontSize * 0.68))
            canvas.Children.Add(tb)

    return s, ox, oy
