# -*- coding: utf-8 -*-
"""
DXF Plan, DcePro XDATA, and mong2 JSON scanner (ported from dxfPlanScanner.ts).
Supports:
- mong2 JSON (object or array)
- DcePro XDATA (\u221e delimiter) inside DXF or raw lines
- Full ASCII DXF plan geometry (LWPOLYLINE + bulge, POLYLINE, LINE loop tracing,
  parallel line pairs, CIRCLE, INSERT/BLOCK/ATTRIB, TEXT/MTEXT, arbitrary rotated polygons)
"""

import json
import math
import re
import time
import unicodedata

from poly_geom import (
    center_polygon,
    clean_polygon,
    is_rect_poly,
    min_area_rect,
    parse_polygon_string,
    point_in_polygon,
    polygon_area,
)


def _round5(v):
    return int(round(float(v) / 5.0) * 5)


def _clean_dxf_text(raw):
    if not raw:
        return ""
    s = str(raw)
    s = s.replace("\\P", " ").replace("\\~", " ")
    s = re.sub(r"%%[cC]", "Ø", s)
    s = re.sub(r"\\U\+2205", "Ø", s, flags=re.IGNORECASE)
    s = re.sub(r"\{\\[^;]*;", "", s)
    s = s.replace("{", "").replace("}", "")
    s = re.sub(r"\\[A-Za-z][^;]*;", "", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _strip_diacritics(text):
    if not text:
        return ""
    nfd = unicodedata.normalize("NFD", str(text))
    stripped = "".join(ch for ch in nfd if unicodedata.category(ch) != "Mn")
    return stripped.replace("đ", "d").replace("Đ", "D")


def _parse_rebar_spec(text, fallback_d, fallback_a):
    m = re.search(r"(\d+)\s*[a@]\s*(\d+)", str(text), re.IGNORECASE)
    if m:
        return {"d": int(m.group(1)) or fallback_d, "a": int(m.group(2)) or fallback_a}
    return {"d": fallback_d, "a": fallback_a}


def _parse_bar_count_diam(text, fallback_n, fallback_d):
    m = re.search(r"(\d+)\s*[TØDdΦφø]\s*(\d+)", str(text), re.IGNORECASE)
    if m:
        return {"n": int(m.group(1)) or fallback_n, "d": int(m.group(2)) or fallback_d}
    return {"n": fallback_n, "d": fallback_d}


def _parse_z_meters(val, fallback):
    try:
        n = float(val)
    except (TypeError, ValueError):
        return fallback
    if not math.isfinite(n):
        return fallback
    return round(n / 1000.0, 3) if abs(n) > 40 else round(n, 3)


def _make_bbox(pts):
    if not pts:
        return {"minX": 0.0, "minY": 0.0, "maxX": 0.0, "maxY": 0.0, "w": 0.0, "h": 0.0, "cx": 0.0, "cy": 0.0}
    xs = [p["x"] for p in pts]
    ys = [p["y"] for p in pts]
    min_x, max_x = min(xs), max(xs)
    min_y, max_y = min(ys), max(ys)
    return {
        "minX": min_x,
        "minY": min_y,
        "maxX": max_x,
        "maxY": max_y,
        "w": max_x - min_x,
        "h": max_y - min_y,
        "cx": (min_x + max_x) / 2.0,
        "cy": (min_y + max_y) / 2.0,
    }


def _safe_float(val, default=0.0):
    try:
        n = float(val)
        return n if math.isfinite(n) else default
    except (TypeError, ValueError):
        return default


def _safe_int(val, default=0):
    try:
        return int(float(val))
    except (TypeError, ValueError):
        return default


# ==================== 1. JSON (mong2 & simple arrays) PARSER ====================

def _parse_mong2_json(raw, defaults):
    trimmed = raw.strip()
    if not (trimmed.startswith("{") or trimmed.startswith("[")):
        return None
    try:
        parsed = json.loads(trimmed)
    except Exception:
        return None

    candidates = []
    messages = []

    thep_rows = {}
    if isinstance(parsed, dict) and isinstance(parsed.get("Thep"), list):
        for r in parsed["Thep"]:
            k = "%s::%s" % (r.get("Loai", ""), r.get("Ten", ""))
            thep_rows.setdefault(k, []).append(r)

    cots_by_owner = {}
    if isinstance(parsed, dict) and isinstance(parsed.get("Cot"), list):
        for c in parsed["Cot"]:
            key = "%s::%s" % (c.get("LoaiMong", ""), c.get("ThuocId") or c.get("ThuocMong") or "")
            cots_by_owner.setdefault(key, []).append(c)

    coc_by_dai = {}
    if isinstance(parsed, dict) and isinstance(parsed.get("Coc"), list):
        for p in parsed["Coc"]:
            key = str(p.get("ThuocId") or p.get("ThuocDai") or "")
            coc_by_dai.setdefault(key, []).append(p)

    def get_thep_row(loai, ten, vitri):
        for r in thep_rows.get("%s::%s" % (loai, ten), []):
            if r.get("ViTri") == vitri:
                return r
        return None

    def read_lop_bv(rows, fallback):
        for r in rows:
            bv = _safe_float(r.get("LopBV"), -1.0)
            if bv > 0:
                return int(round(bv))
        return fallback

    if isinstance(parsed, list):
        for idx, item in enumerate(parsed):
            if not isinstance(item, dict):
                continue
            ten = str(item.get("ten") or item.get("Ten") or item.get("Mark") or ("MĐ%d" % (idx + 1)))
            raw_ten = ten.strip().upper()
            norm_ten = _strip_diacritics(ten).upper()
            kind = "mong_don"
            if (
                _safe_int(item.get("SoCoc"), 0) > 0
                or raw_ten.startswith(("ĐM", "ĐC"))
                or norm_ten.startswith(("MC", "DC", "PC"))
                or (norm_ten.startswith("DM") and _safe_float(item.get("B"), 0) >= 800)
            ):
                kind = "mong_coc"
            elif norm_ten.startswith("MB"):
                kind = "mong_bang"
            elif item.get("NoiDai") or norm_ten.startswith(("GM", "GD", "DM")):
                kind = "dam_mong"

            parsed_poly = parse_polygon_string(item.get("BienDang") or item.get("customPolygon"))
            centered = center_polygon(parsed_poly) if len(parsed_poly) >= 3 else None
            custom_polygon = centered["poly"] if (centered and not is_rect_poly(centered["poly"])) else None

            B = centered["B"] if centered else (_safe_int(item.get("B"), 1500) or 1500)
            L = centered["L"] if centered else (_safe_int(item.get("L") or item.get("Dai"), 1500) or 1500)
            H = _safe_int(item.get("H"), defaults["cocH"] if kind == "mong_coc" else defaults["donH"]) or 400
            cot_b = _safe_int(item.get("cotB"), 200) or 200
            cot_h = _safe_int(item.get("cotH"), 200) or 200
            dat_x = _safe_int(item.get("lechTamX") or item.get("DatX"), 0)
            dat_y = _safe_int(item.get("lechTamY") or item.get("DatY"), 0)
            goc_xoay = _safe_float(item.get("gocXoay") or item.get("Goc"), 0.0) or None
            is_top_flush = item.get("viTriCotMode") == "top_flush" or (
                not custom_polygon and abs(dat_y - (L / 2.0 - cot_h / 2.0)) < 10
            )
            mode = "top_flush" if is_top_flush else ("custom" if (dat_x != 0 or dat_y != 0) else "center")

            candidates.append({
                "id": "json-%d" % idx,
                "selected": True,
                "kind": kind,
                "ten": ten,
                "soLuong": _safe_int(item.get("soLuong") or item.get("SL"), 1) or 1,
                "B": B,
                "L": L,
                "H": H,
                "hMep": _safe_int(item.get("hMep"), min(200, int(round(H / 2.0)))),
                "caoTrinh": _parse_z_meters(item.get("caoTrinhDay") or item.get("ZDay"), defaults["caoTrinhDefault"]),
                "shapePreset": "custom" if custom_polygon else None,
                "customPolygon": custom_polygon,
                "gocXoay": goc_xoay,
                "cotB": cot_b,
                "cotH": cot_h,
                "viTriCotMode": mode,
                "lechTamX": dat_x,
                "lechTamY": dat_y,
                "sourceType": "mong2_json",
                "summary": "JSON (%s×%s×%s%s)" % (
                    B, L, H, (" · %d đỉnh" % len(custom_polygon)) if custom_polygon else ""
                ),
                "warnings": [],
            })

        return {
            "candidates": candidates,
            "detectedFormat": "mong2_json",
            "detectedUnit": "mm",
            "unitScaleToMm": 1,
            "stats": {"polys": 0, "lines": 0, "circles": 0, "inserts": 0, "texts": 0, "xdataRecords": len(candidates)},
            "messages": ["Đã đọc %d cấu kiện từ JSON." % len(candidates)],
        }

    if not isinstance(parsed, dict):
        return None

    # 1) MongDon
    don_groups = {}
    for r in parsed.get("MongDon") or []:
        if r.get("Chon") in (0, False):
            continue
        ten = str(r.get("Ten") or r.get("Mark") or "MĐ1")
        don_groups.setdefault(ten, []).append(r)

    for ten, grp in don_groups.items():
        r = grp[0]
        parsed_poly = parse_polygon_string(r.get("BienDang") or r.get("customPolygon"))
        centered = center_polygon(parsed_poly) if len(parsed_poly) >= 3 else None
        custom_polygon = centered["poly"] if (centered and not is_rect_poly(centered["poly"])) else None
        B = _round5(centered["B"] if centered else (_safe_float(r.get("B"), 1500) or 1500))
        L = _round5(centered["L"] if centered else (_safe_float(r.get("L"), 1500) or 1500))
        H = _round5(_safe_float(r.get("H"), defaults["donH"]) or defaults["donH"])
        id_key = "MongDon::%s" % (r.get("ElementId") or ten)
        cots = cots_by_owner.get(id_key) or cots_by_owner.get("MongDon::%s" % ten) or []
        cot0 = cots[0] if cots else {}
        cot_b = _round5(_safe_float(cot0.get("B"), defaults["donCotB"]) or defaults["donCotB"]) or 200
        cot_h = _round5(_safe_float(cot0.get("H"), defaults["donCotH"]) or defaults["donCotH"]) or 200
        dat_x = int(round(_safe_float(cot0.get("X", r.get("DatX", 0)))))
        dat_y = int(round(_safe_float(cot0.get("Y", r.get("DatY", 0)))))
        goc_xoay = _safe_float(r.get("Goc") or r.get("gocXoay"), 0.0) or None
        extra_cols = [
            {
                "id": "ext-col-%d" % (ci + 1),
                "x": int(round(_safe_float(c.get("X"), 0))),
                "y": int(round(_safe_float(c.get("Y"), 0))),
                "b": _round5(_safe_float(c.get("B"), cot_b)) or 200,
                "h": _round5(_safe_float(c.get("H"), cot_h)) or 200,
            }
            for ci, c in enumerate(cots[1:])
        ]
        is_top_flush = (not custom_polygon) and abs(dat_y - (L / 2.0 - cot_h / 2.0)) < 25
        mode = "top_flush" if is_top_flush else ("custom" if (dat_x != 0 or dat_y != 0) else "center")

        rows = thep_rows.get("MongDon::%s" % ten, [])
        rx = get_thep_row("MongDon", ten, "DayX")
        ry = get_thep_row("MongDon", ten, "DayY")
        bv = read_lop_bv(rows, defaults["coverDay"])

        exp_don = {}
        if rx:
            exp_don["thepPhuongX"] = {
                "d": _safe_int(rx.get("D"), defaults["donD"]) or defaults["donD"],
                "a": _safe_int(rx.get("A"), defaults["donA"]) or defaults["donA"],
                "hasHook": defaults["donHook"],
                "hookLen": defaults["donHookLen"],
            }
        if ry:
            exp_don["thepPhuongY"] = {
                "d": _safe_int(ry.get("D"), defaults["donD"]) or defaults["donD"],
                "a": _safe_int(ry.get("A"), defaults["donA"]) or defaults["donA"],
                "hasHook": defaults["donHook"],
                "hookLen": defaults["donHookLen"],
            }

        candidates.append({
            "id": "m2-don-%s" % ten,
            "selected": True,
            "kind": "mong_don",
            "ten": ten,
            "soLuong": len(grp),
            "B": B,
            "L": L,
            "H": H,
            "hMep": min(200, int(round(H / 2.0))),
            "caoTrinh": _parse_z_meters(r.get("ZDay"), defaults["caoTrinhDefault"]),
            "shapePreset": "custom" if custom_polygon else None,
            "customPolygon": custom_polygon,
            "gocXoay": goc_xoay,
            "extraColumns": extra_cols if extra_cols else None,
            "cotB": cot_b,
            "cotH": cot_h,
            "viTriCotMode": mode,
            "lechTamX": dat_x,
            "lechTamY": dat_y,
            "explicitCoverDay": bv,
            "explicitCoverCanh": bv,
            "explicitDon": exp_don,
            "sourceType": "mong2_json",
            "summary": "mong2 MongDon · %s×%s×%s · %d cột%s" % (
                B, L, H, max(1, len(cots)), (" · %d đỉnh" % len(custom_polygon)) if custom_polygon else ""
            ),
            "warnings": [str(r["CanhBao"])] if r.get("CanhBao") else [],
        })

    # 2) DaiMong + Coc
    dai_groups = {}
    for r in parsed.get("DaiMong") or []:
        if r.get("Chon") in (0, False):
            continue
        ten = str(r.get("Ten") or r.get("Mark") or "ĐM1")
        dai_groups.setdefault(ten, []).append(r)

    for ten, grp in dai_groups.items():
        r = grp[0]
        parsed_poly = parse_polygon_string(r.get("BienDang") or r.get("customPolygon"))
        centered = center_polygon(parsed_poly) if len(parsed_poly) >= 3 else None
        custom_polygon = centered["poly"] if (centered and not is_rect_poly(centered["poly"])) else None

        B = _round5(centered["B"] if centered else (_safe_float(r.get("B"), 1400) or 1400))
        L = _round5(centered["L"] if centered else (_safe_float(r.get("L"), 1400) or 1400))
        H = _round5(_safe_float(r.get("H"), defaults["cocH"]) or defaults["cocH"])
        eid = str(r.get("ElementId") or ten)
        piles = coc_by_dai.get(eid) or coc_by_dai.get(ten) or []
        cots = cots_by_owner.get("DaiMong::%s" % eid) or cots_by_owner.get("DaiMong::%s" % ten) or []
        cot0 = cots[0] if cots else {}
        cot_b = _round5(_safe_float(cot0.get("B"), 300) or 300) or 300
        cot_h = _round5(_safe_float(cot0.get("H"), 220) or 220) or 220
        dat_x = int(round(_safe_float(cot0.get("X", r.get("DatX", 0)))))
        dat_y = int(round(_safe_float(cot0.get("Y", r.get("DatY", 0)))))
        goc_xoay = _safe_float(r.get("Goc") or r.get("gocXoay"), 0.0) or None
        extra_cols = [
            {
                "id": "ext-col-%d" % (ci + 1),
                "x": int(round(_safe_float(c.get("X"), 0))),
                "y": int(round(_safe_float(c.get("Y"), 0))),
                "b": _round5(_safe_float(c.get("B"), cot_b)) or 300,
                "h": _round5(_safe_float(c.get("H"), cot_h)) or 220,
            }
            for ci, c in enumerate(cots[1:])
        ]
        is_top_flush = (not custom_polygon) and abs(dat_y - (L / 2.0 - cot_h / 2.0)) < 25
        mode = "top_flush" if is_top_flush else ("custom" if (dat_x != 0 or dat_y != 0) else "center")

        xs = sorted(set(int(round(_safe_float(p.get("X")) / 25.0) * 25) for p in piles))
        ys = sorted(set(int(round(_safe_float(p.get("Y")) / 25.0) * 25) for p in piles))
        so_coc_raw = _safe_int(r.get("SoCoc"), 0)
        so_coc_x = max(1, len(xs) or (2 if so_coc_raw >= 4 else (so_coc_raw or 2)))
        so_coc_y = max(1, len(ys) or (2 if so_coc_raw >= 4 else 1))
        buoc_coc_x = _round5((xs[-1] - xs[0]) / (len(xs) - 1)) if len(xs) > 1 else 600
        buoc_coc_y = _round5((ys[-1] - ys[0]) / (len(ys) - 1)) if len(ys) > 1 else 600
        is_grid_regular = (
            len(piles) > 0 and (len(xs) * len(ys) == len(piles)) and len(piles) not in (3, 5)
        )
        custom_piles = None
        if len(piles) > 0 and not is_grid_regular:
            custom_piles = [
                {
                    "id": "p-%d" % (pi + 1),
                    "x": int(round(_safe_float(p.get("X"), 0))),
                    "y": int(round(_safe_float(p.get("Y"), 0))),
                    "d": _round5(_safe_float(p.get("D"))) if _safe_float(p.get("D")) > 0 else None,
                }
                for pi, p in enumerate(piles)
            ]
        coc_d = _round5(_safe_float(piles[0].get("D"), defaults["cocDDefault"]) or defaults["cocDDefault"]) if piles else defaults["cocDDefault"]
        hd0 = str(piles[0].get("HinhDang", "")).lower() if piles else ""
        if piles:
            coc_hinh = "square" if ("vuông" in hd0 or "vuong" in hd0 or "square" in hd0) else "circle"
        else:
            coc_hinh = defaults["cocShapeDefault"]

        rows = thep_rows.get("DaiMong::%s" % ten, [])
        bx = get_thep_row("DaiMong", ten, "DayX")
        by = get_thep_row("DaiMong", ten, "DayY")
        tx = get_thep_row("DaiMong", ten, "TrenX")
        ty = get_thep_row("DaiMong", ten, "TrenY")
        vach = get_thep_row("DaiMong", ten, "DaiBo")
        bv = read_lop_bv(rows, defaults["coverCanh"])

        exp_coc = {}
        if bx:
            exp_coc["thepDuoiX"] = {"d": _safe_int(bx.get("D"), 12) or 12, "a": _safe_int(bx.get("A"), 200) or 200}
        if by:
            exp_coc["thepDuoiY"] = {"d": _safe_int(by.get("D"), 12) or 12, "a": _safe_int(by.get("A"), 200) or 200}
        if tx:
            exp_coc["thepTrenX"] = {"d": _safe_int(tx.get("D"), 12) or 12, "a": _safe_int(tx.get("A"), 200) or 200}
        if ty:
            exp_coc["thepTrenY"] = {"d": _safe_int(ty.get("D"), 12) or 12, "a": _safe_int(ty.get("A"), 200) or 200}
        if vach:
            exp_coc["thepVach"] = {"d": _safe_int(vach.get("D"), 12) or 12, "a": _safe_int(vach.get("A"), 250) or 250}

        pile_desc = ("%d cọc tự do" % len(custom_piles)) if custom_piles else ("%d×%d cọc" % (so_coc_x, so_coc_y))
        candidates.append({
            "id": "m2-coc-%s" % ten,
            "selected": True,
            "kind": "mong_coc",
            "ten": ten,
            "soLuong": len(grp),
            "B": B,
            "L": L,
            "H": H,
            "caoTrinh": _parse_z_meters(r.get("ZDinh") or r.get("ZDay"), -0.5),
            "shapePreset": "custom" if custom_polygon else None,
            "customPolygon": custom_polygon,
            "customPiles": custom_piles,
            "gocXoay": goc_xoay,
            "extraColumns": extra_cols if extra_cols else None,
            "cotB": cot_b,
            "cotH": cot_h,
            "viTriCotMode": mode,
            "lechTamX": dat_x,
            "lechTamY": dat_y,
            "cocD": coc_d,
            "cocHinh": coc_hinh,
            "soCocX": so_coc_x,
            "soCocY": so_coc_y,
            "buocCocX": buoc_coc_x,
            "buocCocY": buoc_coc_y,
            "explicitCoverCanh": bv,
            "explicitCoc": exp_coc,
            "sourceType": "mong2_json",
            "summary": "mong2 DaiMong · %s×%s×%s · %s %s%s" % (
                B, L, H, pile_desc, coc_d, (" · %d đỉnh" % len(custom_polygon)) if custom_polygon else ""
            ),
            "warnings": [str(r["CanhBao"])] if r.get("CanhBao") else [],
        })

    # 3) MongBang
    bang_groups = {}
    for r in parsed.get("MongBang") or []:
        if r.get("Chon") in (0, False):
            continue
        nhom = str(r.get("Nhom") or r.get("Mark") or "MB1")
        bang_groups.setdefault(nhom, []).append(r)

    for nhom, grp in bang_groups.items():
        r0 = grp[0]
        total_b = _round5(_safe_float(r0.get("B"), 1400) or 1400)
        H = _round5(_safe_float(r0.get("H"), defaults["bangHDam"]) or defaults["bangHDam"])
        total_len = int(round(sum(_safe_float(seg.get("Dai"), 0) for seg in grp))) or 9000
        b_dam = min(defaults["bangBDam"], total_b)
        lech_tam = _safe_float(r0.get("LechTam"), 0)
        canh_trai = max(0, int(round((total_b - b_dam) / 2.0 - lech_tam)))
        canh_phai = max(0, total_b - b_dam - canh_trai)
        if abs(canh_trai) < 50:
            canh_phai = max(0, total_b - b_dam)
            canh_trai = 0

        if len(grp) > 1:
            spans = [max(1200, int(round((_safe_float(s.get("Dai"), 4000) or 4000) - 300))) for s in grp]
        else:
            half_sp = int(round((total_len - 900) / 2.0))
            spans = [half_sp, half_sp]

        rows = thep_rows.get("MongBang::%s" % nhom, [])
        r_top = get_thep_row("MongBang", nhom, "BangTren")
        r_bot = get_thep_row("MongBang", nhom, "BangDuoi")
        r_skin = get_thep_row("MongBang", nhom, "BangChongPhinh")
        r_stir = get_thep_row("MongBang", nhom, "BangDai")
        r_wing = get_thep_row("MongBang", nhom, "BangCanh")
        bv = read_lop_bv(rows, defaults["coverDamBang"])

        candidates.append({
            "id": "m2-bang-%s" % nhom,
            "selected": True,
            "kind": "mong_bang",
            "ten": nhom,
            "soLuong": 1,
            "B": total_b,
            "L": total_len,
            "H": H,
            "hMep": defaults["bangHMep"],
            "hVat": defaults["bangHVat"],
            "caoTrinh": _parse_z_meters(r0.get("ZDinh"), -0.5),
            "cotB": 300,
            "cotH": 300,
            "viTriCotMode": "center",
            "lechTamX": 0,
            "lechTamY": 0,
            "B_dam": b_dam,
            "canhTrai": canh_trai,
            "canhPhai": canh_phai,
            "spans": spans,
            "explicitCoverDam": bv,
            "explicitBang": {
                "thepTrenCount": _safe_int(r_top.get("SoThanh"), defaults["bangTrenN"]) if r_top else defaults["bangTrenN"],
                "thepTrenD": _safe_int(r_top.get("D"), defaults["bangTrenD"]) if r_top else defaults["bangTrenD"],
                "thepDuoiCount": _safe_int(r_bot.get("SoThanh"), defaults["bangDuoiN"]) if r_bot else defaults["bangDuoiN"],
                "thepDuoiD": _safe_int(r_bot.get("D"), defaults["bangDuoiD"]) if r_bot else defaults["bangDuoiD"],
                "thepGiaCount": _safe_int(r_skin.get("SoThanh"), defaults["bangGiaN"]) if r_skin else defaults["bangGiaN"],
                "thepGiaD": _safe_int(r_skin.get("D"), defaults["bangGiaD"]) if r_skin else defaults["bangGiaD"],
                "thepDaiD": _safe_int(r_stir.get("D"), defaults["bangDaiD"]) if r_stir else defaults["bangDaiD"],
                "thepDaiA": _safe_int(r_stir.get("A"), defaults["bangDaiA"]) if r_stir else defaults["bangDaiA"],
                "thepNgangCanhD": _safe_int(r_wing.get("D"), defaults["bangNgangCanhD"]) if r_wing else defaults["bangNgangCanhD"],
                "thepNgangCanhA": _safe_int(r_wing.get("A"), defaults["bangNgangCanhA"]) if r_wing else defaults["bangNgangCanhA"],
            },
            "sourceType": "mong2_json",
            "summary": "mong2 MongBang · B=%s/%s/%s · H=%s · L=%s" % (b_dam, canh_trai, canh_phai, H, total_len),
            "warnings": [str(r0["CanhBao"])] if r0.get("CanhBao") else [],
        })

    # 4) DamMong
    dam_groups = {}
    for r in parsed.get("DamMong") or []:
        if r.get("Chon") in (0, False):
            continue
        ten = str(r.get("Ten") or r.get("Mark") or "DM1")
        dam_groups.setdefault(ten, []).append(r)

    for ten, grp in dam_groups.items():
        r0 = grp[0]
        B = _round5(_safe_float(r0.get("B"), defaults["damBDam"]) or defaults["damBDam"])
        H = _round5(_safe_float(r0.get("H"), defaults["damHDam"]) or defaults["damHDam"])
        dai = int(round(_safe_float(r0.get("Dai"), 5000) or 5000))

        rows = thep_rows.get("DamMong::%s" % ten, [])
        r_top = get_thep_row("DamMong", ten, "BangTren")
        r_top2 = get_thep_row("DamMong", ten, "BangTrenTC")
        r_bot = get_thep_row("DamMong", ten, "BangDuoi")
        r_skin = get_thep_row("DamMong", ten, "BangChongPhinh")
        r_stir1 = get_thep_row("DamMong", ten, "BangDai")
        r_stir2 = get_thep_row("DamMong", ten, "BangDaiNhip")
        r_stir_tc = get_thep_row("DamMong", ten, "BangDaiTC")
        bv = read_lop_bv(rows, defaults["coverDamBang"])

        sup_names = [s for s in re.split(r"\s*-\s*", str(r0.get("NoiDai") or "B - A")) if s]
        n_sups = max(2, len(sup_names))
        sup_len = 1400
        clear_total = max(1200, dai - n_sups * sup_len)
        span_each = int(round(clear_total / float(n_sups - 1)))

        candidates.append({
            "id": "m2-dam-%s" % ten,
            "selected": True,
            "kind": "dam_mong",
            "ten": ten,
            "soLuong": len(grp),
            "B": B,
            "L": dai,
            "H": H,
            "caoTrinh": _parse_z_meters(r0.get("ZDinh"), -0.5),
            "cotB": 400,
            "cotH": H,
            "viTriCotMode": "center",
            "lechTamX": 0,
            "lechTamY": 0,
            "B_dam": B,
            "supports": [
                {
                    "trucLabel": sup_names[i] if i < len(sup_names) else chr(65 + i),
                    "len": sup_len,
                    "colW": B,
                    "colH": min(700, H),
                }
                for i in range(n_sups)
            ],
            "spans": [span_each for _ in range(n_sups - 1)],
            "explicitCoverDam": bv,
            "explicitDam": {
                "thepTren1Count": _safe_int(r_top.get("SoThanh"), defaults["damTren1N"]) if r_top else defaults["damTren1N"],
                "thepTren1D": _safe_int(r_top.get("D"), defaults["damTren1D"]) if r_top else defaults["damTren1D"],
                "thepTren2Count": _safe_int(r_top2.get("SoThanh"), defaults["damTren2N"]) if r_top2 else defaults["damTren2N"],
                "thepTren2D": _safe_int(r_top2.get("D"), defaults["damTren2D"]) if r_top2 else defaults["damTren2D"],
                "thepDuoiCount": _safe_int(r_bot.get("SoThanh"), defaults["damDuoiN"]) if r_bot else defaults["damDuoiN"],
                "thepDuoiD": _safe_int(r_bot.get("D"), defaults["damDuoiD"]) if r_bot else defaults["damDuoiD"],
                "thepGiaCount": _safe_int(r_skin.get("SoThanh"), defaults["damGiaN"]) if r_skin else defaults["damGiaN"],
                "thepGiaD": _safe_int(r_skin.get("D"), defaults["damGiaD"]) if r_skin else defaults["damGiaD"],
                "thepDaiD": _safe_int(r_stir1.get("D"), defaults["damDaiD"]) if r_stir1 else defaults["damDaiD"],
                "thepDaiAGoi": _safe_int(r_stir1.get("A"), defaults["damDaiAGoi"]) if r_stir1 else defaults["damDaiAGoi"],
                "thepDaiANhip": _safe_int(r_stir2.get("A"), defaults["damDaiANhip"]) if r_stir2 else defaults["damDaiANhip"],
                "thepDaiCTrenD": _safe_int(r_stir_tc.get("D"), defaults["damDaiCTrenD"]) if r_stir_tc else defaults["damDaiCTrenD"],
                "thepDaiCTrenA": _safe_int(r_stir_tc.get("A"), defaults["damDaiCTrenA"]) if r_stir_tc else defaults["damDaiCTrenA"],
            },
            "sourceType": "mong2_json",
            "summary": "mong2 DamMong · %s×%s · L=%s · Gối %s" % (B, H, dai, "-".join(sup_names)),
            "warnings": [str(r0["CanhBao"])] if r0.get("CanhBao") else [],
        })

    messages.append(
        "Đã đọc dữ liệu mong2 JSON: %d Móng Đơn, %d Móng Băng, %d Móng Cọc, %d Dầm Móng."
        % (len(don_groups), len(bang_groups), len(dai_groups), len(dam_groups))
    )

    return {
        "candidates": candidates,
        "detectedFormat": "mong2_json",
        "detectedUnit": "mm",
        "unitScaleToMm": 1,
        "stats": {"polys": 0, "lines": 0, "circles": 0, "inserts": 0, "texts": 0, "xdataRecords": len(candidates)},
        "messages": messages,
    }


# ==================== 2. DCEPRO XDATA PARSER ====================

def _parse_dcepro_xdata_record(app_name, payload, extra_dong11=None, extra_dong12=None, idx=0):
    parts = [x.strip() for x in payload.split("\u221e")]
    non_empty = parts if (parts and parts[0]) else parts[1:]

    def get_p(arr, i, default=""):
        return arr[i] if i < len(arr) and arr[i] != "" else default

    if "MongDon" in app_name:
        p = [x.strip() for x in payload.strip().split("\u221e")]
        lot_parts = (get_p(p, 10, "100/50")).split("/")
        lot_day_str = lot_parts[0] if lot_parts else "100"
        lot_chia_str = lot_parts[1] if len(lot_parts) > 1 else "50"
        rx = _parse_rebar_spec(get_p(p, 13, "12a200"), 12, 200)
        ry = _parse_rebar_spec(get_p(p, 14, "12a200"), 12, 200)
        H = _safe_int(get_p(p, 4, "400"), 400) or 400
        h_mep = _safe_int(get_p(p, 5, "200"), 200) or 200
        return {
            "id": "xdata-don-%d" % idx,
            "selected": True,
            "kind": "mong_don",
            "ten": get_p(p, 0, "MĐ%d" % (idx + 1)).strip(),
            "soLuong": _safe_int(get_p(p, 1, "1"), 1) or 1,
            "B": 1500,
            "L": 1500,
            "H": H,
            "hMep": h_mep,
            "caoTrinh": _safe_float(get_p(p, 7, "-1.1"), -1.1),
            "cotB": 200,
            "cotH": 200,
            "viTriCotMode": "center",
            "lechTamX": 0,
            "lechTamY": 0,
            "explicitCoverDay": _safe_int(get_p(p, 8, "50"), 50) or 50,
            "explicitCoverCanh": _safe_int(get_p(p, 9, "50"), 50) or 50,
            "explicitLotDay": _safe_int(lot_day_str, 100) or 100,
            "explicitLotChiaMC": _safe_int(lot_chia_str, 50) or 50,
            "explicitDon": {
                "tiLe": _safe_int(get_p(p, 2, "25"), 25) or 25,
                "giangH": _safe_int(get_p(p, 11, "400"), 400) or 400,
                "caoTuDinhDaiDenMatGiang": _safe_int(get_p(p, 12, "650"), 650) or 650,
                "thepPhuongX": {"d": rx["d"], "a": rx["a"], "hasHook": False, "hookLen": 150},
                "thepPhuongY": {"d": ry["d"], "a": ry["a"], "hasHook": False, "hookLen": 150},
            },
            "sourceType": "dxf_xdata",
            "summary": "XDATA MongDon · H=%s · BV=%s/%s" % (H, get_p(p, 8, "50"), get_p(p, 9, "50")),
            "warnings": ["XDATA chỉ lưu H và thép, kích thước B×L cần kiểm tra thêm từ mặt bằng."],
        }

    if "MongCoc" in app_name:
        p = [x.strip() for x in payload.strip().split("\u221e")]
        lot_parts = (get_p(p, 9, "100/50")).split("/")
        lot_day_str = lot_parts[0] if lot_parts else "100"
        lot_chia_str = lot_parts[1] if len(lot_parts) > 1 else "50"
        b1 = _parse_rebar_spec(get_p(p, 18, "12a200"), 12, 200)
        b2 = _parse_rebar_spec(get_p(p, 20, "12a200"), 12, 200)
        t1 = _parse_rebar_spec(get_p(p, 22, "12a200"), 12, 200)
        t2 = _parse_rebar_spec(get_p(p, 24, "12a200"), 12, 200)
        vach = _parse_rebar_spec(get_p(p, 33, "12a250"), 12, 250)
        H = _safe_int(get_p(p, 4, "900"), 900) or 900
        coc_d = _safe_int(get_p(p, 17, "200"), 200) or 200
        return {
            "id": "xdata-coc-%d" % idx,
            "selected": True,
            "kind": "mong_coc",
            "ten": get_p(p, 0, "ĐM%d" % (idx + 1)).strip(),
            "soLuong": _safe_int(get_p(p, 1, "1"), 1) or 1,
            "B": 1400,
            "L": 1400,
            "H": H,
            "caoTrinh": _safe_float(get_p(p, 5, "-0.5"), -0.5),
            "cotB": 300,
            "cotH": 220,
            "viTriCotMode": "top_flush",
            "lechTamX": 0,
            "lechTamY": 0,
            "cocD": coc_d,
            "cocHinh": "square",
            "soCocX": 2,
            "soCocY": 2,
            "buocCocX": 600,
            "buocCocY": 600,
            "explicitCoverTren": _safe_int(get_p(p, 6, "35"), 35) or 35,
            "explicitCoverDay": _safe_int(get_p(p, 7, "135"), 135) or 135,
            "explicitCoverCanh": _safe_int(get_p(p, 8, "50"), 50) or 50,
            "explicitLotDay": _safe_int(lot_day_str, 100) or 100,
            "explicitLotChiaMC": _safe_int(lot_chia_str, 50) or 50,
            "explicitCoc": {
                "tiLe": _safe_int(get_p(p, 2, "25"), 25) or 25,
                "ngamCoc": _safe_int(get_p(p, 12, "100"), 100) or 100,
                "thepDuoiX": b1,
                "thepDuoiY": b2,
                "thepTrenX": t1,
                "thepTrenY": t2,
                "thepVach": vach,
            },
            "sourceType": "dxf_xdata",
            "summary": "XDATA MongCoc · H=%s · BV trên/đáy=%s/%s" % (H, get_p(p, 6, "35"), get_p(p, 7, "135")),
            "warnings": [],
        }

    ten = get_p(non_empty, 0, "CK%d" % (idx + 1)).strip()
    sec_w = get_p(non_empty, 1, "400")
    sec_h = get_p(non_empty, 2, "800")
    sl = _safe_int(get_p(non_empty, 3, "1"), 1) or 1
    z_top = _parse_z_meters(get_p(non_empty, 4, "-0.5"), -0.5)
    top_bar = _parse_bar_count_diam(get_p(non_empty, 21, "3T18"), 3, 18)
    second_bar_str = get_p(non_empty, 22, "3T18")
    bot_bar = _parse_bar_count_diam(second_bar_str.split("/")[0] or "3T18", 3, 18)
    stir_d = _safe_int(get_p(non_empty, 14, "8"), 8) or 8
    stir_a_goi = _safe_int(get_p(non_empty, 10, "100"), 100) or 100
    stir_a_nhip = _safe_int(get_p(non_empty, 9, str(max(150, stir_a_goi * 2))), max(150, stir_a_goi * 2))

    d11 = []
    for x in (extra_dong11 or "").split("\u221e"):
        v = _safe_float(x.strip(), 0.0)
        if v > 0:
            d11.append(int(round(v)))
    d12 = [x.strip() for x in (extra_dong12 or "").split("\u221e")]

    if "/" in sec_w or "/" in sec_h:
        w_parts = (sec_w.split("/") + ["0", "0"])[:3]
        h_parts = (sec_h.split("/") + ["200", "200"])[:3]
        B_dam = _safe_int(w_parts[0], 300) or 300
        canh_trai = _safe_int(w_parts[1], 0)
        canh_phai = _safe_int(w_parts[2], 0)
        H_dam = _safe_int(h_parts[0], 600) or 600
        h_vat = _safe_int(h_parts[1], 200) or 200
        h_mep = _safe_int(h_parts[2], 200) or 200
        wing_match = re.search(r"/(\d+)[a@](\d+)", second_bar_str, re.IGNORECASE)
        cols = []
        spans = []
        if len(d11) >= 3:
            for k, val in enumerate(d11):
                if k % 2 == 0:
                    cols.append({"trucLabel": str(k // 2 + 1), "bCot": val, "align": "center"})
                else:
                    spans.append(val)
        tong_l = sum(d11) if d11 else 10000
        return {
            "id": "xdata-mb-%d" % idx,
            "selected": True,
            "kind": "mong_bang",
            "ten": ten,
            "soLuong": sl,
            "B": canh_trai + B_dam + canh_phai,
            "L": tong_l,
            "H": H_dam,
            "hVat": h_vat,
            "hMep": h_mep,
            "caoTrinh": z_top,
            "cotB": cols[0]["bCot"] if cols else 350,
            "cotH": 300,
            "viTriCotMode": "center",
            "lechTamX": 0,
            "lechTamY": 0,
            "B_dam": B_dam,
            "canhTrai": canh_trai,
            "canhPhai": canh_phai,
            "stripCols": cols if len(cols) >= 2 else None,
            "spans": spans if spans else [4000, 4500],
            "explicitBang": {
                "thepTrenCount": top_bar["n"],
                "thepTrenD": top_bar["d"],
                "thepDuoiCount": bot_bar["n"],
                "thepDuoiD": bot_bar["d"],
                "thepDaiD": stir_d,
                "thepDaiA": stir_a_nhip,
                "thepNgangCanhD": int(wing_match.group(1)) if wing_match else 12,
                "thepNgangCanhA": int(wing_match.group(2)) if wing_match else 200,
            },
            "sourceType": "dxf_xdata",
            "summary": "XDATA MongBang · %s/%s/%s · H=%s · L=%s" % (B_dam, canh_trai, canh_phai, H_dam, tong_l),
            "warnings": [],
        }

    B_dam = _safe_int(sec_w, 400) or 400
    H_dam = _safe_int(sec_h, 800) or 800
    supports = []
    spans = []
    if len(d11) >= 3:
        for k, val in enumerate(d11):
            if k % 2 == 0:
                sup_idx = k // 2
                col_w_val = _safe_int(d12[k + 1], B_dam) if (k + 1 < len(d12)) else B_dam
                if col_w_val <= 0:
                    col_w_val = B_dam
                supports.append({
                    "trucLabel": chr(65 + min(25, sup_idx)),
                    "len": val,
                    "colW": col_w_val,
                    "colH": min(700, H_dam),
                })
            else:
                spans.append(val)
    tong_l = sum(d11) if d11 else 6000
    return {
        "id": "xdata-dm-%d" % idx,
        "selected": True,
        "kind": "dam_mong",
        "ten": ten,
        "soLuong": sl,
        "B": B_dam,
        "L": tong_l,
        "H": H_dam,
        "caoTrinh": z_top,
        "cotB": B_dam,
        "cotH": H_dam,
        "viTriCotMode": "center",
        "lechTamX": 0,
        "lechTamY": 0,
        "B_dam": B_dam,
        "supports": supports if len(supports) >= 2 else None,
        "spans": spans if spans else [3200],
        "explicitDam": {
            "thepTren1Count": top_bar["n"],
            "thepTren1D": top_bar["d"],
            "thepDuoiCount": bot_bar["n"],
            "thepDuoiD": bot_bar["d"],
            "thepDaiD": stir_d,
            "thepDaiAGoi": min(stir_a_goi, 150),
            "thepDaiANhip": max(stir_a_nhip, 150),
        },
        "sourceType": "dxf_xdata",
        "summary": "XDATA DamMong · %s×%s · L=%s" % (B_dam, H_dam, tong_l),
        "warnings": [],
    }


# ==================== 3. ARBITRARY DXF PLAN GEOMETRY PARSER ====================

def _tessellate_bulge(p1, p2, bulge, steps=8):
    if abs(bulge) < 1e-4:
        return []
    dx = p2["x"] - p1["x"]
    dy = p2["y"] - p1["y"]
    chord = math.hypot(dx, dy)
    if chord < 1e-5:
        return []
    theta = 4.0 * math.atan(bulge)
    sin_half = math.sin(abs(theta) / 2.0)
    if sin_half < 1e-5:
        return []
    r = chord / (2.0 * sin_half)
    sagitta = r * math.cos(theta / 2.0)
    mx = (p1["x"] + p2["x"]) / 2.0
    my = (p1["y"] + p2["y"]) / 2.0
    ux = -dy / chord
    uy = dx / chord
    sign = 1.0 if bulge >= 0 else -1.0
    cx = mx + sign * ux * sagitta
    cy = my + sign * uy * sagitta
    a1 = math.atan2(p1["y"] - cy, p1["x"] - cx)
    out = []
    for k in range(1, steps):
        a = a1 + (theta * k) / float(steps)
        out.append({"x": cx + r * math.cos(a), "y": cy + r * math.sin(a)})
    return out


def _trace_closed_line_loops(lines, snap_tol=2.0):
    result = []
    if len(lines) < 3 or len(lines) > 800:
        return result

    nodes = []

    def find_or_add_node(x, y):
        for idx, nd in enumerate(nodes):
            if math.hypot(nd["x"] - x, nd["y"] - y) <= snap_tol:
                return idx
        nodes.append({"x": x, "y": y, "edges": []})
        return len(nodes) - 1

    for idx, l in enumerate(lines):
        u = find_or_add_node(l["x1"], l["y1"])
        v = find_or_add_node(l["x2"], l["y2"])
        if u != v:
            nodes[u]["edges"].append({"to": v, "lineIdx": idx})
            nodes[v]["edges"].append({"to": u, "lineIdx": idx})

    used_edges = set()
    seen_keys = set()

    for start in range(len(nodes)):
        for first_edge in nodes[start]["edges"]:
            if first_edge["lineIdx"] in used_edges:
                continue
            path_nodes = [start, first_edge["to"]]
            path_edges = [first_edge["lineIdx"]]
            found = None

            prev = start
            curr = first_edge["to"]
            for _ in range(24):
                if curr == start and len(path_nodes) >= 4:
                    found = path_nodes[:-1]
                    break
                tail = set(path_nodes[1:])
                candidates = [
                    e for e in nodes[curr]["edges"]
                    if e["to"] != prev and e["lineIdx"] not in used_edges and e["to"] not in tail
                ]
                if not candidates:
                    break
                close_edge = None
                if len(path_nodes) >= 3:
                    for e in candidates:
                        if e["to"] == start:
                            close_edge = e
                            break
                picked = close_edge
                if picked is None:
                    in_ang = math.atan2(nodes[curr]["y"] - nodes[prev]["y"], nodes[curr]["x"] - nodes[prev]["x"])

                    def _turn_key(e):
                        ang = math.atan2(nodes[e["to"]]["y"] - nodes[curr]["y"], nodes[e["to"]]["x"] - nodes[curr]["x"])
                        return (ang - in_ang + 4.0 * math.pi) % (2.0 * math.pi)

                    picked = sorted(candidates, key=_turn_key)[0]
                path_edges.append(picked["lineIdx"])
                path_nodes.append(picked["to"])
                prev = curr
                curr = picked["to"]

            if found and len(found) >= 3:
                pts = [{"x": nodes[ni]["x"], "y": nodes[ni]["y"]} for ni in found]
                key = "|".join(sorted("%d:%d" % (round(p["x"]), round(p["y"])) for p in pts))
                if key not in seen_keys and polygon_area(pts) > 1e-2:
                    seen_keys.add(key)
                    for ei in path_edges:
                        used_edges.add(ei)
                    layer = lines[first_edge["lineIdx"]].get("layer", "0")
                    result.append({"pts": pts, "closed": True, "layer": layer, "bbox": _make_bbox(pts)})
    return result


def _parse_dxf_file(raw, unit_mode, defaults):
    raw_lines = raw.splitlines()
    pairs = []
    idx_line = 0
    while idx_line + 1 < len(raw_lines):
        try:
            code = int(raw_lines[idx_line].strip())
            pairs.append((code, raw_lines[idx_line + 1].strip()))
        except ValueError:
            pass
        idx_line += 2

    polys = []
    dxf_lines = []
    circles = []
    texts = []
    inserts = []
    blocks = {}
    xdata_map = []

    section = ""
    in_block = None
    i = 0
    n_pairs = len(pairs)

    while i < n_pairs:
        code, val = pairs[i]
        if code == 0 and val == "SECTION":
            if i + 1 < n_pairs and pairs[i + 1][0] == 2:
                section = pairs[i + 1][1].upper()
                i += 2
                continue
        if code == 0 and val == "ENDSEC":
            section = ""
            i += 1
            continue

        if section == "BLOCKS":
            if code == 0 and val == "BLOCK":
                name = ""
                i += 1
                while i < n_pairs and pairs[i][0] != 0:
                    if pairs[i][0] == 2:
                        name = pairs[i][1]
                    i += 1
                in_block = {"name": name, "def": {"polys": [], "lines": [], "circles": []}}
                continue
            if code == 0 and val == "ENDBLK":
                if in_block and in_block["name"] and not (
                    in_block["name"].startswith("*Model") or in_block["name"].startswith("*Paper")
                ):
                    blocks[in_block["name"]] = in_block["def"]
                in_block = None
                i += 1
                continue

        if section != "ENTITIES" and not (section == "BLOCKS" and in_block is not None):
            i += 1
            continue

        if code != 0:
            i += 1
            continue

        etype = val.upper()
        i += 1

        target_polys = in_block["def"]["polys"] if in_block else polys
        target_lines = in_block["def"]["lines"] if in_block else dxf_lines
        target_circles = in_block["def"]["circles"] if in_block else circles

        if etype == "LWPOLYLINE":
            layer = "0"
            closed = False
            verts = []
            cur_x = None
            paper_space = False
            while i < n_pairs and pairs[i][0] != 0:
                pc, pv = pairs[i]
                if pc == 8:
                    layer = pv
                elif pc == 67 and pv == "1":
                    paper_space = True
                elif pc == 70:
                    closed = (_safe_int(pv, 0) & 1) == 1
                elif pc == 10:
                    cur_x = _safe_float(pv)
                elif pc == 20 and cur_x is not None:
                    verts.append({"x": cur_x, "y": _safe_float(pv), "bulge": 0.0})
                    cur_x = None
                elif pc == 42 and verts:
                    verts[-1]["bulge"] = _safe_float(pv, 0.0)
                elif pc == 1001 and i + 1 < n_pairs and pairs[i + 1][0] == 1000:
                    xdata_map.append({"app": pv, "data": pairs[i + 1][1]})
                i += 1
            if not paper_space and len(verts) >= 2:
                expanded = []
                for k, v_curr in enumerate(verts):
                    expanded.append({"x": v_curr["x"], "y": v_curr["y"]})
                    if abs(v_curr["bulge"]) > 1e-4 and (k < len(verts) - 1 or closed):
                        v_next = verts[(k + 1) % len(verts)]
                        expanded.extend(_tessellate_bulge(v_curr, v_next, v_curr["bulge"], 8))
                is_loop_closed = closed or (
                    len(expanded) >= 3
                    and math.hypot(expanded[0]["x"] - expanded[-1]["x"], expanded[0]["y"] - expanded[-1]["y"]) < 1e-2
                )
                if is_loop_closed and len(expanded) >= 3:
                    target_polys.append({"pts": expanded, "closed": True, "layer": layer, "bbox": _make_bbox(expanded)})
            continue

        if etype == "POLYLINE":
            layer = "0"
            closed = False
            paper_space = False
            while i < n_pairs and pairs[i][0] != 0:
                pc, pv = pairs[i]
                if pc == 8:
                    layer = pv
                elif pc == 67 and pv == "1":
                    paper_space = True
                elif pc == 70:
                    closed = (_safe_int(pv, 0) & 1) == 1
                i += 1
            pts = []
            while i < n_pairs:
                if pairs[i][0] == 0 and pairs[i][1].upper() == "SEQEND":
                    i += 1
                    while i < n_pairs and pairs[i][0] != 0:
                        i += 1
                    break
                if pairs[i][0] == 0 and pairs[i][1].upper() == "VERTEX":
                    vx, vy = 0.0, 0.0
                    i += 1
                    while i < n_pairs and pairs[i][0] != 0:
                        if pairs[i][0] == 10:
                            vx = _safe_float(pairs[i][1])
                        elif pairs[i][0] == 20:
                            vy = _safe_float(pairs[i][1])
                        i += 1
                    pts.append({"x": vx, "y": vy})
                else:
                    i += 1
            if not paper_space and len(pts) >= 3:
                is_loop_closed = closed or math.hypot(pts[0]["x"] - pts[-1]["x"], pts[0]["y"] - pts[-1]["y"]) < 1e-2
                if is_loop_closed:
                    target_polys.append({"pts": pts, "closed": True, "layer": layer, "bbox": _make_bbox(pts)})
            continue

        if etype == "LINE":
            layer = "0"
            x1 = y1 = x2 = y2 = 0.0
            paper_space = False
            while i < n_pairs and pairs[i][0] != 0:
                pc, pv = pairs[i]
                if pc == 8:
                    layer = pv
                elif pc == 67 and pv == "1":
                    paper_space = True
                elif pc == 10:
                    x1 = _safe_float(pv)
                elif pc == 20:
                    y1 = _safe_float(pv)
                elif pc == 11:
                    x2 = _safe_float(pv)
                elif pc == 21:
                    y2 = _safe_float(pv)
                i += 1
            if not paper_space and math.hypot(x2 - x1, y2 - y1) > 1e-4:
                target_lines.append({"x1": x1, "y1": y1, "x2": x2, "y2": y2, "layer": layer})
            continue

        if etype == "CIRCLE":
            layer = "0"
            cx = cy = r = 0.0
            paper_space = False
            while i < n_pairs and pairs[i][0] != 0:
                pc, pv = pairs[i]
                if pc == 8:
                    layer = pv
                elif pc == 67 and pv == "1":
                    paper_space = True
                elif pc == 10:
                    cx = _safe_float(pv)
                elif pc == 20:
                    cy = _safe_float(pv)
                elif pc == 40:
                    r = _safe_float(pv)
                i += 1
            if not paper_space and r > 1e-3:
                target_circles.append({"cx": cx, "cy": cy, "r": r, "layer": layer})
            continue

        if etype in ("TEXT", "MTEXT") and in_block is None:
            layer = "0"
            x = y = 0.0
            text = ""
            paper_space = False
            while i < n_pairs and pairs[i][0] != 0:
                pc, pv = pairs[i]
                if pc == 8:
                    layer = pv
                elif pc == 67 and pv == "1":
                    paper_space = True
                elif pc == 10:
                    x = _safe_float(pv)
                elif pc == 20:
                    y = _safe_float(pv)
                elif pc in (1, 3):
                    text += (" " if text else "") + pv
                i += 1
            cleaned = _clean_dxf_text(text)
            if not paper_space and cleaned:
                texts.append({"x": x, "y": y, "text": cleaned, "layer": layer})
            continue

        if etype == "INSERT" and in_block is None:
            name = ""
            layer = "0"
            x = y = rot = 0.0
            sx = sy = 1.0
            has_attribs = False
            paper_space = False
            attribs = []
            while i < n_pairs and pairs[i][0] != 0:
                pc, pv = pairs[i]
                if pc == 2:
                    name = pv
                elif pc == 8:
                    layer = pv
                elif pc == 67 and pv == "1":
                    paper_space = True
                elif pc == 10:
                    x = _safe_float(pv)
                elif pc == 20:
                    y = _safe_float(pv)
                elif pc == 41:
                    sx = _safe_float(pv, 1.0) or 1.0
                elif pc == 42:
                    sy = _safe_float(pv, 1.0) or 1.0
                elif pc == 50:
                    rot = _safe_float(pv, 0.0)
                elif pc == 66:
                    has_attribs = _safe_int(pv, 0) == 1
                elif pc == 1001 and i + 1 < n_pairs and pairs[i + 1][0] == 1000:
                    xdata_map.append({"app": pv, "data": pairs[i + 1][1]})
                i += 1

            if has_attribs:
                while i < n_pairs:
                    if pairs[i][0] == 0 and pairs[i][1].upper() == "SEQEND":
                        i += 1
                        while i < n_pairs and pairs[i][0] != 0:
                            if pairs[i][0] == 1001 and i + 1 < n_pairs and pairs[i + 1][0] == 1000:
                                xdata_map.append({"app": pairs[i][1], "data": pairs[i + 1][1]})
                            i += 1
                        break
                    if pairs[i][0] == 0 and pairs[i][1].upper() == "ATTRIB":
                        ax, ay, aval = x, y, ""
                        i += 1
                        while i < n_pairs and pairs[i][0] != 0:
                            if pairs[i][0] == 10:
                                ax = _safe_float(pairs[i][1])
                            elif pairs[i][0] == 20:
                                ay = _safe_float(pairs[i][1])
                            elif pairs[i][0] == 1:
                                aval = pairs[i][1]
                            elif pairs[i][0] == 1001 and i + 1 < n_pairs and pairs[i + 1][0] == 1000:
                                xdata_map.append({"app": pairs[i][1], "data": pairs[i + 1][1]})
                            i += 1
                        clean_attr = _clean_dxf_text(aval)
                        if clean_attr and not paper_space:
                            attribs.append(clean_attr)
                            texts.append({"x": ax, "y": ay, "text": clean_attr, "layer": layer})
                    else:
                        i += 1

            if not paper_space:
                inserts.append({"name": name, "x": x, "y": y, "sx": sx, "sy": sy, "rot": rot, "layer": layer, "attribs": attribs})
            continue

        while i < n_pairs and pairs[i][0] != 0:
            if pairs[i][0] == 1001 and i + 1 < n_pairs and pairs[i + 1][0] == 1000:
                xdata_map.append({"app": pairs[i][1], "data": pairs[i + 1][1]})
            i += 1

    # Expand INSERT blocks
    for ins in inserts:
        bdef = blocks.get(ins["name"])
        if not bdef:
            continue
        rad = math.radians(ins["rot"])
        c_ang = math.cos(rad)
        s_ang = math.sin(rad)

        def xform(px, py):
            lx = px * ins["sx"]
            ly = py * ins["sy"]
            return {"x": ins["x"] + lx * c_ang - ly * s_ang, "y": ins["y"] + lx * s_ang + ly * c_ang}

        for bp in bdef["polys"]:
            w_pts = [xform(pt["x"], pt["y"]) for pt in bp["pts"]]
            polys.append({
                "pts": w_pts,
                "closed": True,
                "layer": ins["layer"] if bp["layer"] == "0" else bp["layer"],
                "bbox": _make_bbox(w_pts),
            })
        for bl in bdef["lines"]:
            p1 = xform(bl["x1"], bl["y1"])
            p2 = xform(bl["x2"], bl["y2"])
            dxf_lines.append({
                "x1": p1["x"],
                "y1": p1["y"],
                "x2": p2["x"],
                "y2": p2["y"],
                "layer": ins["layer"] if bl["layer"] == "0" else bl["layer"],
            })
        for bc in bdef["circles"]:
            wc = xform(bc["cx"], bc["cy"])
            circles.append({
                "cx": wc["x"],
                "cy": wc["y"],
                "r": bc["r"] * max(abs(ins["sx"]), abs(ins["sy"])),
                "layer": ins["layer"] if bc["layer"] == "0" else bc["layer"],
            })

    # Check DcePro XDATA priority
    chung_xdata = [
        x for x in xdata_map
        if x["app"] in ("LuuThongSoChungMongDon_SYS", "LuuThongSoChungMongCoc_SYS", "LuuThongSoChung_SYS")
    ]
    if chung_xdata and len(polys) > 15:
        dong11_list = [x["data"] for x in xdata_map if x["app"] == "LuuThongSoDong11_SYS"]
        dong12_list = [x["data"] for x in xdata_map if x["app"] == "LuuThongSoDong12_SYS"]
        x_cands = []
        seen_x = set()
        for idx, xd in enumerate(chung_xdata):
            d11 = dong11_list[idx] if idx < len(dong11_list) else None
            d12 = dong12_list[idx] if idx < len(dong12_list) else None
            cand = _parse_dcepro_xdata_record(xd["app"], xd["data"], d11, d12, idx)
            if cand:
                key = "%s::%s" % (cand["kind"], cand["ten"].upper())
                if key not in seen_x:
                    seen_x.add(key)
                    x_cands.append(cand)
        if x_cands:
            return {
                "candidates": x_cands,
                "detectedFormat": "dxf_xdata",
                "detectedUnit": "mm",
                "unitScaleToMm": 1,
                "stats": {
                    "polys": len(polys),
                    "lines": len(dxf_lines),
                    "circles": len(circles),
                    "inserts": len(inserts),
                    "texts": len(texts),
                    "xdataRecords": len(x_cands),
                },
                "messages": ["Phát hiện %d cấu kiện có XDATA DcePro nhúng sẵn trong file DXF." % len(x_cands)],
            }

    # Trace closed loops from loose LINEs
    line_loops = _trace_closed_line_loops(dxf_lines, 2.0)
    for lp in line_loops:
        dup = any(
            abs(ex["bbox"]["cx"] - lp["bbox"]["cx"]) < 5
            and abs(ex["bbox"]["cy"] - lp["bbox"]["cy"]) < 5
            and abs(ex["bbox"]["w"] - lp["bbox"]["w"]) < 5
            and abs(ex["bbox"]["h"] - lp["bbox"]["h"]) < 5
            for ex in polys
        )
        if not dup:
            polys.append(lp)

    # Unit auto-detection
    box_dims_raw = sorted(
        min(p["bbox"]["w"], p["bbox"]["h"])
        for p in polys
        if 0 < p["bbox"]["w"] < 50000 and 0 < p["bbox"]["h"] < 50000
    )
    median_dim = box_dims_raw[int(len(box_dims_raw) * 0.6)] if box_dims_raw else 1000.0
    if unit_mode != "auto":
        detected_unit = unit_mode
    else:
        if 0 < median_dim <= 12:
            detected_unit = "m"
        elif 12 < median_dim <= 180:
            detected_unit = "cm"
        else:
            detected_unit = "mm"
    scale = 1000.0 if detected_unit == "m" else (10.0 if detected_unit == "cm" else 1.0)

    raw_boxes = []
    for idx, p in enumerate(polys):
        world_pts = clean_polygon([{"x": pt["x"] * scale, "y": pt["y"] * scale} for pt in p["pts"]], 2.0)
        if len(world_pts) < 3:
            continue
        area = polygon_area(world_pts)
        if area < 6000:
            continue
        mbr = min_area_rect(world_pts)
        w = int(round(mbr["B"]))
        h = int(round(mbr["L"]))
        if w < 80 or h < 80 or w > 60000 or h > 60000:
            continue
        bb = _make_bbox(world_pts)
        dup = any(
            abs(b["cx"] - mbr["cx"]) < 15
            and abs(b["cy"] - mbr["cy"]) < 15
            and abs(b["w"] - w) < 15
            and abs(b["h"] - h) < 15
            and abs(b["area"] - area) / max(1.0, area) < 0.08
            for b in raw_boxes
        )
        if dup:
            continue
        raw_boxes.append({
            "id": idx,
            "cx": mbr["cx"],
            "cy": mbr["cy"],
            "minX": bb["minX"],
            "maxX": bb["maxX"],
            "minY": bb["minY"],
            "maxY": bb["maxY"],
            "w": w,
            "h": h,
            "angleDeg": mbr["angleDeg"],
            "uAxis": mbr["uAxis"],
            "vAxis": mbr["vAxis"],
            "worldPts": world_pts,
            "localPoly": mbr["localPoly"],
            "area": area,
            "shortSide": int(round(min(w, h))),
            "longSide": int(round(max(w, h))),
            "aspect": max(w, h) / float(max(1, min(w, h))),
            "layer": p["layer"].lower(),
            "used": False,
        })

    # Convert parallel line pairs at ANY angle
    scaled_lines = []
    for l in dxf_lines:
        x1, y1, x2, y2 = l["x1"] * scale, l["y1"] * scale, l["x2"] * scale, l["y2"] * scale
        length = math.hypot(x2 - x1, y2 - y1)
        if length < 1500:
            continue
        ang_deg = math.degrees(math.atan2(y2 - y1, x2 - x1))
        while ang_deg < 0:
            ang_deg += 180.0
        while ang_deg >= 180.0:
            ang_deg -= 180.0
        if ang_deg > 177.5:
            ang_deg = 0.0
        scaled_lines.append({
            "x1": x1, "y1": y1, "x2": x2, "y2": y2, "len": length, "angDeg": ang_deg, "layer": l["layer"].lower()
        })

    for a in range(len(scaled_lines)):
        l1 = scaled_lines[a]
        for b in range(a + 1, len(scaled_lines)):
            l2 = scaled_lines[b]
            da = abs(l1["angDeg"] - l2["angDeg"])
            if da > 90:
                da = 180.0 - da
            if da > 2.5:
                continue
            rad = math.radians(l1["angDeg"])
            ux, uy = math.cos(rad), math.sin(rad)
            vx, vy = -uy, ux

            u1a = l1["x1"] * ux + l1["y1"] * uy
            u1b = l1["x2"] * ux + l1["y2"] * uy
            v1 = l1["x1"] * vx + l1["y1"] * vy
            u2a = l2["x1"] * ux + l2["y1"] * uy
            u2b = l2["x2"] * ux + l2["y2"] * uy
            v2 = l2["x1"] * vx + l2["y1"] * vy

            ov_min = max(min(u1a, u1b), min(u2a, u2b))
            ov_max = min(max(u1a, u1b), max(u2a, u2b))
            ov_len = ov_max - ov_min
            sep = abs(v1 - v2)
            if ov_len < 1500 or sep < 180 or sep > 2600:
                continue

            min_v, max_v = min(v1, v2), max(v1, v2)
            mid_u = (ov_min + ov_max) / 2.0
            mid_v = (min_v + max_v) / 2.0
            cx = mid_u * ux + mid_v * vx
            cy = mid_u * uy + mid_v * vy

            def _corner(u, v):
                return {"x": u * ux + v * vx, "y": u * uy + v * vy}

            world_pts = [
                _corner(ov_min, min_v),
                _corner(ov_max, min_v),
                _corner(ov_max, max_v),
                _corner(ov_min, max_v),
            ]
            w = int(round(ov_len))
            h = int(round(sep))
            dup = any(
                abs(box["cx"] - cx) < 70
                and abs(box["cy"] - cy) < 70
                and abs(box["shortSide"] - min(w, h)) < 80
                and abs(box["longSide"] - max(w, h)) < 120
                for box in raw_boxes
            )
            if not dup:
                rot_deg = l1["angDeg"]
                if rot_deg > 90:
                    rot_deg -= 180.0
                hw, hh = w / 2.0, h / 2.0
                raw_boxes.append({
                    "id": len(raw_boxes) + 10000,
                    "cx": cx,
                    "cy": cy,
                    "minX": min(p["x"] for p in world_pts),
                    "maxX": max(p["x"] for p in world_pts),
                    "minY": min(p["y"] for p in world_pts),
                    "maxY": max(p["y"] for p in world_pts),
                    "w": w,
                    "h": h,
                    "angleDeg": 0.0 if abs(rot_deg) < 1.8 else round(rot_deg, 1),
                    "uAxis": {"x": ux, "y": uy},
                    "vAxis": {"x": vx, "y": vy},
                    "worldPts": world_pts,
                    "localPoly": [{"x": -hw, "y": -hh}, {"x": hw, "y": -hh}, {"x": hw, "y": hh}, {"x": -hw, "y": hh}],
                    "area": float(w * h),
                    "shortSide": min(w, h),
                    "longSide": max(w, h),
                    "aspect": max(w, h) / float(max(1, min(w, h))),
                    "layer": l1["layer"],
                    "used": False,
                })

    scaled_circles = [
        {"cx": c["cx"] * scale, "cy": c["cy"] * scale, "d": int(round(c["r"] * 2.0 * scale)), "layer": c["layer"].lower()}
        for c in circles
        if 120 <= round(c["r"] * 2.0 * scale) <= 1200
    ]
    scaled_texts = [
        {
            "x": t["x"] * scale,
            "y": t["y"] * scale,
            "text": t["text"],
            "norm": _strip_diacritics(t["text"]).upper(),
            "layer": t["layer"].lower(),
        }
        for t in texts
    ]

    label_re = re.compile(r"\b(MĐ[\w-]+|MD[\w-]+|MB[\w-]+|ĐM[\w-]+|ĐC[\w-]+|MC[\w-]+|DC[\w-]+|DM[\w-]+|GM[\w-]+|GD[\w-]+|PC[\w-]+|CAP[\w-]+|M\d+[A-Z]?)\b", re.IGNORECASE)

    def find_nearest_label(cx, cy, max_dist, pattern):
        best_text = None
        best_dist = float("inf")
        for t in scaled_texts:
            if not pattern.search(t["text"]):
                continue
            dist = math.hypot(t["x"] - cx, t["y"] - cy)
            if dist <= max_dist and dist < best_dist:
                best_dist = dist
                best_text = t["text"]
        return best_text

    # Detect concentric lean concrete halos
    halo_map = {}
    for outer in raw_boxes:
        if outer["shortSide"] < 650:
            continue
        for inner in raw_boxes:
            if inner["id"] == outer["id"]:
                continue
            if outer["area"] <= inner["area"] * 1.06 or outer["area"] >= inner["area"] * 1.95:
                continue
            if math.hypot(outer["cx"] - inner["cx"], outer["cy"] - inner["cy"]) > 160:
                continue
            if not point_in_polygon({"x": inner["cx"], "y": inner["cy"]}, outer["worldPts"], 10.0):
                continue
            margin_w = (outer["w"] - inner["w"]) / 2.0
            margin_h = (outer["h"] - inner["h"]) / 2.0
            if 35 <= margin_w <= 220 and 35 <= margin_h <= 220 and abs(margin_w - margin_h) <= 85:
                outer["used"] = True
                halo_map[inner["id"]] = _round5((margin_w + margin_h) / 2.0)

    def is_ignore_cad_layer(layer):
        lp = _strip_diacritics(layer).lower()
        return bool(re.search(r"(^|[_\s./-])(bt[_\s-]?lot|lot|lean|hatch|dim|kt|kich[_\s-]?thuoc|axis|grid|truc|khung|border|title|text|ghi[_\s-]?chu)($|[_\s./-])", lp))

    def is_pile_cap_layer(layer):
        lp = _strip_diacritics(layer).lower()
        return bool(re.search(r"(^|[_\s./-])(dai|dai[_\s-]?coc|dai[_\s-]?mong|pile[_\s-]?cap|pilecap|mong[_\s-]?coc|mongcoc)($|[_\s./-])", lp))

    def is_pile_layer(layer):
        if is_pile_cap_layer(layer):
            return False
        lp = _strip_diacritics(layer).lower()
        return bool(re.search(r"(^|[_\s./-])(coc|pile|piles|phc|coc[_\s-]?ep|coc[_\s-]?nhoi)($|[_\s./-])", lp))

    def is_col_layer(layer):
        lp = _strip_diacritics(layer).lower()
        return bool(re.search(r"(^|[_\s./-])(cot|col|cols|column|columns)($|[_\s./-])", lp))

    def has_piles_inside(box):
        for c in scaled_circles:
            if 150 <= c["d"] <= 800 and point_in_polygon({"x": c["cx"], "y": c["cy"]}, box["worldPts"], 35.0):
                return True
        for sb in raw_boxes:
            if sb["id"] != box["id"] and not sb["used"] and sb["aspect"] <= 1.25 and 160 <= sb["shortSide"] <= 450:
                if is_pile_layer(sb["layer"]) and point_in_polygon({"x": sb["cx"], "y": sb["cy"]}, box["worldPts"], 20.0):
                    return True
        return False

    small_boxes = [
        b for b in raw_boxes
        if not b["used"] and not is_ignore_cad_layer(b["layer"])
        and 120 <= b["shortSide"] and b["longSide"] <= 720 and b["aspect"] <= 3.0
    ]

    pad_boxes = []
    strip_or_beam_boxes = []
    for b in raw_boxes:
        if b["used"] or is_ignore_cad_layer(b["layer"]):
            continue
        if is_pile_layer(b["layer"]) or is_col_layer(b["layer"]):
            continue
        # Elongated 2x1 / 3x1 pile caps or explicit pile-cap layers stay in pad_boxes regardless of aspect
        if b["shortSide"] >= 450 and b["longSide"] <= 9000 and (is_pile_cap_layer(b["layer"]) or has_piles_inside(b)):
            pad_boxes.append(b)
        elif b["longSide"] >= 900 and b["aspect"] >= 2.3 and b["shortSide"] >= 160:
            strip_or_beam_boxes.append(b)
        elif b["shortSide"] >= 450 and b["aspect"] < 2.3 and b["longSide"] <= 7500:
            pad_boxes.append(b)

    def parse_mark_and_qty(raw_label, fallback_mark):
        if not raw_label:
            return fallback_mark, None
        sl = None
        sl_m = re.search(r"SL\s*=?\s*(\d+)", raw_label, re.IGNORECASE)
        if sl_m:
            sl = int(sl_m.group(1))
        clean = re.sub(r"\(?\s*SL\s*=?\s*\d+\s*\)?", "", raw_label, flags=re.IGNORECASE)
        clean = re.sub(r"^(MÓNG|MONG|ĐÀI|DAI|DẦM|DAM)\s+", "", clean, flags=re.IGNORECASE).strip()
        token = re.split(r"[\s,;]+", clean)[0] if clean else fallback_mark
        return token or fallback_mark, sl

    def to_local_uv(pad, px, py):
        dx = px - pad["cx"]
        dy = py - pad["cy"]
        return {
            "x": int(round(dx * pad["uAxis"]["x"] + dy * pad["uAxis"]["y"])),
            "y": int(round(dx * pad["vAxis"]["x"] + dy * pad["vAxis"]["y"])),
        }

    candidates = []
    used_cols = set()
    auto_don_count = 0
    auto_coc_count = 0

    for pad in pad_boxes:
        if pad["used"]:
            continue
        pad["used"] = True

        round_circles_inside = [
            c for c in scaled_circles
            if 150 <= c["d"] <= 800 and point_in_polygon({"x": c["cx"], "y": c["cy"]}, pad["worldPts"], 35.0)
        ]
        inner_smalls = [
            sb for sb in small_boxes
            if sb["id"] != pad["id"] and point_in_polygon({"x": sb["cx"], "y": sb["cy"]}, pad["worldPts"], 20.0)
        ]

        explicit_cols = [sb for sb in inner_smalls if is_col_layer(sb["layer"])]
        square_piles = []
        for sb in inner_smalls:
            if is_col_layer(sb["layer"]):
                continue
            if is_pile_layer(sb["layer"]):
                square_piles.append(sb)
            elif sb["aspect"] <= 1.25 and 160 <= sb["shortSide"] <= 450:
                same_squares = [
                    o for o in inner_smalls
                    if abs(o["w"] - sb["w"]) <= 25 and abs(o["h"] - sb["h"]) <= 25 and not is_col_layer(o["layer"])
                ]
                if len(same_squares) >= 2:
                    square_piles.append(sb)

        sq_ids = set(p["id"] for p in square_piles)
        detected_cols = explicit_cols if explicit_cols else [sb for sb in inner_smalls if sb["id"] not in sq_ids]
        for c in detected_cols:
            used_cols.add(c["id"])
        col_box = detected_cols[0] if detected_cols else None

        lbl = find_nearest_label(pad["cx"], pad["cy"], max(pad["w"], pad["h"]) * 0.65 + 750.0, label_re)
        raw_lbl_upper = (lbl or "").strip().upper()
        norm_lbl = _strip_diacritics(lbl).upper() if lbl else ""
        is_pile_cap = (
            len(round_circles_inside) >= 1
            or len(square_piles) >= 2
            or (len(square_piles) >= 1 and is_pile_layer(square_piles[0]["layer"]))
            or is_pile_cap_layer(pad["layer"])
            or bool(re.match(r"^(ĐM|ĐC|MC|DC|PC)", raw_lbl_upper))
            or (bool(re.match(r"^DM", norm_lbl)) and (len(round_circles_inside) > 0 or len(square_piles) > 0))
        )

        cot_b = _round5(col_box["w"]) if col_box else (300 if is_pile_cap else defaults["donCotB"])
        cot_h = _round5(col_box["h"]) if col_box else (220 if is_pile_cap else defaults["donCotH"])
        col_local = to_local_uv(pad, col_box["cx"], col_box["cy"]) if col_box else {"x": 0, "y": 0}
        is_polygonal = not is_rect_poly(pad["localPoly"])
        is_top_flush = (not is_polygonal and col_box is not None and abs(col_local["y"] - (pad["h"] / 2.0 - cot_h / 2.0)) <= 35)
        if not col_box:
            mode = "center"
        elif is_top_flush:
            mode = "top_flush"
        elif abs(col_local["x"]) > 25 or abs(col_local["y"]) > 25:
            mode = "custom"
        else:
            mode = "center"

        extra_cols = []
        for eci, ec in enumerate(detected_cols[1:]):
            pt = to_local_uv(pad, ec["cx"], ec["cy"])
            extra_cols.append({
                "id": "ec-%s-%d" % (pad["id"], eci + 1),
                "x": _round5(pt["x"]),
                "y": _round5(pt["y"]),
                "b": _round5(ec["w"]),
                "h": _round5(ec["h"]),
            })

        lot_chia = halo_map.get(pad["id"])
        custom_polygon = pad["localPoly"] if is_polygonal else None
        goc_xoay = pad["angleDeg"] if abs(pad["angleDeg"]) >= 0.8 else None

        if is_pile_cap:
            auto_coc_count += 1
            ten, sl = parse_mark_and_qty(lbl, "ĐM%d" % auto_coc_count)
            if len(round_circles_inside) >= len(square_piles):
                raw_pile_pts = [dict(to_local_uv(pad, c["cx"], c["cy"]), d=c["d"], shape="circle") for c in round_circles_inside]
            else:
                raw_pile_pts = [dict(to_local_uv(pad, p["cx"], p["cy"]), d=p["shortSide"], shape="square") for p in square_piles]

            xs = sorted(set(int(round(p["x"] / 40.0) * 40) for p in raw_pile_pts))
            ys = sorted(set(int(round(p["y"] / 40.0) * 40) for p in raw_pile_pts))
            so_coc_x = max(1, len(xs) or 2)
            so_coc_y = max(1, len(ys) or 2)
            buoc_coc_x = _round5((xs[-1] - xs[0]) / (len(xs) - 1)) if len(xs) > 1 else 600
            buoc_coc_y = _round5((ys[-1] - ys[0]) / (len(ys) - 1)) if len(ys) > 1 else 600
            coc_d = _round5(raw_pile_pts[0]["d"]) if raw_pile_pts else defaults["cocDDefault"]

            is_non_grid = len(raw_pile_pts) > 0 and (
                len(raw_pile_pts) in (3, 5) or (len(xs) * len(ys) != len(raw_pile_pts)) or is_polygonal
            )
            custom_piles = None
            if is_non_grid:
                custom_piles = [
                    {
                        "id": "p-%d" % (pi + 1),
                        "x": _round5(p["x"]),
                        "y": _round5(p["y"]),
                        "d": _round5(p["d"]) if _round5(p["d"]) != coc_d else None,
                    }
                    for pi, p in enumerate(raw_pile_pts)
                ]

            shape_desc = ("Đa giác %d đỉnh" % len(custom_polygon)) if custom_polygon else ("Đài %s×%s" % (_round5(pad["w"]), _round5(pad["h"])))
            pile_desc = ("%d cọc tự do" % len(custom_piles)) if custom_piles else ("%d×%d cọc %s" % (so_coc_x, so_coc_y, coc_d))
            world_inst = {
                "ten": ten,
                "kind": "mong_coc",
                "cx": round(pad["cx"], 1),
                "cy": round(pad["cy"], 1),
                "B": _round5(pad["w"]),
                "L": _round5(pad["h"]),
                "ang": pad["angleDeg"],
                "poly": [[round(pt["x"], 1), round(pt["y"], 1)] for pt in pad["worldPts"]],
            }
            candidates.append({
                "id": "dxf-coc-%s" % pad["id"],
                "selected": True,
                "kind": "mong_coc",
                "ten": ten,
                "soLuong": sl or 1,
                "B": _round5(pad["w"]),
                "L": _round5(pad["h"]),
                "H": defaults["cocH"],
                "shapePreset": "custom" if custom_polygon else None,
                "customPolygon": custom_polygon,
                "customPiles": custom_piles,
                "gocXoay": goc_xoay,
                "extraColumns": extra_cols if extra_cols else None,
                "cotB": cot_b,
                "cotH": cot_h,
                "viTriCotMode": mode,
                "lechTamX": col_local["x"],
                "lechTamY": col_local["y"],
                "cocD": coc_d,
                "cocHinh": raw_pile_pts[0]["shape"] if raw_pile_pts else defaults["cocShapeDefault"],
                "soCocX": so_coc_x,
                "soCocY": so_coc_y,
                "buocCocX": buoc_coc_x,
                "buocCocY": buoc_coc_y,
                "explicitLotChiaMB": lot_chia,
                "worldInstances": [world_inst],
                "sourceType": "dxf_geom",
                "summary": "Quét MB DXF · %s · %s%s%s" % (
                    shape_desc,
                    pile_desc,
                    (" · %d cột" % len(detected_cols)) if len(detected_cols) > 1 else "",
                    (" · Xoay %s°" % goc_xoay) if goc_xoay else "",
                ),
                "warnings": [] if col_box else ["Không tìm thấy nét cột bên trong đài — dùng kích thước cột mặc định."],
            })
        else:
            auto_don_count += 1
            ten, sl = parse_mark_and_qty(lbl, "MĐ%d" % auto_don_count)
            shape_desc = (
                "Chữ/Đa giác %d đỉnh (%s×%s)" % (len(custom_polygon), _round5(pad["w"]), _round5(pad["h"]))
                if custom_polygon
                else "Móng đơn %s×%s" % (_round5(pad["w"]), _round5(pad["h"]))
            )
            world_inst = {
                "ten": ten,
                "kind": "mong_don",
                "cx": round(pad["cx"], 1),
                "cy": round(pad["cy"], 1),
                "B": _round5(pad["w"]),
                "L": _round5(pad["h"]),
                "ang": pad["angleDeg"],
                "poly": [[round(pt["x"], 1), round(pt["y"], 1)] for pt in pad["worldPts"]],
            }
            candidates.append({
                "id": "dxf-don-%s" % pad["id"],
                "selected": True,
                "kind": "mong_don",
                "ten": ten,
                "soLuong": sl or 1,
                "B": _round5(pad["w"]),
                "L": _round5(pad["h"]),
                "H": defaults["donH"],
                "hMep": defaults["donHMep"],
                "shapePreset": "custom" if custom_polygon else None,
                "customPolygon": custom_polygon,
                "gocXoay": goc_xoay,
                "extraColumns": extra_cols if extra_cols else None,
                "cotB": cot_b,
                "cotH": cot_h,
                "viTriCotMode": mode,
                "lechTamX": col_local["x"],
                "lechTamY": col_local["y"],
                "explicitLotChiaMB": lot_chia,
                "worldInstances": [world_inst],
                "sourceType": "dxf_geom",
                "summary": "Quét MB DXF · %s · %s%s" % (
                    shape_desc,
                    ("%d cột" % len(detected_cols)) if len(detected_cols) > 1 else ("Cột %s×%s" % (cot_b, cot_h)),
                    (" · Xoay %s°" % goc_xoay) if goc_xoay else "",
                ),
                "warnings": [] if col_box else ["Không thấy hình chiếu cột trong đài — đang đặt cột đúng tâm mặc định."],
            })

    # Step B: Strip & Foundation Beams (pre-attach inner ribs, then chain collinear split segments -> 1 beam!)
    rib_assigned = set()
    rib_by_host = {}
    for box in sorted(strip_or_beam_boxes, key=lambda b: -b["shortSide"]):
        if box["used"] or box["id"] in rib_assigned:
            continue
        u_is_long = box["w"] >= box["h"]
        long_dir = box["uAxis"] if u_is_long else box["vAxis"]
        perp_dir = box["vAxis"] if u_is_long else {"x": -box["uAxis"]["x"], "y": -box["uAxis"]["y"]}
        for other in strip_or_beam_boxes:
            if other["id"] == box["id"] or other["used"] or other["id"] in rib_assigned:
                continue
            if other["shortSide"] >= box["shortSide"] - 80:
                continue
            o_u = (other["cx"] - box["cx"]) * long_dir["x"] + (other["cy"] - box["cy"]) * long_dir["y"]
            o_v = (other["cx"] - box["cx"]) * perp_dir["x"] + (other["cy"] - box["cy"]) * perp_dir["y"]
            if abs(o_u) <= box["longSide"] / 2.0 + 80 and abs(o_v) <= box["shortSide"] / 2.0 + 60:
                rib_assigned.add(other["id"])
                other["used"] = True
                rib_by_host[box["id"]] = other
                break

    # Pre-build segment representations for remaining outer strip/beam boxes and chain collinear segments
    outer_segs = []
    for box in strip_or_beam_boxes:
        if box["used"] or box["id"] in rib_assigned:
            continue
        u_is_long = box["w"] >= box["h"]
        ld = box["uAxis"] if u_is_long else box["vAxis"]
        pd = box["vAxis"] if u_is_long else {"x": -box["uAxis"]["x"], "y": -box["uAxis"]["y"]}
        hl = box["longSide"] / 2.0
        p0 = {"x": box["cx"] - ld["x"] * hl, "y": box["cy"] - ld["y"] * hl}
        p1 = {"x": box["cx"] + ld["x"] * hl, "y": box["cy"] + ld["y"] * hl}
        if (p1["x"] < p0["x"] - 5.0) or (abs(p1["x"] - p0["x"]) <= 5.0 and p1["y"] < p0["y"]):
            p0, p1 = p1, p0
            ld = {"x": -ld["x"], "y": -ld["y"]}
            pd = {"x": -ld["y"], "y": ld["x"]}
        lbl_seg = find_nearest_label(box["cx"], box["cy"], box["longSide"] * 0.55 + 700.0, label_re)
        mark_seg = re.sub(r"\(.*\)", "", lbl_seg).strip().upper() if lbl_seg else ""
        outer_segs.append({
            "box": box,
            "p0": p0,
            "p1": p1,
            "ld": ld,
            "pd": pd,
            "shortSide": box["shortSide"],
            "rib": rib_by_host.get(box["id"]),
            "lbl": lbl_seg,
            "markUpper": mark_seg,
        })

    def _dxf_seg_match(tail, cand):
        if abs(tail["shortSide"] - cand["shortSide"]) > max(60.0, 0.25 * min(tail["shortSide"], cand["shortSide"])):
            return False, False
        if bool(tail["rib"]) != bool(cand["rib"]):
            return False, False
        if tail["markUpper"] and cand["markUpper"] and tail["markUpper"] != cand["markUpper"]:
            return False, False
        dot = abs(tail["ld"]["x"] * cand["ld"]["x"] + tail["ld"]["y"] * cand["ld"]["y"])
        if dot < math.cos(math.radians(6.0)):
            return False, False
        perp = abs((cand["p0"]["x"] - tail["p0"]["x"]) * (-tail["ld"]["y"]) + (cand["p0"]["y"] - tail["p0"]["y"]) * tail["ld"]["x"])
        if perp > max(tail["shortSide"], cand["shortSide"]) * 0.45 + 80.0:
            return False, False
        ta = (cand["p0"]["x"] - tail["p1"]["x"]) * tail["ld"]["x"] + (cand["p0"]["y"] - tail["p1"]["y"]) * tail["ld"]["y"]
        tb = (cand["p1"]["x"] - tail["p1"]["x"]) * tail["ld"]["x"] + (cand["p1"]["y"] - tail["p1"]["y"]) * tail["ld"]["y"]
        if ta <= tb:
            near_t, far_t, flip, near_pt = ta, tb, False, cand["p0"]
        else:
            near_t, far_t, flip, near_pt = tb, ta, True, cand["p1"]
        l1 = math.hypot(tail["p1"]["x"] - tail["p0"]["x"], tail["p1"]["y"] - tail["p0"]["y"])
        if far_t <= 50.0 or near_t < -min(450.0, l1 * 0.45):
            return False, False
        gap = max(0.0, near_t)
        if gap <= 450.0:
            return True, flip
        if gap <= 2200.0:
            mx = (tail["p1"]["x"] + near_pt["x"]) / 2.0
            my = (tail["p1"]["y"] + near_pt["y"]) / 2.0
            for pb in pad_boxes:
                if point_in_polygon({"x": mx, "y": my}, pb["worldPts"], 160.0):
                    return True, flip
            for sb in small_boxes:
                if point_in_polygon({"x": mx, "y": my}, sb["worldPts"], 160.0):
                    return True, flip
        return False, False

    chained_beams = []
    rem_segs = list(outer_segs)
    while rem_segs:
        seed = rem_segs.pop(0)
        run = [seed]
        changed = True
        while changed:
            changed = False
            tail = run[-1]
            for idx, cand in enumerate(rem_segs):
                ok, flip = _dxf_seg_match(tail, cand)
                if ok:
                    nxt = dict(cand)
                    if flip:
                        nxt["p0"], nxt["p1"] = cand["p1"], cand["p0"]
                    run.append(nxt)
                    rem_segs.pop(idx)
                    changed = True
                    break
        changed = True
        while changed:
            changed = False
            head = run[0]
            head_rev = dict(head, p0=head["p1"], p1=head["p0"], ld={"x": -head["ld"]["x"], "y": -head["ld"]["y"]})
            for idx, cand in enumerate(rem_segs):
                ok, flip = _dxf_seg_match(head_rev, cand)
                if ok:
                    prv = dict(cand)
                    if not flip:
                        prv["p0"], prv["p1"] = cand["p1"], cand["p0"]
                    run.insert(0, prv)
                    rem_segs.pop(idx)
                    changed = True
                    break
        chained_beams.append(run)

    auto_bang_count = 0
    auto_dam_count = 0

    for run in chained_beams:
        rep_seg = run[0]
        box = rep_seg["box"]
        p0, p1 = run[0]["p0"], run[-1]["p1"]
        dx, dy = p1["x"] - p0["x"], p1["y"] - p0["y"]
        total_len_raw = max(100.0, math.hypot(dx, dy))
        long_dir = {"x": dx / total_len_raw, "y": dy / total_len_raw}
        perp_dir = {"x": -long_dir["y"], "y": long_dir["x"]}
        cx = (p0["x"] + p1["x"]) / 2.0
        cy = (p0["y"] + p1["y"]) / 2.0
        length = _round5(total_len_raw)
        width = _round5(rep_seg["shortSide"])
        inner_rib = next((s["rib"] for s in run if s.get("rib")), None)
        chain_ang = round(math.degrees(math.atan2(dy, dx)), 1)

        def proj_u(px, py):
            return (px - cx) * long_dir["x"] + (py - cy) * long_dir["y"]

        def proj_v(px, py):
            return (px - cx) * perp_dir["x"] + (py - cy) * perp_dir["y"]

        lbl = next((s["lbl"] for s in run if s.get("lbl")), None)
        if not lbl:
            lbl = find_nearest_label(cx, cy, length * 0.55 + 900.0, label_re)
        norm_lbl = _strip_diacritics(lbl).upper() if lbl else ""

        cols_on_beam = sorted(
            [
                c for c in small_boxes
                if c["id"] not in used_cols
                and abs(proj_u(c["cx"], c["cy"])) <= length / 2.0 + 180
                and abs(proj_v(c["cx"], c["cy"])) <= width / 2.0 + 180
            ],
            key=lambda c: proj_u(c["cx"], c["cy"]),
        )
        pads_touching = sorted(
            [
                p for p in pad_boxes
                if abs(proj_u(p["cx"], p["cy"])) <= length / 2.0 + p["longSide"] / 2.0 + 160
                and abs(proj_v(p["cx"], p["cy"])) <= width / 2.0 + p["longSide"] / 2.0 + 160
            ],
            key=lambda p: proj_u(p["cx"], p["cy"]),
        )

        box_layer_plain = _strip_diacritics(box["layer"]).lower()
        is_strip_footing = (
            bool(inner_rib)
            or bool(re.search(r"(bang|strip)", box_layer_plain))
            or bool(re.match(r"^MB", norm_lbl))
            or (
                not re.match(r"^(DM|GM|GD)", norm_lbl)
                and not re.search(r"(dam|giang|beam)", box_layer_plain)
                and (width > defaults["bangBThreshold"] or (len(cols_on_beam) >= 2 and width >= 700))
            )
        )
        goc_xoay = chain_ang if abs(chain_ang) >= 0.8 else None
        hb = width / 2.0
        chain_poly = [
            [round(p0["x"] - perp_dir["x"] * hb, 1), round(p0["y"] - perp_dir["y"] * hb, 1)],
            [round(p1["x"] - perp_dir["x"] * hb, 1), round(p1["y"] - perp_dir["y"] * hb, 1)],
            [round(p1["x"] + perp_dir["x"] * hb, 1), round(p1["y"] + perp_dir["y"] * hb, 1)],
            [round(p0["x"] + perp_dir["x"] * hb, 1), round(p0["y"] + perp_dir["y"] * hb, 1)],
        ]

        if is_strip_footing:
            auto_bang_count += 1
            ten, sl = parse_mark_and_qty(lbl, "MB%d" % auto_bang_count)
            b_dam = _round5(inner_rib["shortSide"]) if inner_rib else min(defaults["bangBDam"], width)
            if inner_rib:
                offset_v = proj_v(inner_rib["cx"], inner_rib["cy"])
                canh_trai = _round5(max(0.0, width / 2.0 - (offset_v + b_dam / 2.0)))
                canh_phai = _round5(max(0.0, width - b_dam - canh_trai))
            else:
                wing_total = max(0, width - b_dam)
                canh_trai = _round5(wing_total / 2.0)
                canh_phai = wing_total - canh_trai

            strip_cols = []
            spans = []
            if len(cols_on_beam) >= 2:
                for k, c in enumerate(cols_on_beam):
                    cw = _round5(c["w"])
                    strip_cols.append({"trucLabel": str(k + 1), "bCot": cw, "align": "center"})
                    if k > 0:
                        prev = cols_on_beam[k - 1]
                        gap = proj_u(c["cx"], c["cy"]) - proj_u(prev["cx"], prev["cy"]) - prev["w"] / 2.0 - c["w"] / 2.0
                        spans.append(max(800, _round5(gap)))
            else:
                mid = max(1500, _round5((length - 900) / 2.0))
                strip_cols = [
                    {"trucLabel": "C", "bCot": 300, "align": "center"},
                    {"trucLabel": "B", "bCot": 300, "align": "center"},
                    {"trucLabel": "A", "bCot": 300, "align": "center"},
                ]
                spans = [mid, mid]

            world_inst = {
                "ten": ten,
                "kind": "mong_bang",
                "cx": round(cx, 1),
                "cy": round(cy, 1),
                "B": width,
                "L": length,
                "ang": chain_ang,
                "poly": chain_poly,
                "p0": [round(p0["x"], 1), round(p0["y"], 1)],
                "p1": [round(p1["x"], 1), round(p1["y"], 1)],
            }
            candidates.append({
                "id": "dxf-bang-%s" % box["id"],
                "selected": True,
                "kind": "mong_bang",
                "ten": ten,
                "soLuong": sl or 1,
                "B": width,
                "L": length,
                "H": defaults["bangHDam"],
                "hVat": defaults["bangHVat"],
                "hMep": defaults["bangHMep"],
                "gocXoay": goc_xoay,
                "cotB": strip_cols[0]["bCot"],
                "cotH": 300,
                "viTriCotMode": "center",
                "lechTamX": 0,
                "lechTamY": 0,
                "B_dam": b_dam,
                "canhTrai": canh_trai,
                "canhPhai": canh_phai,
                "stripCols": strip_cols,
                "spans": spans,
                "worldInstances": [world_inst],
                "sourceType": "dxf_geom",
                "summary": "Quét MB DXF · Móng băng %s/%s/%s · L=%s (%d nhịp%s)%s" % (
                    b_dam, canh_trai, canh_phai, length, len(spans),
                    (" · nối %d đoạn" % len(run)) if len(run) > 1 else "",
                    (" · Xoay %s°" % goc_xoay) if goc_xoay else "",
                ),
                "warnings": [],
            })
        else:
            auto_dam_count += 1
            ten, sl = parse_mark_and_qty(lbl, "DM%d" % auto_dam_count)
            supports = []
            spans = []
            if len(pads_touching) >= 2:
                for k, p in enumerate(pads_touching):
                    supports.append({
                        "trucLabel": chr(65 + min(25, k)),
                        "len": _round5(p["longSide"]),
                        "colW": width,
                        "colH": min(700, defaults["damHDam"]),
                    })
                    if k > 0:
                        prev = pads_touching[k - 1]
                        gap = proj_u(p["cx"], p["cy"]) - proj_u(prev["cx"], prev["cy"]) - prev["longSide"] / 2.0 - p["longSide"] / 2.0
                        spans.append(max(600, _round5(gap)))
            elif len(cols_on_beam) >= 2:
                for k, c in enumerate(cols_on_beam):
                    supports.append({
                        "trucLabel": chr(65 + min(25, k)),
                        "len": max(800, _round5(c["w"] + 400)),
                        "colW": width,
                        "colH": min(700, defaults["damHDam"]),
                    })
                    if k > 0:
                        prev = cols_on_beam[k - 1]
                        gap = proj_u(c["cx"], c["cy"]) - proj_u(prev["cx"], prev["cy"]) - supports[k - 1]["len"] / 2.0 - supports[k]["len"] / 2.0
                        spans.append(max(800, _round5(gap)))
            else:
                supports = [
                    {"trucLabel": "B", "len": 1400, "colW": width, "colH": 700},
                    {"trucLabel": "A", "len": 1400, "colW": width, "colH": 700},
                ]
                spans = [max(1200, length)]

            world_inst = {
                "ten": ten,
                "kind": "dam_mong",
                "cx": round(cx, 1),
                "cy": round(cy, 1),
                "B": width,
                "L": length,
                "ang": chain_ang,
                "poly": chain_poly,
                "p0": [round(p0["x"], 1), round(p0["y"], 1)],
                "p1": [round(p1["x"], 1), round(p1["y"], 1)],
            }
            candidates.append({
                "id": "dxf-dam-%s" % box["id"],
                "selected": True,
                "kind": "dam_mong",
                "ten": ten,
                "soLuong": sl or 1,
                "B": width,
                "L": length,
                "H": defaults["damHDam"],
                "gocXoay": goc_xoay,
                "cotB": width,
                "cotH": defaults["damHDam"],
                "viTriCotMode": "center",
                "lechTamX": 0,
                "lechTamY": 0,
                "B_dam": width,
                "supports": supports,
                "spans": spans,
                "worldInstances": [world_inst],
                "sourceType": "dxf_geom",
                "summary": "Quét MB DXF · Dầm móng %s×%s · L=%s (%d nhịp%s)%s" % (
                    width, defaults["damHDam"], length, len(spans),
                    (" · nối %d đoạn" % len(run)) if len(run) > 1 else "",
                    (" · Xoay %s°" % goc_xoay) if goc_xoay else "",
                ),
                "warnings": [],
            })

    # Consolidate ALL items sharing the same (kind, Mark) into 1 typical configuration with summed SL
    grouped = []
    group_index = {}
    for c in candidates:
        key = "%s::%s" % (c["kind"], c["ten"].strip().upper())
        if key in group_index:
            g = grouped[group_index[key]]
            g["soLuong"] += c["soLuong"]
            g.setdefault("worldInstances", []).extend(c.get("worldInstances") or [])
            if g.get("B") != c.get("B") or g.get("L") != c.get("L"):
                msg = "Mark '%s' có nhiều kích thước hơi khác nhau — đã gom chung thành 1 điển hình." % c["ten"]
                if msg not in g["warnings"]:
                    g["warnings"].append(msg)
        else:
            group_index[key] = len(grouped)
            grouped.append(c)

    msgs = [
        "Đơn vị mặt bằng: %s (hệ số ×%g) · Đọc %d đa giác/biên dạng, %d đoạn thẳng, %d hình tròn, %d Block, %d nhãn chữ."
        % (detected_unit.upper(), scale, len(polys), len(dxf_lines), len(circles), len(inserts), len(texts))
    ]
    if not grouped:
        msgs.append(
            "Chưa nhận diện được hình học móng hợp lệ (hỗ trợ đa giác LWPOLYLINE, đường vòng khép kín LINE góc bất kỳ, ≥ 550mm hoặc 0.55m)."
        )
    else:
        c_don = sum(1 for x in grouped if x["kind"] == "mong_don")
        c_bang = sum(1 for x in grouped if x["kind"] == "mong_bang")
        c_coc = sum(1 for x in grouped if x["kind"] == "mong_coc")
        c_dam = sum(1 for x in grouped if x["kind"] == "dam_mong")
        msgs.append(
            "Phân loại tự động: %d loại Móng Đơn, %d loại Móng Băng, %d loại Móng Cọc, %d loại Dầm Móng."
            % (c_don, c_bang, c_coc, c_dam)
        )

    return {
        "candidates": grouped,
        "detectedFormat": "dxf_plan",
        "detectedUnit": detected_unit,
        "unitScaleToMm": scale,
        "stats": {
            "polys": len(polys),
            "lines": len(dxf_lines),
            "circles": len(circles),
            "inserts": len(inserts),
            "texts": len(texts),
            "xdataRecords": len(xdata_map),
        },
        "messages": msgs,
    }


def scan_foundation_plan_input(raw, unit_mode, defaults):
    trimmed = (raw or "").strip()
    if not trimmed:
        return {
            "candidates": [],
            "detectedFormat": "unknown",
            "detectedUnit": "mm",
            "unitScaleToMm": 1,
            "stats": {"polys": 0, "lines": 0, "circles": 0, "inserts": 0, "texts": 0, "xdataRecords": 0},
            "messages": ["Chưa có dữ liệu đầu vào. Hãy tải file .DXF / .JSON hoặc dán nội dung bên dưới."],
        }

    if trimmed.startswith("{") or trimmed.startswith("["):
        res = _parse_mong2_json(trimmed, defaults)
        if res is not None:
            return res

    if re.search(r"\bSECTION\b[\s\S]*\bENTITIES\b", trimmed, re.IGNORECASE) or (
        "LWPOLYLINE" in trimmed and "EOF" in trimmed
    ):
        return _parse_dxf_file(trimmed, unit_mode, defaults)

    if "\u221e" in trimmed:
        lines = [l for l in trimmed.splitlines() if "\u221e" in l]
        cands = []
        for idx, line in enumerate(lines):
            parts_cnt = len(line.split("\u221e"))
            if "LuuThongSoChungMongCoc" in line or parts_cnt > 26:
                app = "LuuThongSoChungMongCoc_SYS"
            elif "LuuThongSoChungMongDon" in line or parts_cnt <= 18:
                app = "LuuThongSoChungMongDon_SYS"
            else:
                app = "LuuThongSoChung_SYS"
            payload = re.sub(r"^1000\s*", "", line, flags=re.IGNORECASE).strip()
            c = _parse_dcepro_xdata_record(app, payload, None, None, idx)
            if c:
                cands.append(c)
        return {
            "candidates": cands,
            "detectedFormat": "xdata_text",
            "detectedUnit": "mm",
            "unitScaleToMm": 1,
            "stats": {"polys": 0, "lines": 0, "circles": 0, "inserts": 0, "texts": 0, "xdataRecords": len(cands)},
            "messages": ["Đã nhận diện %d dòng XDATA DcePro." % len(cands)],
        }

    return {
        "candidates": [],
        "detectedFormat": "unknown",
        "detectedUnit": "mm",
        "unitScaleToMm": 1,
        "stats": {"polys": 0, "lines": 0, "circles": 0, "inserts": 0, "texts": 0, "xdataRecords": 0},
        "messages": ["Không nhận diện được định dạng dữ liệu. Hỗ trợ file .DXF mặt bằng, JSON từ mong2, hoặc chuỗi XDATA DcePro."],
    }


def build_configs_from_candidates(candidates, defaults, overwrite_explicit_rebar=False):
    # Re-consolidate selected candidates sharing the same (kind, ten) so any Mark edits in Step 1 sum SL cleanly
    consolidated = []
    by_mark = {}
    for raw_c in candidates:
        if not raw_c.get("selected", True):
            continue
        c = dict(raw_c)
        c["worldInstances"] = list(raw_c.get("worldInstances") or [])
        mkey = (c.get("kind", "mong_don"), str(c.get("ten", "")).strip().upper())
        if mkey in by_mark:
            existing = consolidated[by_mark[mkey]]
            existing["soLuong"] = max(1, int(existing.get("soLuong", 1))) + max(1, int(c.get("soLuong", 1)))
            existing["worldInstances"].extend(c["worldInstances"])
        else:
            by_mark[mkey] = len(consolidated)
            consolidated.append(c)

    mong_don = []
    mong_bang = []
    mong_coc = []
    dam_mong = []
    stamp = int(time.time() * 1000)

    for idx, c in enumerate(consolidated):
        kind = c["kind"]
        world_insts = list(c.get("worldInstances") or [])

        if kind == "mong_don":
            exp = {} if overwrite_explicit_rebar else (c.get("explicitDon") or {})
            cover_day = defaults["coverDay"] if overwrite_explicit_rebar else (c.get("explicitCoverDay") or defaults["coverDay"])
            cover_canh = defaults["coverCanh"] if overwrite_explicit_rebar else (c.get("explicitCoverCanh") or defaults["coverCanh"])
            mong_don.append({
                "id": "scan-md-%d-%d" % (stamp, idx),
                "ten": c["ten"],
                "soLuong": max(1, int(c.get("soLuong", 1))),
                "tiLe": exp.get("tiLe", 25),
                "B": c["B"],
                "L": c["L"],
                "H": c.get("H") or defaults["donH"],
                "hMep": c.get("hMep") if c.get("hMep") is not None else defaults["donHMep"],
                "shapePreset": c.get("shapePreset") or ("custom" if c.get("customPolygon") else "rect"),
                "customPolygon": c.get("customPolygon"),
                "gocXoay": c.get("gocXoay"),
                "extraColumns": c.get("extraColumns"),
                "worldInstances": world_insts,
                "caoTrinhDay": c.get("caoTrinh") if c.get("caoTrinh") is not None else defaults["caoTrinhDefault"],
                "lotDay": c.get("explicitLotDay") if c.get("explicitLotDay") is not None else defaults["lotDay"],
                "lotChiaMatCat": c.get("explicitLotChiaMC") if c.get("explicitLotChiaMC") is not None else defaults["lotChiaMatCat"],
                "lotChiaMatBang": c.get("explicitLotChiaMB") if c.get("explicitLotChiaMB") is not None else defaults["lotChiaMatBang"],
                "coverDay": cover_day,
                "coverCanh": cover_canh,
                "cotB": c.get("cotB") or defaults["donCotB"],
                "cotH": c.get("cotH") or defaults["donCotH"],
                "goCoCot": 50,
                "viTriCotMode": c.get("viTriCotMode", "center"),
                "lechTamX": c.get("lechTamX", 0),
                "lechTamY": c.get("lechTamY", 0),
                "giangMode": defaults["donGiangMode"],
                "giangH": exp.get("giangH", defaults["donGiangH"]),
                "caoTuDinhDaiDenMatGiang": exp.get("caoTuDinhDaiDenMatGiang", defaults["donCaoCoCot"]),
                "chieuCaoCotVeThem": 500,
                "thepCotD": defaults["donCotD"],
                "thepCotChanL": defaults["donCotChanL"],
                "thepDaiD": defaults["donDaiD"],
                "thepDaiA": defaults["donDaiA"],
                "thepPhuongX": exp.get("thepPhuongX") or {
                    "d": defaults["donD"],
                    "a": defaults["donA"],
                    "hasHook": defaults["donHook"],
                    "hookLen": defaults["donHookLen"],
                },
                "thepPhuongY": exp.get("thepPhuongY") or {
                    "d": defaults["donD"],
                    "a": defaults["donA"],
                    "hasHook": defaults["donHook"],
                    "hookLen": defaults["donHookLen"],
                },
                "ghiChu": c.get("summary", ""),
            })
        elif kind == "mong_bang":
            exp = {} if overwrite_explicit_rebar else (c.get("explicitBang") or {})
            b_dam = c.get("B_dam") if c.get("B_dam") is not None else defaults["bangBDam"]
            canh_trai = c.get("canhTrai") if c.get("canhTrai") is not None else defaults["bangCanhTrai"]
            canh_phai = c.get("canhPhai") if c.get("canhPhai") is not None else defaults["bangCanhPhai"]
            strip_cols = c.get("stripCols") or [
                {"trucLabel": "C", "bCot": c.get("cotB") or 300, "align": "center"},
                {"trucLabel": "B", "bCot": 300, "align": "center"},
                {"trucLabel": "A", "bCot": 300, "align": "center"},
            ]
            spans_list = c.get("spans") if (c.get("spans") and len(c["spans"]) >= 1) else [4000, 4500]
            mong_bang.append({
                "id": "scan-mb-%d-%d" % (stamp, idx),
                "ten": c["ten"],
                "soLuong": max(1, int(c.get("soLuong", 1))),
                "tiLeMatDung": 50,
                "tiLeMatCat": 25,
                "worldInstances": world_insts,
                "columns": [
                    {
                        "id": "col-%d-%d-%d" % (stamp, idx, ci),
                        "trucLabel": col["trucLabel"],
                        "bCot": col["bCot"],
                        "trucAlign": col.get("align", "center"),
                    }
                    for ci, col in enumerate(strip_cols)
                ],
                "spans": [
                    {"id": "sp-%d-%d-%d" % (stamp, idx, si), "L_nhip": L_nhip}
                    for si, L_nhip in enumerate(spans_list)
                ],
                "chieuCaoCoCot": 250,
                "B_dam": b_dam,
                "canhTrai": canh_trai,
                "canhPhai": canh_phai,
                "H_dam": c.get("H") or defaults["bangHDam"],
                "hVat": c.get("hVat") if c.get("hVat") is not None else defaults["bangHVat"],
                "hMep": c.get("hMep") if c.get("hMep") is not None else defaults["bangHMep"],
                "vaiMepDam": 50,
                "caoTrinhTop": c.get("caoTrinh") if c.get("caoTrinh") is not None else -0.5,
                "lotDay": c.get("explicitLotDay") if c.get("explicitLotDay") is not None else defaults["lotDay"],
                "lotChia": c.get("explicitLotChiaMC") if c.get("explicitLotChiaMC") is not None else defaults["lotChiaMatCat"],
                "cover": defaults["coverDamBang"] if overwrite_explicit_rebar else (c.get("explicitCoverDam") or defaults["coverDamBang"]),
                "thepTrenCount": exp.get("thepTrenCount", defaults["bangTrenN"]),
                "thepTrenD": exp.get("thepTrenD", defaults["bangTrenD"]),
                "thepTrenMocLen": defaults["bangTrenMoc"],
                "thepDuoiCount": exp.get("thepDuoiCount", defaults["bangDuoiN"]),
                "thepDuoiD": exp.get("thepDuoiD", defaults["bangDuoiD"]),
                "thepDuoiMocLen": defaults["bangDuoiMoc"],
                "thepDocCanhCount": defaults["bangDocCanhN"],
                "thepDocCanhD": defaults["bangDocCanhD"],
                "thepGiaCount": exp.get("thepGiaCount", defaults["bangGiaN"]),
                "thepGiaD": exp.get("thepGiaD", defaults["bangGiaD"]),
                "thepDaiD": exp.get("thepDaiD", defaults["bangDaiD"]),
                "thepDaiA": exp.get("thepDaiA", defaults["bangDaiA"]),
                "thepDaiGiaD": defaults["bangDaiGiaD"],
                "thepDaiGiaA": defaults["bangDaiGiaA"],
                "thepNgangCanhD": exp.get("thepNgangCanhD", defaults["bangNgangCanhD"]),
                "thepNgangCanhA": exp.get("thepNgangCanhA", defaults["bangNgangCanhA"]),
                "thepNgangCanhHook": defaults["bangNgangCanhHook"],
                "ghiChu": c.get("summary", ""),
            })
        elif kind == "mong_coc":
            exp = {} if overwrite_explicit_rebar else (c.get("explicitCoc") or {})
            cover_day_default = max(defaults["coverDay"], defaults["cocNgam"] + 35)
            mong_coc.append({
                "id": "scan-mc-%d-%d" % (stamp, idx),
                "ten": c["ten"],
                "soLuong": max(1, int(c.get("soLuong", 1))),
                "tiLe": exp.get("tiLe", 25),
                "B": c["B"],
                "L": c["L"],
                "H": c.get("H") or defaults["cocH"],
                "shapePreset": c.get("shapePreset") or ("custom" if c.get("customPolygon") else "rect"),
                "customPolygon": c.get("customPolygon"),
                "customPiles": c.get("customPiles"),
                "gocXoay": c.get("gocXoay"),
                "extraColumns": c.get("extraColumns"),
                "worldInstances": world_insts,
                "cocHinh": c.get("cocHinh") or defaults["cocShapeDefault"],
                "cocD": c.get("cocD") or defaults["cocDDefault"],
                "soCocX": c.get("soCocX") or 2,
                "soCocY": c.get("soCocY") or 2,
                "buocCocX": c.get("buocCocX") or 600,
                "buocCocY": c.get("buocCocY") or 600,
                "ngamCoc": exp.get("ngamCoc", defaults["cocNgam"]),
                "cocVeThem": 240,
                "rauCocCao": defaults["cocRauCao"],
                "caoTrinhMatDai": c.get("caoTrinh") if c.get("caoTrinh") is not None else -0.5,
                "lotDay": c.get("explicitLotDay") if c.get("explicitLotDay") is not None else defaults["lotDay"],
                "lotChiaMatBang": c.get("explicitLotChiaMB") if c.get("explicitLotChiaMB") is not None else defaults["lotChiaMatBang"],
                "lotChiaMatCat": c.get("explicitLotChiaMC") if c.get("explicitLotChiaMC") is not None else defaults["lotChiaMatCat"],
                "coverDay": cover_day_default if overwrite_explicit_rebar else (c.get("explicitCoverDay") or cover_day_default),
                "coverTren": defaults["coverTren"] if overwrite_explicit_rebar else (c.get("explicitCoverTren") or defaults["coverTren"]),
                "coverCanh": defaults["coverCanh"] if overwrite_explicit_rebar else (c.get("explicitCoverCanh") or defaults["coverCanh"]),
                "cotB": c.get("cotB") or 300,
                "cotH": c.get("cotH") or 220,
                "viTriCotMode": c.get("viTriCotMode", "center"),
                "lechTamX": c.get("lechTamX", 0),
                "lechTamY": c.get("lechTamY", 0),
                "chieuCaoCotVeThem": 500,
                "thepDuoiX": exp.get("thepDuoiX") or {"d": defaults["cocDuoiD"], "a": defaults["cocDuoiA"]},
                "mocDuoiLen": defaults["cocMocDuoiLen"],
                "thepDuoiY": exp.get("thepDuoiY") or {"d": defaults["cocDuoiD"], "a": defaults["cocDuoiA"]},
                "thepTrenX": exp.get("thepTrenX") or {"d": defaults["cocTrenD"], "a": defaults["cocTrenA"]},
                "thepTrenY": exp.get("thepTrenY") or {"d": defaults["cocTrenD"], "a": defaults["cocTrenA"]},
                "thepVach": exp.get("thepVach") or {"d": defaults["cocVachD"], "a": defaults["cocVachA"]},
                "soTangThepVach": defaults["cocVachTang"],
                "thepCotD": defaults["cocCotD"],
                "thepCotChanL": defaults["cocCotChanL"],
                "thepDaiD": defaults["cocDaiD"],
                "thepDaiA": defaults["cocDaiA"],
                "ghiChu": c.get("summary", ""),
            })
        else:
            exp = {} if overwrite_explicit_rebar else (c.get("explicitDam") or {})
            b_dam = c.get("B_dam") or c.get("B") or defaults["damBDam"]
            sups = c.get("supports") or [
                {"trucLabel": "B", "len": 1400, "colW": b_dam, "colH": 700},
                {"trucLabel": "A", "len": 1400, "colW": b_dam, "colH": 700},
            ]
            sp_list = c.get("spans") if (c.get("spans") and len(c["spans"]) >= 1) else [3200]
            dam_mong.append({
                "id": "scan-dm-%d-%d" % (stamp, idx),
                "ten": c["ten"],
                "soLuong": max(1, int(c.get("soLuong", 1))),
                "tiLeMatDung": 50,
                "tiLeMatCat": 25,
                "B_dam": b_dam,
                "H_dam": c.get("H") or defaults["damHDam"],
                "worldInstances": world_insts,
                "caoTrinhTop": c.get("caoTrinh") if c.get("caoTrinh") is not None else -0.5,
                "cover": defaults["coverDamBang"] if overwrite_explicit_rebar else (c.get("explicitCoverDam") or defaults["coverDamBang"]),
                "lotDay": c.get("explicitLotDay") if c.get("explicitLotDay") is not None else defaults["lotDay"],
                "lotChiaMatCat": c.get("explicitLotChiaMC") if c.get("explicitLotChiaMC") is not None else defaults["lotChiaMatCat"],
                "supportTopExt": 500,
                "supportBotExt": 350,
                "supports": [
                    {
                        "id": "sup-%d-%d-%d" % (stamp, idx, si),
                        "trucLabel": s["trucLabel"],
                        "supportLen": s["len"],
                        "colW": s["colW"],
                        "colH": s["colH"],
                    }
                    for si, s in enumerate(sups)
                ],
                "spans": [
                    {
                        "id": "sp-%d-%d-%d" % (stamp, idx, si),
                        "L_thongThuy": L_tt,
                        "vungGoiLen": min(900, int(round(L_tt * 0.28))),
                        "hasMidCrossBeam": False,
                        "midCrossW": 300,
                        "midCrossH": 300,
                    }
                    for si, L_tt in enumerate(sp_list)
                ],
                "thepTren1Count": exp.get("thepTren1Count", defaults["damTren1N"]),
                "thepTren1D": exp.get("thepTren1D", defaults["damTren1D"]),
                "thepTren1Moc": defaults["damTren1Moc"],
                "thepTren2Count": exp.get("thepTren2Count", defaults["damTren2N"]),
                "thepTren2D": exp.get("thepTren2D", defaults["damTren2D"]),
                "thepTren2Moc": defaults["damTren2Moc"],
                "thepDuoiCount": exp.get("thepDuoiCount", defaults["damDuoiN"]),
                "thepDuoiD": exp.get("thepDuoiD", defaults["damDuoiD"]),
                "thepDuoiMoc": defaults["damDuoiMoc"],
                "thepGiaCount": exp.get("thepGiaCount", defaults["damGiaN"]),
                "thepGiaD": exp.get("thepGiaD", defaults["damGiaD"]),
                "thepGiaNeoGoi": defaults["damGiaNeoGoi"],
                "thepDaiD": exp.get("thepDaiD", defaults["damDaiD"]),
                "thepDaiAGoi": exp.get("thepDaiAGoi", defaults["damDaiAGoi"]),
                "thepDaiANhip": exp.get("thepDaiANhip", defaults["damDaiANhip"]),
                "thepDaiCTrenD": exp.get("thepDaiCTrenD", defaults["damDaiCTrenD"]),
                "thepDaiCTrenA": exp.get("thepDaiCTrenA", defaults["damDaiCTrenA"]),
                "thepDaiCHongD": defaults["damDaiCHongD"],
                "thepDaiCHongA": defaults["damDaiCHongA"],
                "ghiChu": c.get("summary", ""),
            })

    return {
        "mongDon": mong_don,
        "mongBang": mong_bang,
        "mongCoc": mong_coc,
        "damMong": dam_mong,
    }


# ==================== SAMPLE DXF GENERATORS ====================

def _rect_dxf(x1, y1, x2, y2, layer):
    return "\n".join([
        "0", "LWPOLYLINE", "8", layer, "90", "4", "70", "1",
        "10", str(x1), "20", str(y1),
        "10", str(x2), "20", str(y1),
        "10", str(x2), "20", str(y2),
        "10", str(x1), "20", str(y2),
    ])


def _circle_dxf(cx, cy, r, layer):
    return "\n".join(["0", "CIRCLE", "8", layer, "10", str(cx), "20", str(cy), "40", str(r)])


def _text_dxf(x, y, text, layer="TEXT"):
    return "\n".join(["0", "TEXT", "8", layer, "10", str(x), "20", str(y), "40", "200", "1", text])


def _poly_dxf(pts, layer):
    arr = ["0", "LWPOLYLINE", "8", layer, "90", str(len(pts)), "70", "1"]
    for px, py in pts:
        arr.extend(["10", str(px), "20", str(py)])
    return "\n".join(arr)


def _line_dxf(x1, y1, x2, y2, layer):
    return "\n".join(["0", "LINE", "8", layer, "10", str(x1), "20", str(y1), "11", str(x2), "21", str(y2)])


def _rotated_rect_lines(cx, cy, length, width, angle_deg, layer):
    rad = math.radians(angle_deg)
    ux, uy = math.cos(rad), math.sin(rad)
    vx, vy = -uy, ux
    hl, hw = length / 2.0, width / 2.0

    def pt(u, v):
        return int(round(cx + u * ux + v * vx)), int(round(cy + u * uy + v * vy))

    p1 = pt(-hl, -hw)
    p2 = pt(hl, -hw)
    p3 = pt(hl, hw)
    p4 = pt(-hl, hw)
    return "\n".join([
        _line_dxf(p1[0], p1[1], p2[0], p2[1], layer),
        _line_dxf(p4[0], p4[1], p3[0], p3[1], layer),
    ])


SAMPLE_ARBITRARY_PLAN_DXF = "\n".join([
    "0", "SECTION", "2", "ENTITIES",
    _rect_dxf(-100, -100, 1600, 1600, "BT_LOT"),
    _rect_dxf(0, 0, 1500, 1500, "MONG_DON"),
    _rect_dxf(640, 1280, 860, 1500, "COT"),
    _text_dxf(750, -350, "MĐ1 (SL=3)"),
    _rect_dxf(3400, -100, 5000, 1500, "BT_LOT"),
    _rect_dxf(3500, 0, 4900, 1400, "DAI_COC"),
    _rect_dxf(4050, 1180, 4350, 1400, "COT"),
    _circle_dxf(3900, 400, 125, "COC"),
    _circle_dxf(4500, 400, 125, "COC"),
    _circle_dxf(3900, 1000, 125, "COC"),
    _circle_dxf(4500, 1000, 125, "COC"),
    _text_dxf(4200, -350, "ĐM4"),
    _rect_dxf(9400, 0, 10800, 1400, "DAI_COC"),
    _rect_dxf(9950, 1180, 10250, 1400, "COT"),
    _circle_dxf(9800, 400, 125, "COC"),
    _circle_dxf(10400, 400, 125, "COC"),
    _circle_dxf(9800, 1000, 125, "COC"),
    _circle_dxf(10400, 1000, 125, "COC"),
    _text_dxf(10100, -350, "ĐM4"),
    _rect_dxf(4800, 500, 9500, 900, "DAM_MONG"),
    _text_dxf(7150, 1050, "DM4"),
    _rect_dxf(0, 4000, 9650, 5400, "MONG_BANG"),
    _rect_dxf(0, 5100, 9650, 5400, "MONG_BANG"),
    _rect_dxf(0, 5100, 350, 5400, "COT"),
    _rect_dxf(4150, 5100, 4450, 5400, "COT"),
    _rect_dxf(9250, 5100, 9650, 5400, "COT"),
    _text_dxf(4800, 3650, "MB2 (SL=2)"),
    "0", "ENDSEC", "0", "EOF",
])

SAMPLE_CUSTOM_SHAPES_DXF = "\n".join([
    "0", "SECTION", "2", "ENTITIES",
    _poly_dxf([[-100, -100], [2100, -100], [2100, 1300], [1300, 1300], [1300, 2100], [-100, 2100]], "BT_LOT"),
    _poly_dxf([[0, 0], [2000, 0], [2000, 1200], [1200, 1200], [1200, 2000], [0, 2000]], "MONG_DON"),
    _rect_dxf(450, 450, 700, 700, "COT"),
    _text_dxf(900, -350, "MĐ-L1 (SL=2)"),
    _poly_dxf([[3850, -100], [5750, -100], [6000, 620], [5380, 1650], [4220, 1650], [3600, 620]], "BT_LOT"),
    _poly_dxf([[3950, 0], [5650, 0], [5900, 600], [5300, 1550], [4300, 1550], [3700, 600]], "DAI_COC"),
    _circle_dxf(4300, 450, 150, "COC"),
    _circle_dxf(5300, 450, 150, "COC"),
    _circle_dxf(4800, 1200, 150, "COC"),
    _rect_dxf(4650, 580, 4950, 830, "COT"),
    _text_dxf(4800, -350, "ĐM3 (SL=4)"),
    _poly_dxf([[7450, 0], [9750, 0], [10000, 250], [10000, 1250], [9750, 1500], [7450, 1500], [7200, 1250], [7200, 250]], "MONG_DON"),
    _rect_dxf(7750, 625, 8000, 875, "COT"),
    _rect_dxf(9200, 625, 9450, 875, "COT"),
    _text_dxf(8600, -350, "MĐ-HC2"),
    _rotated_rect_lines(3000, 4600, 5200, 400, 35, "DAM_MONG"),
    _text_dxf(3000, 4100, "DM-X1"),
    _rect_dxf(6500, 3800, 14500, 5200, "MONG_BANG"),
    _rect_dxf(6500, 4350, 14500, 4650, "MONG_BANG"),
    _rect_dxf(6500, 4350, 6800, 4650, "COT"),
    _rect_dxf(10350, 4350, 10650, 4650, "COT"),
    _rect_dxf(14200, 4350, 14500, 4650, "COT"),
    _text_dxf(10500, 3450, "MB-X1"),
    "0", "ENDSEC", "0", "EOF",
])
