# -*- coding: utf-8 -*-
"""Structural & TCVN 5574:2018 / TCVN 10304:2014 calculation engine for all 4 foundation types."""

import math
from poly_geom import (
    build_shape_preset_polygon,
    clean_polygon,
    clip_line_to_poly,
    is_rect_poly,
    min_dist_to_polygon_edges,
    offset_polygon,
    point_in_polygon,
    polygon_area,
    polygon_centroid,
)


def kg_per_meter(d_mm):
    return (float(d_mm) * float(d_mm)) / 162.0


def unit_mass_kg_per_m(d_mm):
    return 0.006165 * float(d_mm) * float(d_mm)


def clamp(val, mn, mx):
    return max(mn, min(mx, val))


def format_elevation(meters):
    m = float(meters)
    if abs(m) < 0.0005:
        return "±0.000"
    sign = "+" if m > 0 else "-"
    return "%s%.3f" % (sign, abs(m))


# ==================== 1. MÓNG ĐƠN ====================

def resolve_footing_polygon(cfg):
    custom_poly = cfg.get("customPolygon")
    if custom_poly and len(custom_poly) >= 3:
        cleaned = clean_polygon(custom_poly, 2.0)
        if len(cleaned) >= 3:
            return cleaned, not is_rect_poly(cleaned)
    preset = cfg.get("shapePreset")
    if preset and preset not in ("rect", "custom"):
        poly = build_shape_preset_polygon(
            preset, float(cfg["B"]), float(cfg["L"]), cfg.get("cutW"), cfg.get("cutH")
        )
        return poly, not is_rect_poly(poly)
    rect = build_shape_preset_polygon("rect", float(cfg["B"]), float(cfg["L"]))
    return rect, False


def compute_footing(cfg):
    B = float(cfg["B"])
    L = float(cfg["L"])
    H = float(cfg["H"])
    h_mep = float(cfg["hMep"])
    cot_b = float(cfg["cotB"])
    cot_h = float(cfg["cotH"])
    half_b = B / 2.0
    half_l = L / 2.0
    half_cot_b = cot_b / 2.0
    half_cot_h = cot_h / 2.0

    outline_polygon, is_polygonal = resolve_footing_polygon(cfg)
    dien_tich_m2 = round(polygon_area(outline_polygon) / 1e6, 3)

    raw_cx = float(cfg.get("lechTamX", 0))
    raw_cy = float(cfg.get("lechTamY", 0))
    mode = cfg.get("viTriCotMode", "center")

    if mode == "center":
        if is_polygonal and not point_in_polygon({"x": 0.0, "y": 0.0}, outline_polygon, 2.0):
            cent = polygon_centroid(outline_polygon)
            raw_cx = round(cent["x"])
            raw_cy = round(cent["y"])
        else:
            raw_cx = 0.0
            raw_cy = 0.0
    elif mode == "top_flush":
        raw_cx = float(cfg.get("lechTamX", 0))
        raw_cy = half_l - half_cot_h

    max_cx = max(0.0, half_b - half_cot_b)
    max_cy = max(0.0, half_l - half_cot_h)
    col_cx = clamp(raw_cx, -max_cx, max_cx)
    col_cy = clamp(raw_cy, -max_cy, max_cy)

    col_left = col_cx - half_cot_b
    col_right = col_cx + half_cot_b
    col_top = col_cy + half_cot_h
    col_bot = col_cy - half_cot_h

    dx_left = round(col_left - (-half_b))
    dx_right = round(half_b - col_right)
    dy_top = round(half_l - col_top)
    dy_bot = round(col_bot - (-half_l))

    g = max(0.0, float(cfg.get("goCoCot", 50)))
    ped_left = max(-half_b, col_left - g)
    ped_right = min(half_b, col_right + g)
    ped_top = min(half_l, col_top + g)
    ped_bot = max(-half_l, col_bot - g)

    all_columns = [
        {"id": "col-primary", "x": col_cx, "y": col_cy, "b": cot_b, "h": cot_h}
    ] + list(cfg.get("extraColumns") or [])

    h_vat = max(0.0, H - h_mep)
    cao_trinh_day = float(cfg["caoTrinhDay"])
    cao_trinh_dinh_dai = cao_trinh_day + H / 1000.0
    cao_trinh_mat_giang = cao_trinh_dinh_dai + float(cfg["caoTuDinhDaiDenMatGiang"]) / 1000.0

    cover_canh = float(cfg["coverCanh"])
    cover_day = float(cfg["coverDay"])
    lot_day = float(cfg["lotDay"])

    avail_spread_y = max(0.0, L - 2.0 * cover_canh)
    avail_spread_x = max(0.0, B - 2.0 * cover_canh)

    tx = cfg["thepPhuongX"]
    ty = cfg["thepPhuongY"]
    ax = max(50.0, float(tx["a"]))
    ay = max(50.0, float(ty["a"]))
    hook_x = 2.0 * max(0.0, float(tx.get("hookLen", 150))) if tx.get("hasHook") else 0.0
    hook_y = 2.0 * max(0.0, float(ty.get("hookLen", 150))) if ty.get("hasHook") else 0.0

    so_thanh_x = max(2, int(math.floor(avail_spread_y / ax)) + 1)
    so_thanh_y = max(2, int(math.floor(avail_spread_x / ay)) + 1)
    chieu_dai_x = max(100.0, B - 2.0 * cover_canh + hook_x)
    chieu_dai_y = max(100.0, L - 2.0 * cover_canh + hook_y)
    total_len_xm = (so_thanh_x * chieu_dai_x) / 1000.0
    total_len_ym = (so_thanh_y * chieu_dai_y) / 1000.0

    if is_polygonal:
        inner_poly = offset_polygon(outline_polygon, -max(20.0, cover_canh))
        if len(inner_poly) >= 3:
            count_x = 0
            sum_x = 0.0
            y = -half_l + cover_canh
            end_y = half_l - cover_canh
            while y <= end_y + 1.0:
                for s, e in clip_line_to_poly(inner_poly, "x", y):
                    count_x += 1
                    sum_x += max(100.0, e - s + hook_x)
                y += ax
            if count_x > 0:
                so_thanh_x = count_x
                total_len_xm = sum_x / 1000.0
                chieu_dai_x = round(sum_x / count_x)

            count_y = 0
            sum_y = 0.0
            x = -half_b + cover_canh
            end_x = half_b - cover_canh
            while x <= end_x + 1.0:
                for s, e in clip_line_to_poly(inner_poly, "y", x):
                    count_y += 1
                    sum_y += max(100.0, e - s + hook_y)
                x += ay
            if count_y > 0:
                so_thanh_y = count_y
                total_len_ym = sum_y / 1000.0
                chieu_dai_y = round(sum_y / count_y)

    wt_x = total_len_xm * kg_per_meter(tx["d"])
    wt_y = total_len_ym * kg_per_meter(ty["d"])
    kl_1_mong = round(wt_x + wt_y, 2)
    kl_tong = round(kl_1_mong * max(1, int(cfg["soLuong"])), 2)

    checks = []
    if cover_day < 40:
        checks.append({
            "code": "TCVN-BV",
            "label": "Lớp bảo vệ đáy móng",
            "status": "error",
            "detail": "c = %g mm < 40 mm (TCVN 5574:2018 yêu cầu tối thiểu 40–50 mm khi có BT lót)." % cover_day,
        })
    elif cover_day < 50 and lot_day == 0:
        checks.append({
            "code": "TCVN-BV",
            "label": "Lớp bảo vệ đáy móng",
            "status": "warn",
            "detail": "c = %g mm khi không có BT lót nên lấy >= 70 mm." % cover_day,
        })
    else:
        checks.append({
            "code": "TCVN-BV",
            "label": "Lớp bảo vệ đáy móng",
            "status": "ok",
            "detail": "c = %g mm đạt chuẩn TCVN (BT lót %g mm)." % (cover_day, lot_day),
        })

    min_d = min(tx["d"], ty["d"])
    if min_d < 10:
        checks.append({
            "code": "TCVN-D",
            "label": "Đường kính cốt thép đài",
            "status": "error",
            "detail": "Ø%g < Ø10 mm (tối thiểu Ø10 theo cấu tạo đài móng)." % min_d,
        })
    else:
        checks.append({
            "code": "TCVN-D",
            "label": "Đường kính cốt thép đài",
            "status": "ok",
            "detail": "Phương X Ø%g, phương Y Ø%g đạt (>= Ø10)." % (tx["d"], ty["d"]),
        })

    max_a = max(tx["a"], ty["a"])
    min_a = min(tx["a"], ty["a"])
    if max_a > 250:
        checks.append({
            "code": "TCVN-A",
            "label": "Bước cốt thép lưới đáy",
            "status": "warn",
            "detail": "Khoảng cách a = %g mm > 250 mm (nên bố trí a <= 200–250 mm)." % max_a,
        })
    elif min_a < 100:
        checks.append({
            "code": "TCVN-A",
            "label": "Bước cốt thép lưới đáy",
            "status": "warn",
            "detail": "Bước thép dày (%g mm), kiểm tra thi công đổ bê tông." % min_a,
        })
    else:
        checks.append({
            "code": "TCVN-A",
            "label": "Bước cốt thép lưới đáy",
            "status": "ok",
            "detail": "Bước thép aX=%g, aY=%g mm hợp lý (100–250 mm)." % (tx["a"], ty["a"]),
        })

    if h_mep > H:
        checks.append({
            "code": "GEOM-H",
            "label": "Chiều cao mép & đài móng",
            "status": "error",
            "detail": "h_mép (%g) > H (%g mm) không hợp lệ." % (h_mep, H),
        })
    elif h_mep < 150:
        checks.append({
            "code": "GEOM-H",
            "label": "Chiều cao mép đài",
            "status": "warn",
            "detail": "h_mép = %g mm < 150 mm, nên chọn tối thiểu 150–200 mm." % h_mep,
        })
    else:
        checks.append({
            "code": "GEOM-H",
            "label": "Chiều cao đài & mép vát",
            "status": "ok",
            "detail": "H = %g mm, h_mép = %g mm, vát %g mm." % (H, h_mep, h_vat),
        })

    if cot_b > B or cot_h > L:
        checks.append({
            "code": "GEOM-COL",
            "label": "Kích thước cột & đài",
            "status": "error",
            "detail": "Cột (%gx%g) lớn hơn đài (%gx%g)." % (cot_b, cot_h, B, L),
        })
    elif is_polygonal:
        out_cols = [c for c in all_columns if not point_in_polygon({"x": c["x"], "y": c["y"]}, outline_polygon, 20.0)]
        if out_cols:
            checks.append({
                "code": "GEOM-POLY",
                "label": "Cột nằm trong đa giác đài",
                "status": "warn",
                "detail": "Có %d tâm cột gần/ngoài mép biên dạng đa giác." % len(out_cols),
            })
        else:
            checks.append({
                "code": "GEOM-POLY",
                "label": "Biên dạng đài đa giác",
                "status": "ok",
                "detail": "%d đỉnh · Diện tích %.2f m² · %d cột." % (len(outline_polygon), dien_tich_m2, len(all_columns)),
            })

    return {
        "colCx": col_cx,
        "colCy": col_cy,
        "allColumns": all_columns,
        "outlinePolygon": outline_polygon,
        "isPolygonal": is_polygonal,
        "dienTichM2": dien_tich_m2,
        "dxLeft": dx_left,
        "dxRight": dx_right,
        "dyTop": dy_top,
        "dyBot": dy_bot,
        "pedLeft": ped_left,
        "pedRight": ped_right,
        "pedTop": ped_top,
        "pedBot": ped_bot,
        "hVat": h_vat,
        "caoTrinhMatGiang": cao_trinh_mat_giang,
        "caoTrinhDinhDai": cao_trinh_dinh_dai,
        "soThanhX": so_thanh_x,
        "chieuDaiThanhX": chieu_dai_x,
        "soThanhY": so_thanh_y,
        "chieuDaiThanhY": chieu_dai_y,
        "khoiLuongThepDay1Mong": kl_1_mong,
        "khoiLuongThepDayTong": kl_tong,
        "checks": checks,
        "hasError": any(c["status"] == "error" for c in checks),
        "hasWarn": any(c["status"] == "warn" for c in checks),
    }


# ==================== 2. MÓNG BĂNG ====================

def compute_strip_footing(cfg):
    col_layouts = []
    span_layouts = []
    cursor_x = 0.0
    cols = cfg.get("columns") or []
    spans = cfg.get("spans") or []
    col_count = max(2, len(cols))

    for i in range(col_count):
        col = cols[i] if i < len(cols) else {
            "id": "col-auto-%d" % i,
            "trucLabel": str(i + 1),
            "bCot": 300,
            "trucAlign": "center",
        }
        b_cot = max(150.0, float(col.get("bCot") or 300))
        x_start = cursor_x
        x_end = x_start + b_cot
        align = col.get("trucAlign", "center")
        axis_x = x_start + b_cot / 2.0
        if align == "left":
            axis_x = x_start
        elif align == "right":
            axis_x = x_end

        col_layouts.append({
            "id": col["id"],
            "trucLabel": col["trucLabel"],
            "bCot": b_cot,
            "trucAlign": align,
            "xStart": x_start,
            "xEnd": x_end,
            "axisX": axis_x,
        })
        cursor_x = x_end

        if i < col_count - 1:
            sp = spans[i] if i < len(spans) else {"id": "sp-auto-%d" % i, "L_nhip": 4000}
            l_nhip = max(500.0, float(sp.get("L_nhip") or 4000))
            span_layouts.append({
                "id": sp["id"],
                "index": i,
                "L_nhip": l_nhip,
                "xStart": cursor_x,
                "xEnd": cursor_x + l_nhip,
                "midX": cursor_x + l_nhip / 2.0,
            })
            cursor_x += l_nhip

    tong_l = round(cursor_x)
    canh_trai = float(cfg["canhTrai"])
    canh_phai = float(cfg["canhPhai"])
    b_dam = float(cfg["B_dam"])
    h_dam = float(cfg["H_dam"])
    h_vat = float(cfg["hVat"])
    h_mep = float(cfg["hMep"])
    cover = float(cfg["cover"])
    lot_day = float(cfg["lotDay"])

    B_mong = max(200.0, canh_trai) + b_dam + max(0.0, canh_phai)
    h_tren = max(0.0, h_dam - h_vat - h_mep)
    cao_trinh_day = round(float(cfg["caoTrinhTop"]) - h_dam / 1000.0, 3)

    axis_gaps = [round(col_layouts[i]["axisX"] - col_layouts[i - 1]["axisX"]) for i in range(1, len(col_layouts))]
    axis_total_span = round(col_layouts[-1]["axisX"] - col_layouts[0]["axisX"]) if len(col_layouts) >= 2 else tong_l

    bar_len_long = max(500.0, tong_l - 2.0 * cover)
    len_bar1 = (bar_len_long + 2.0 * float(cfg["thepTrenMocLen"])) / 1000.0
    len_bar2 = (bar_len_long + 2.0 * float(cfg["thepDuoiMocLen"])) / 1000.0
    len_bar3 = bar_len_long / 1000.0
    len_bar4 = max(400.0, tong_l - 300.0) / 1000.0

    stirrup_w = max(100.0, b_dam - 2.0 * cover)
    stirrup_h = max(150.0, h_dam - 2.0 * cover)
    stirrup_perim_m = (2.0 * (stirrup_w + stirrup_h) + 120.0) / 1000.0
    total_clear_span = sum(s["L_nhip"] for s in span_layouts)
    count_dai5 = max(2, int(math.floor(total_clear_span / max(50.0, float(cfg["thepDaiA"])))) + 1)
    count_dai6 = max(2, int(math.floor(total_clear_span / max(100.0, float(cfg["thepDaiGiaA"])))) + 1)
    len_dai6_m = (stirrup_w + 100.0) / 1000.0

    so_thanh_ngang_canh = max(2, int(math.floor((tong_l - 2.0 * cover) / max(50.0, float(cfg["thepNgangCanhA"])))) + 1)
    chieu_dai_thanh_mb = max(200.0, B_mong - 2.0 * cover + 2.0 * float(cfg["thepNgangCanhHook"]))

    w1 = float(cfg["thepTrenCount"]) * len_bar1 * unit_mass_kg_per_m(cfg["thepTrenD"])
    w2 = float(cfg["thepDuoiCount"]) * len_bar2 * unit_mass_kg_per_m(cfg["thepDuoiD"])
    w3 = float(cfg["thepDocCanhCount"]) * len_bar3 * unit_mass_kg_per_m(cfg["thepDocCanhD"])
    w4 = float(cfg["thepGiaCount"]) * len_bar4 * unit_mass_kg_per_m(cfg["thepGiaD"])
    w5 = count_dai5 * stirrup_perim_m * unit_mass_kg_per_m(cfg["thepDaiD"])
    w6 = count_dai6 * len_dai6_m * unit_mass_kg_per_m(cfg["thepDaiGiaD"])
    w_mb = so_thanh_ngang_canh * (chieu_dai_thanh_mb / 1000.0) * unit_mass_kg_per_m(cfg["thepNgangCanhD"])

    kl_1_mong = round(w1 + w2 + w3 + w4 + w5 + w6 + w_mb, 1)
    kl_tong = round(kl_1_mong * max(1, int(cfg["soLuong"])), 1)

    checks = []
    if h_vat + h_mep > h_dam:
        checks.append({
            "code": "H-GEO",
            "label": "Chiều cao dầm & cánh",
            "status": "error",
            "detail": "h_vát (%g) + h_mép (%g) > H_dầm (%g mm)" % (h_vat, h_mep, h_dam),
        })
    elif h_mep < 150:
        checks.append({
            "code": "H-MEP",
            "label": "Chiều cao mép cánh",
            "status": "warn",
            "detail": "h_mép = %g mm < 150 mm (TCVN khuyến nghị ≥ 150 mm)" % h_mep,
        })
    else:
        checks.append({
            "code": "H-GEO",
            "label": "Tiết diện dầm & cánh",
            "status": "ok",
            "detail": "H = %g mm (%g/%g/%g), B = %g mm" % (h_dam, h_tren, h_vat, h_mep, B_mong),
        })

    if b_dam < 250:
        checks.append({
            "code": "B-DAM",
            "label": "Bề rộng dầm móng",
            "status": "warn",
            "detail": "B_dầm = %g mm hơi mảnh (< 250 mm)" % b_dam,
        })
    else:
        checks.append({
            "code": "B-DAM",
            "label": "Bề rộng dầm móng",
            "status": "ok",
            "detail": "B_dầm = %g mm (Đạt)" % b_dam,
        })

    if cover < 35:
        checks.append({
            "code": "COV",
            "label": "Lớp BT bảo vệ",
            "status": "error",
            "detail": "Lớp bảo vệ %g mm < 35 mm (BT tiếp đất theo TCVN cần ≥ 40–50 mm)" % cover,
        })
    else:
        checks.append({
            "code": "COV",
            "label": "Lớp BT bảo vệ",
            "status": "ok",
            "detail": "c = %g mm, BT lót %g mm (Đạt)" % (cover, lot_day),
        })

    if float(cfg["thepDaiA"]) > 250:
        checks.append({
            "code": "DAI",
            "label": "Bước thép đai dầm ⑤",
            "status": "warn",
            "detail": "a = %g mm > 250 mm (nên bố trí ≤ 200–250 mm)" % cfg["thepDaiA"],
        })
    else:
        checks.append({
            "code": "DAI",
            "label": "Thép đai dầm ⑤",
            "status": "ok",
            "detail": "Ø%ga%g + đai C Ø%ga%g" % (cfg["thepDaiD"], cfg["thepDaiA"], cfg["thepDaiGiaD"], cfg["thepDaiGiaA"]),
        })

    if float(cfg["thepNgangCanhD"]) < 10 or float(cfg["thepNgangCanhA"]) > 250:
        checks.append({
            "code": "WING-REBAR",
            "label": "Thép bản cánh MB & ③",
            "status": "warn",
            "detail": "Kiểm tra lại Ø%ga%g (nên ≥ Ø10 và a ≤ 200–250)" % (cfg["thepNgangCanhD"], cfg["thepNgangCanhA"]),
        })
    else:
        checks.append({
            "code": "WING-REBAR",
            "label": "Thép bản cánh MB & ③",
            "status": "ok",
            "detail": "MB: Ø%ga%g | Dọc ③: %gØ%g" % (
                cfg["thepNgangCanhD"], cfg["thepNgangCanhA"], cfg["thepDocCanhCount"], cfg["thepDocCanhD"]
            ),
        })

    return {
        "tongL": tong_l,
        "B_mong": B_mong,
        "hTren": h_tren,
        "caoTrinhDay": cao_trinh_day,
        "colLayouts": col_layouts,
        "spanLayouts": span_layouts,
        "axisGaps": axis_gaps,
        "axisTotalSpan": axis_total_span,
        "soThanhNgangCanh": so_thanh_ngang_canh,
        "chieuDaiThanhMB": chieu_dai_thanh_mb,
        "khoiLuong1Mong": kl_1_mong,
        "khoiLuongTong": kl_tong,
        "checks": checks,
        "hasError": any(c["status"] == "error" for c in checks),
        "hasWarn": any(c["status"] == "warn" for c in checks),
    }


# ==================== 3. MÓNG CỌC ====================

def resolve_pile_cap_polygon(cfg):
    custom_poly = cfg.get("customPolygon")
    if custom_poly and len(custom_poly) >= 3:
        cleaned = clean_polygon(custom_poly, 2.0)
        if len(cleaned) >= 3:
            return cleaned, not is_rect_poly(cleaned)
    preset = cfg.get("shapePreset")
    if preset and preset not in ("rect", "custom"):
        poly = build_shape_preset_polygon(
            preset, float(cfg["B"]), float(cfg["L"]), cfg.get("cutW"), cfg.get("cutH")
        )
        return poly, not is_rect_poly(poly)
    return build_shape_preset_polygon("rect", float(cfg["B"]), float(cfg["L"])), False


def compute_pile_cap(cfg):
    B = float(cfg["B"])
    L = float(cfg["L"])
    H = float(cfg["H"])
    half_b = B / 2.0
    half_l = L / 2.0
    cot_b = float(cfg["cotB"])
    cot_h = float(cfg["cotH"])
    outline_polygon, is_polygonal = resolve_pile_cap_polygon(cfg)
    dien_tich_m2 = round(polygon_area(outline_polygon) / 1e6, 3)

    col_cx = 0.0
    col_cy = 0.0
    mode = cfg.get("viTriCotMode", "center")
    if mode == "top_flush":
        col_cx = float(cfg.get("lechTamX", 0))
        col_cy = half_l - cot_h / 2.0
    elif mode == "custom":
        col_cx = float(cfg.get("lechTamX", 0))
        col_cy = float(cfg.get("lechTamY", 0))
    elif is_polygonal:
        cent = polygon_centroid(outline_polygon)
        col_cx = round(cent["x"])
        col_cy = round(cent["y"])

    col_cx = clamp(col_cx, -half_b + cot_b / 2.0, half_b - cot_b / 2.0)
    col_cy = clamp(col_cy, -half_l + cot_h / 2.0, half_l - cot_h / 2.0)

    dx_left = round(half_b + col_cx - cot_b / 2.0)
    dx_right = round(half_b - col_cx - cot_b / 2.0)
    dy_top = round(half_l - col_cy - cot_h / 2.0)
    dy_bot = round(half_l + col_cy - cot_h / 2.0)

    all_columns = [
        {"id": "col-primary", "x": col_cx, "y": col_cy, "b": cot_b, "h": cot_h}
    ] + list(cfg.get("extraColumns") or [])

    nx = max(1, int(round(cfg["soCocX"])))
    ny = max(1, int(round(cfg["soCocY"])))
    custom_piles = cfg.get("customPiles")
    piles = []
    if custom_piles:
        for idx, p in enumerate(custom_piles):
            piles.append({
                "id": p.get("id") or ("cp-%d" % idx),
                "x": round(float(p["x"])),
                "y": round(float(p["y"])),
                "d": p.get("d"),
            })
    else:
        bx = float(cfg["buocCocX"])
        by = float(cfg["buocCocY"])
        total_span_x = (nx - 1) * bx
        total_span_y = (ny - 1) * by
        for iy in range(ny):
            for ix in range(nx):
                px = 0.0 if nx == 1 else -total_span_x / 2.0 + ix * bx
                py = 0.0 if ny == 1 else -total_span_y / 2.0 + iy * by
                piles.append({"id": "p-%d-%d" % (ix, iy), "x": round(px), "y": round(py)})

    tong_so_coc = len(piles)
    min_px = min((p["x"] for p in piles), default=0)
    max_px = max((p["x"] for p in piles), default=0)
    min_py = min((p["y"] for p in piles), default=0)
    max_py = max((p["y"] for p in piles), default=0)

    meps_coc_x = round(min(min_px - (-half_b), half_b - max_px))
    meps_coc_y = round(min(min_py - (-half_l), half_l - max_py))
    cao_trinh_day_dai = round(float(cfg["caoTrinhMatDai"]) - H / 1000.0, 3)

    min_edge_dist = float("inf")
    for p in piles:
        d = min_dist_to_polygon_edges(p, outline_polygon)
        if d < min_edge_dist:
            min_edge_dist = d
    min_edge_dist = round(min_edge_dist) if math.isfinite(min_edge_dist) else min(meps_coc_x, meps_coc_y)

    min_pile_spacing = float("inf")
    for i in range(len(piles)):
        for j in range(i + 1, len(piles)):
            dist = math.hypot(piles[i]["x"] - piles[j]["x"], piles[i]["y"] - piles[j]["y"])
            if dist < min_pile_spacing:
                min_pile_spacing = dist
    min_pile_spacing = round(min_pile_spacing) if math.isfinite(min_pile_spacing) else round(float(cfg["buocCocX"]))

    cover_canh = float(cfg["coverCanh"])
    cover_day = float(cfg["coverDay"])
    cover_tren = float(cfg["coverTren"])
    moc_duoi_len = float(cfg["mocDuoiLen"])
    b1 = cfg["thepDuoiX"]
    b2 = cfg["thepDuoiY"]
    t1 = cfg["thepTrenX"]
    t2 = cfg["thepTrenY"]
    vach = cfg["thepVach"]

    span_x = max(200.0, B - 2.0 * cover_canh)
    span_y = max(200.0, L - 2.0 * cover_canh)
    so_b1 = int(math.floor(span_y / max(50.0, float(b1["a"])))) + 1
    so_b2 = int(math.floor(span_x / max(50.0, float(b2["a"])))) + 1
    so_t1 = int(math.floor(span_y / max(50.0, float(t1["a"])))) + 1
    so_t2 = int(math.floor(span_x / max(50.0, float(t2["a"])))) + 1

    down_leg_t = max(200.0, H - cover_day - cover_tren)
    total_b1_m = (so_b1 * (span_x + 2.0 * moc_duoi_len)) / 1000.0
    total_b2_m = (so_b2 * (span_y + 2.0 * moc_duoi_len)) / 1000.0
    total_t1_m = (so_t1 * (max(200.0, B - 2.0 * (cover_canh + 25.0)) + 2.0 * down_leg_t)) / 1000.0
    total_t2_m = (so_t2 * (max(200.0, L - 2.0 * (cover_canh + 25.0)) + 2.0 * down_leg_t)) / 1000.0

    perim_mm = 2.0 * (span_x + span_y)
    if is_polygonal:
        inner_bot = offset_polygon(outline_polygon, -max(20.0, cover_canh))
        if len(inner_bot) >= 3:
            p_len = 0.0
            for i in range(len(inner_bot)):
                pa = inner_bot[i]
                pb = inner_bot[(i + 1) % len(inner_bot)]
                p_len += math.hypot(pb["x"] - pa["x"], pb["y"] - pa["y"])
            if p_len > 200.0:
                perim_mm = p_len

            def clip_sum(step, axis, hook_add):
                min_c = -half_l + cover_canh if axis == "x" else -half_b + cover_canh
                max_c = half_l - cover_canh if axis == "x" else half_b - cover_canh
                cnt = 0
                total_len = 0.0
                c = min_c
                st = max(50.0, float(step))
                while c <= max_c + 1.0:
                    for s, e in clip_line_to_poly(inner_bot, axis, c):
                        cnt += 1
                        total_len += e - s + hook_add
                    c += st
                return cnt, total_len / 1000.0

            c_b1, m_b1 = clip_sum(b1["a"], "x", 2.0 * moc_duoi_len)
            c_b2, m_b2 = clip_sum(b2["a"], "y", 2.0 * moc_duoi_len)
            c_t1, m_t1 = clip_sum(t1["a"], "x", 2.0 * down_leg_t)
            c_t2, m_t2 = clip_sum(t2["a"], "y", 2.0 * down_leg_t)
            if c_b1 > 0:
                so_b1, total_b1_m = c_b1, m_b1
            if c_b2 > 0:
                so_b2, total_b2_m = c_b2, m_b2
            if c_t1 > 0:
                so_t1, total_t1_m = c_t1, m_t1
            if c_t2 > 0:
                so_t2, total_t2_m = c_t2, m_t2

    w_b1 = total_b1_m * unit_mass_kg_per_m(b1["d"])
    w_b2 = total_b2_m * unit_mass_kg_per_m(b2["d"])
    w_t1 = total_t1_m * unit_mass_kg_per_m(t1["d"])
    w_t2 = total_t2_m * unit_mass_kg_per_m(t2["d"])
    w_vach = float(cfg["soTangThepVach"]) * (perim_mm / 1000.0) * unit_mass_kg_per_m(vach["d"])

    kl_1_dai = round(w_b1 + w_b2 + w_t1 + w_t2 + w_vach, 1)
    kl_tong = round(kl_1_dai * max(1, int(cfg["soLuong"])), 1)

    checks = []
    coc_d = float(cfg["cocD"])
    ngam_coc = float(cfg["ngamCoc"])
    min_clear_req = coc_d / 2.0 + 100.0

    if min_edge_dist < min_clear_req:
        checks.append({
            "code": "COC-EDGE",
            "label": "Khoảng cách cọc tới mép đài",
            "status": "error",
            "detail": "Từ tim cọc tới mép đài (%g mm) < D/2 + 100 (%g mm)" % (min_edge_dist, min_clear_req),
        })
    else:
        desc = " (sơ đồ tự do)" if custom_piles else (" (%d×%d)" % (nx, ny))
        checks.append({
            "code": "COC-EDGE",
            "label": "Bố trí tim cọc trong đài",
            "status": "ok",
            "detail": "%d cọc%s, mép nhỏ nhất %g mm" % (tong_so_coc, desc, min_edge_dist),
        })

    if tong_so_coc > 1 and min_pile_spacing < 2.5 * coc_d:
        checks.append({
            "code": "COC-SPACING",
            "label": "Bước tim giữa các cọc",
            "status": "warn",
            "detail": "Khoảng cách tim 2 cọc gần nhất %g mm < 2.5D (%g mm)" % (min_pile_spacing, 2.5 * coc_d),
        })
    elif tong_so_coc > 1:
        checks.append({
            "code": "COC-SPACING",
            "label": "Bước tim giữa các cọc",
            "status": "ok",
            "detail": "Bước nhỏ nhất %g mm (≥ 2.5D = %g mm)" % (min_pile_spacing, 2.5 * coc_d),
        })

    if ngam_coc < 50:
        checks.append({
            "code": "NGAM-COC",
            "label": "Đoạn đầu cọc ngàm vào đài",
            "status": "warn",
            "detail": "Ngàm %g mm < 50–100 mm theo TCVN 10304" % ngam_coc,
        })
    elif cover_day < ngam_coc + 30:
        checks.append({
            "code": "COV-DAY",
            "label": "Lớp bảo vệ đáy lưới B1",
            "status": "warn",
            "detail": "c_đáy (%g mm) nên ≥ ngàm cọc (%g) + 30–35 mm" % (cover_day, ngam_coc),
        })
    else:
        checks.append({
            "code": "COV-DAY",
            "label": "Ngàm đầu cọc & Bảo vệ đáy",
            "status": "ok",
            "detail": "Ngàm %g mm, c_đáy = %g mm (Đạt)" % (ngam_coc, cover_day),
        })

    if H < 600:
        checks.append({
            "code": "H-DAI",
            "label": "Chiều cao đài cọc H",
            "status": "warn",
            "detail": "H = %g mm hơi mỏng cho đài cọc (thường ≥ 600–900 mm)" % H,
        })
    else:
        checks.append({
            "code": "H-DAI",
            "label": "Chiều cao đài cọc H",
            "status": "ok",
            "detail": "H = %g mm, cọc ngàm %g mm (Đạt)" % (H, ngam_coc),
        })

    return {
        "tongSoCoc": tong_so_coc,
        "piles": piles,
        "allColumns": all_columns,
        "outlinePolygon": outline_polygon,
        "isPolygonal": is_polygonal,
        "dienTichM2": dien_tich_m2,
        "minEdgeDist": min_edge_dist,
        "minPileSpacing": min_pile_spacing,
        "mepsCocX": meps_coc_x,
        "mepsCocY": meps_coc_y,
        "colCx": col_cx,
        "colCy": col_cy,
        "dxLeft": dx_left,
        "dxRight": dx_right,
        "dyTop": dy_top,
        "dyBot": dy_bot,
        "caoTrinhDayDai": cao_trinh_day_dai,
        "soThanhB1": so_b1,
        "soThanhB2": so_b2,
        "soThanhT1": so_t1,
        "soThanhT2": so_t2,
        "khoiLuong1Dai": kl_1_dai,
        "khoiLuongTong": kl_tong,
        "checks": checks,
        "hasError": any(c["status"] == "error" for c in checks),
        "hasWarn": any(c["status"] == "warn" for c in checks),
    }


# ==================== 4. DẦM MÓNG ====================

def compute_foundation_beam(cfg):
    support_segments = []
    span_segments = []
    cursor_x = 0.0
    sups = cfg.get("supports") or []
    spans = cfg.get("spans") or []
    sup_count = len(sups)

    for i in range(sup_count):
        sup = sups[i]
        sup_len = float(sup["supportLen"])
        x_start = cursor_x
        x_end = x_start + sup_len
        if i == 0:
            axis_x = x_start
        elif i == sup_count - 1:
            axis_x = x_end
        else:
            axis_x = round((x_start + x_end) / 2.0)

        support_segments.append({
            "id": sup["id"],
            "trucLabel": sup["trucLabel"],
            "xStart": x_start,
            "xEnd": x_end,
            "axisX": axis_x,
            "supportLen": sup_len,
            "colW": float(sup["colW"]),
            "colH": float(sup["colH"]),
        })
        cursor_x = x_end

        if i < len(spans):
            sp = spans[i]
            l_tt = float(sp["L_thongThuy"])
            sp_start = cursor_x
            sp_end = sp_start + l_tt
            clamped_zone = min(float(sp["vungGoiLen"]), int(math.floor(l_tt * 0.4)))
            vung_nhip_len = max(0.0, l_tt - 2.0 * clamped_zone)
            span_segments.append({
                "id": sp["id"],
                "xStart": sp_start,
                "xEnd": sp_end,
                "L_thongThuy": l_tt,
                "vungGoiLen": clamped_zone,
                "vungNhipLen": vung_nhip_len,
                "hasMidCrossBeam": bool(sp.get("hasMidCrossBeam", False)),
                "midCrossW": float(sp.get("midCrossW", 300)),
                "midCrossH": float(sp.get("midCrossH", 300)),
            })
            cursor_x = sp_end

    tong_l = round(cursor_x)
    b_dam = float(cfg["B_dam"])
    h_dam = float(cfg["H_dam"])
    cover = float(cfg["cover"])
    cao_trinh_day = round(float(cfg["caoTrinhTop"]) - h_dam / 1000.0, 3)

    main_len1_m = (tong_l - 2.0 * cover + 2.0 * float(cfg["thepTren1Moc"])) / 1000.0
    main_len2_m = (tong_l - 2.0 * cover - 50.0 + 2.0 * float(cfg["thepTren2Moc"])) / 1000.0
    bot_len_m = (tong_l - 2.0 * cover + 2.0 * float(cfg["thepDuoiMoc"])) / 1000.0
    total_clear_m = sum((s["L_thongThuy"] + 2.0 * float(cfg["thepGiaNeoGoi"])) / 1000.0 for s in span_segments)

    stirrup_perim_m = (2.0 * (max(150.0, b_dam - 2.0 * cover) + max(200.0, h_dam - 2.0 * cover)) + 160.0) / 1000.0
    stirrup_count = 0
    for sp in span_segments:
        end_c = 2 * (int(math.floor(sp["vungGoiLen"] / max(60.0, float(cfg["thepDaiAGoi"])))) + 1)
        mid_c = int(math.floor(sp["vungNhipLen"] / max(80.0, float(cfg["thepDaiANhip"]))))
        stirrup_count += end_c + mid_c

    c_tie_len_m = (max(150.0, b_dam - 2.0 * cover) + 140.0) / 1000.0
    c_tren_count = max(2, int(math.floor(tong_l / max(150.0, float(cfg["thepDaiCTrenA"])))))
    c_hong_count = max(2, int(math.floor(tong_l / max(150.0, float(cfg["thepDaiCHongA"])))))

    w_tren1 = float(cfg["thepTren1Count"]) * main_len1_m * unit_mass_kg_per_m(cfg["thepTren1D"])
    w_tren2 = float(cfg["thepTren2Count"]) * main_len2_m * unit_mass_kg_per_m(cfg["thepTren2D"])
    w_duoi = float(cfg["thepDuoiCount"]) * bot_len_m * unit_mass_kg_per_m(cfg["thepDuoiD"])
    w_gia = float(cfg["thepGiaCount"]) * total_clear_m * unit_mass_kg_per_m(cfg["thepGiaD"])
    w_dai = stirrup_count * stirrup_perim_m * unit_mass_kg_per_m(cfg["thepDaiD"])
    w_c_tie = (
        c_tren_count * c_tie_len_m * unit_mass_kg_per_m(cfg["thepDaiCTrenD"])
        + c_hong_count * c_tie_len_m * unit_mass_kg_per_m(cfg["thepDaiCHongD"])
    )

    kl_1_dam = round(w_tren1 + w_tren2 + w_duoi + w_gia + w_dai + w_c_tie, 1)
    kl_tong = round(kl_1_dam * max(1, int(cfg["soLuong"])), 1)

    checks = []
    if cover < 30 or cover > 70:
        checks.append({
            "code": "COV",
            "label": "Lớp bảo vệ cốt thép dầm móng",
            "status": "error" if cover < 25 else "warn",
            "detail": "c = %g mm (tiêu chuẩn dầm móng thường 40–50 mm khi có BT lót)" % cover,
        })
    else:
        checks.append({
            "code": "COV",
            "label": "Lớp bảo vệ cốt thép",
            "status": "ok",
            "detail": "c = %g mm phù hợp môi trường nền đất (Đạt)" % cover,
        })

    if h_dam < 400:
        checks.append({
            "code": "H-DAM",
            "label": "Chiều cao dầm móng H",
            "status": "warn",
            "detail": "H = %g mm hơi mảnh cho dầm giằng/dầm móng (thường 500–800 mm)" % h_dam,
        })
    else:
        checks.append({
            "code": "H-DAM",
            "label": "Kích thước tiết diện B×H",
            "status": "ok",
            "detail": "%g×%g mm (H/B = %.2f) (Đạt)" % (b_dam, h_dam, h_dam / max(100.0, b_dam)),
        })

    max_span = max((s["L_thongThuy"] for s in span_segments), default=0.0)
    if h_dam >= 600 and float(cfg["thepGiaCount"]) < 2:
        checks.append({
            "code": "GIA",
            "label": "Thép cấu tạo hông dầm (④)",
            "status": "warn",
            "detail": "Dầm cao H = %g mm (≥ 600) bắt buộc ≥ 2Ø12 hông dầm" % h_dam,
        })
    else:
        checks.append({
            "code": "GIA",
            "label": "Thép giá & Đai C chống phình hông",
            "status": "ok",
            "detail": "%gØ%g + đai C ⑦ Ø%ga%g (Đạt)" % (
                cfg["thepGiaCount"], cfg["thepGiaD"], cfg["thepDaiCHongD"], cfg["thepDaiCHongA"]
            ),
        })

    if float(cfg["thepDaiAGoi"]) > min(200.0, math.floor(h_dam / 2.0)):
        checks.append({
            "code": "DAI",
            "label": "Bước cốt đai vùng gối",
            "status": "warn",
            "detail": "a_gối = %g mm hơi thưa (TCVN khuyến nghị ≤ 100–150 mm)" % cfg["thepDaiAGoi"],
        })
    else:
        checks.append({
            "code": "DAI",
            "label": "Bố trí cốt đai vùng gối / nhịp",
            "status": "ok",
            "detail": "Nhịp max %g mm · Ø%ga%g/%g (Đạt)" % (
                max_span, cfg["thepDaiD"], cfg["thepDaiAGoi"], cfg["thepDaiANhip"]
            ),
        })

    return {
        "tongL": tong_l,
        "caoTrinhDay": cao_trinh_day,
        "supportSegments": support_segments,
        "spanSegments": span_segments,
        "khoiLuong1Dam": kl_1_dam,
        "khoiLuongTong": kl_tong,
        "checks": checks,
        "hasError": any(c["status"] == "error" for c in checks),
        "hasWarn": any(c["status"] == "warn" for c in checks),
    }
